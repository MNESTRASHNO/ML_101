(function (root, factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', 'kotlin'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('kotlin'));
  else {
    if (typeof kotlin === 'undefined') {
      throw new Error("Error loading module 'analytika-analytika-utils'. Its dependency 'kotlin' was not found. Please, check whether 'kotlin' is loaded prior to 'analytika-analytika-utils'.");
    }root['analytika-analytika-utils'] = factory(typeof this['analytika-analytika-utils'] === 'undefined' ? {} : this['analytika-analytika-utils'], kotlin);
  }
}(this, function (_, Kotlin) {
  'use strict';
  function freeze($receiver) {
    return $receiver;
  }
  function get_isFrozen($receiver) {
    return false;
  }
  function ensureNeverFrozen($receiver) {
  }
  var package$com = _.com || (_.com = {});
  var package$careem = package$com.careem || (package$com.careem = {});
  var package$analytika = package$careem.analytika || (package$careem.analytika = {});
  package$analytika.freeze_eoe559$ = freeze;
  package$analytika.get_isFrozen_vvk9$ = get_isFrozen;
  package$analytika.ensureNeverFrozen_s8jyvk$ = ensureNeverFrozen;
  Kotlin.defineModule('analytika-analytika-utils', _);
  return _;
}));

//# sourceMappingURL=analytika-analytika-utils.js.map
