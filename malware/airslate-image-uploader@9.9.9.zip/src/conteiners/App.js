import React, { Component, createRef, Fragment } from 'react';
import {
  string, bool, func, number, object, any,
} from 'prop-types';
import { connect } from 'react-redux';
import Dropzone from 'react-dropzone';
import classnames from 'classnames';
import Loader from 'airslate-controls/src/Loader';
import camera from 'airslate-static/src/_images/svg-inline/camera.svg';
import Content from '../components/Content';
import Video from '../components/Video';
import Footer from '../components/Footer';
import Button from '../components/Button';
import {
  imageUpload, imageSelector, resetStore, loading, scaleSelector, setTypeContent,
  loaded, streamUpdate, streamSelector, isLoadingSelector, imageEditorUpdate,
  typeContentSelector,
} from '../reducers/imageUploader';
import ImageEditor from '../components/ImageEditor';
import { startMediaStream, stopMediaStream } from '../actions';
import { $l } from '../app-config';
import { bytesToSize } from '../utils';
import { TYPE_EDITOR, TYPE_CAMERA, TYPE_DROPZONE } from '../constants';

const mapStateToProps = state => ({
  image: imageSelector(state),
  stream: streamSelector(state),
  isLoading: isLoadingSelector(state),
  scale: scaleSelector(state),
  typeContent: typeContentSelector(state),
});

const mapDispatchToProps = {
  imageUpload,
  streamUpdate,
  resetStore,
  loading,
  loaded,
  imageEditorUpdate,
  startMediaStream,
  stopMediaStream,
  setTypeContent,
};

class App extends Component {
  static propTypes = {
    maxScale: number,
    minScale: number,
    stepScale: number,
    scale: number,
    width: number,
    height: number,
    isLoading: bool,
    image: object,
    stream: object,
    disableClick: bool,
    maxSize: number,
    minSize: number,
    classNameDrop: string,
    activeClassName: string,
    acceptClassName: string,
    rejectClassName: string,
    disabledClassName: string,
    accept: any,
    cameraButtonDisable: any,
    typeContent: string.isRequired,
    onDropRejected: func,
    onDropMaxSizeRejected: func,
    imageEditorUpdate: func.isRequired,
    handleSave: func.isRequired,
    setTypeContent: func.isRequired,
    resetStore: func.isRequired,
    imageUpload: func.isRequired,
    startMediaStream: func.isRequired,
    stopMediaStream: func.isRequired,
    onDropAccepted: func,
    onCameraError: func,
  };

  static defaultProps = {
    classNameDrop: 'drag-and-drop drag-and-drop--profile-photo',
    disableClick: true,
    isLoading: false,
    accept: ['image/jpeg', 'image/png', 'image/gif'],
    stepScale: 0.01,
    stream: {},
    image: {},
    activeClassName: '',
    acceptClassName: '',
    rejectClassName: '',
    disabledClassName: '',
    onDropMaxSizeRejected: () => null,
    onDropRejected: () => null,
  };

  constructor(props) {
    super(props);
    this.dropzone = createRef();
    this.video = createRef();
  }

  componentWillUnmount() {
    const { resetStore } = this.props;

    resetStore();
  }

  onDropMaxSize = () => {
    const { maxSize, onDropMaxSizeRejected } = this.props;

    return onDropMaxSizeRejected && onDropMaxSizeRejected(`${$l('ERROR_FILE_IS_TOO_BIG')} ${bytesToSize(maxSize)}`);
  };

  onError = (files) => {
    const { onDropRejected, setTypeContent } = this.props;

    if (this.isMaxSizeValidate(files[0])) this.onDropMaxSize();

    onDropRejected(files);
    setTypeContent(TYPE_DROPZONE);
  };

  onDrop = (files) => {
    const { imageUpload } = this.props;

    imageUpload(files[0]);
  };

  isMaxSizeValidate = ({ size }) => {
    const { maxSize } = this.props;

    return maxSize < size;
  };

  fileChanged = () => this.dropzone.current.open();

  showDropScreen = () => {
    const { stopMediaStream, resetStore } = this.props;
    const { video } = this.video.current;

    resetStore();
    stopMediaStream(video.current);
  };

  startMediaStream = (cb) => {
    const { startMediaStream, onCameraError } = this.props;
    if (typeof cb === 'function') cb();
    return startMediaStream(TYPE_CAMERA, onCameraError);
  };

  handleStartMediaStream = () => {
    const { captureImgCb } = this.props;
    this.startMediaStream(captureImgCb);
  };

  captureImage = () => {
    const { setTypeContent, imageUpload } = this.props;
    const { video } = this.video.current;

    const canvas = document.createElement('canvas');
    canvas.width = video.current.videoWidth;
    canvas.height = video.current.videoHeight;

    canvas.getContext('2d').drawImage(video.current, 0, 0, canvas.width, canvas.height);
    imageUpload({ preview: canvas.toDataURL() });
    setTypeContent(TYPE_EDITOR);
  };

  render() {
    const {
      classNameDrop, disableClick, image, typeContent, isLoading, stream, accept, maxSize, minSize,
      activeClassName, acceptClassName, rejectClassName, disabledClassName, handleSave, maxScale,
      minScale, stepScale, imageEditorUpdate, scale, resetStore, stopMediaStream, width, height,
      cameraButtonDisable, onDropAccepted,
    } = this.props;

    const isShowDefaultPage = typeContent === TYPE_DROPZONE || typeContent === TYPE_EDITOR;
    const preview = image && image.preview;

    const wrapClassName = classnames({
      'sl-modal__inner': ![TYPE_EDITOR, TYPE_CAMERA].includes(typeContent),
      'loader-wrapper-solid': isLoading,
      'upload-section': preview,
    });

    const DropClassName = classnames({
      [classNameDrop]: !preview,
      'upload-section__inner': preview,
    });

    return (
      <div className={wrapClassName}>
        <div className="modal-content">
          {typeContent === TYPE_CAMERA && (
            <Fragment>
              <Video
                ref={this.video}
                stream={stream}
                stopMediaStream={stopMediaStream}
              />
              <Footer>
                <Button
                  wrapClassName="modal-footer__btn"
                  className="button button--sm button--secondary"
                  onClick={this.showDropScreen}
                >
                  Cancel
                </Button>
                <Button
                  wrapClassName="modal-footer__btn"
                  className="button button--sm button--primary"
                  icon={camera}
                  onClick={this.captureImage}
                >
                  {$l('TAKE_NEW_PHOTO_BTN_UPLOAD')}
                </Button>
              </Footer>
            </Fragment>
          )
          }

          {isShowDefaultPage && (
            <Fragment>
              {isLoading && <Loader />}
              <Dropzone
                accept={accept}
                className={DropClassName}
                ref={this.dropzone}
                onDrop={this.onDrop}
                disableClick={disableClick}
                onDropAccepted={onDropAccepted}
                maxSize={maxSize}
                minSize={minSize}
                activeClassName={activeClassName}
                acceptClassName={acceptClassName}
                rejectClassName={rejectClassName}
                disabledClassName={disabledClassName}
                onDropRejected={this.onError}
              >
                {preview ? (
                  <ImageEditor
                    scale={scale}
                    image={image}
                    maxScale={maxScale}
                    minScale={minScale}
                    stepScale={stepScale}
                    fileChanged={this.fileChanged}
                    imageEditorUpdate={imageEditorUpdate}
                    handleSave={handleSave}
                    startMediaStream={this.startMediaStream}
                    resetStore={resetStore}
                    width={width}
                    height={height}
                    cameraButtonDisable={cameraButtonDisable}
                  />
                ) : (
                  <Content
                    fileChanged={this.fileChanged}
                    startMediaStream={this.handleStartMediaStream}
                    cameraButtonDisable={cameraButtonDisable}
                  />
                )}
              </Dropzone>
            </Fragment>
          )
          }
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
