import Locale from '@airslate/front-locales/lib';
import defaultLocale from '@airslate/front-locales/locales/en/imageUploader';

const APP_LOCALE_PREFIX = 'IMAGE_UPLOADER_';
const isDev = () => process.env.NODE_ENV === 'development';

const { get: $l } = Locale(APP_LOCALE_PREFIX, {
  ...defaultLocale,
  ...window.allConstants,
});

export { $l, isDev };
