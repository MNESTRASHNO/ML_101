import React, { Component } from 'react';
import { number, func } from 'prop-types';
import minus from 'airslate-static/src/_images/svg-inline/minus-simple.svg';
import plus from 'airslate-static/src/_images/svg-inline/plus-simple.svg';
import Svg from 'airslate-controls/src/Svg';
import Slider from 'react-rangeslider';
import { SCALE } from '../reducers/imageUploader';

export default class RangeZoom extends Component {
  stepClick = 0.3;

  static propTypes = {
    scale: number,
    maxScale: number.isRequired,
    minScale: number.isRequired,
    stepScale: number.isRequired,
    imageEditorUpdate: func.isRequired,
  };

  static defaultProps = {
    scale: 0,
  };

  handleChange = (value) => {
    const { imageEditorUpdate } = this.props;
    imageEditorUpdate({ [SCALE]: value });
  };

  handleChangeLeft = () => {
    const { imageEditorUpdate, scale, minScale } = this.props;
    if (scale > minScale) {
      const step = scale - this.stepClick < minScale ? minScale : scale - this.stepClick;
      imageEditorUpdate({ [SCALE]: step });
    }
  };

  handleChangeRight = () => {
    const { imageEditorUpdate, scale, maxScale } = this.props;

    if (scale < maxScale) {
      const step = scale + this.stepClick > maxScale ? maxScale : scale + this.stepClick;
      imageEditorUpdate({ [SCALE]: step });
    }
  };

  render() {
    const {
      scale, maxScale, minScale, stepScale,
    } = this.props;

    return (
      <div className="range-slider">
        <div className="range-slider__control">
          <div className="range-slider__action">
            <button type="button" onClick={this.handleChangeLeft} className="range-slider__action-btn">
              <Svg symbol={minus} />
            </button>
          </div>
          <Slider
            min={minScale}
            max={maxScale}
            step={stepScale}
            value={scale}
            tooltip={false}
            onChange={this.handleChange}
          />
          <div className="range-slider__action">
            <button type="button" onClick={this.handleChangeRight} className="range-slider__action-btn">
              <Svg symbol={plus} />
            </button>
          </div>
        </div>
      </div>
    );
  }
}
