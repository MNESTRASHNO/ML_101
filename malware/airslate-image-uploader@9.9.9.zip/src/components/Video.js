import React, { createRef, Component } from 'react';
import { object, func } from 'prop-types';

export default class Video extends Component {
  video = createRef();

  static propTypes = {
    stream: object.isRequired,
    stopMediaStream: func,
  };

  componentDidMount() {
    const { stream } = this.props;

    this.updateVideoStream(stream);
  }


  componentWillUnmount() {
    const { stopMediaStream } = this.props;

    stopMediaStream(this.video.current);
  }

  updateVideoStream = (stream) => {
    this.video.current.srcObject = stream;
  };

  render() {
    return (
      <div className="media">
        <div className="media__video-wrap media__video-wrap--16to9">
          <video
            className="media__video"
            ref={this.video}
            muted
            autoPlay
          />
        </div>
      </div>
    );
  }
}
