import React from 'react';
import { func, any } from 'prop-types';
import upload from 'airslate-static/src/_images/svg-inline/upload.svg';
import camera from 'airslate-static/src/_images/svg-inline/camera.svg';
import Icon from 'ui-components/src/components/Icon';
import FileIcon from 'airslate-static.icons/src/colored/48/upload.svg';
import Button from './Button';
import { $l } from '../app-config';

const Content = ({ fileChanged, startMediaStream, cameraButtonDisable }) => (
  <div className="drag-and-drop__content">
    <div className="drag-and-drop__info">
      <div className="drag-and-drop__icon">
        <Icon id={FileIcon.id} />
      </div>
      <span className="drag-and-drop__title">
        { $l('TITLE') }
      </span>
      <span className="drag-and-drop__subtitle">
        { $l('DESC') }
      </span>
    </div>
    <div className="drag-and-drop__action">
      <Button icon={upload} onClick={fileChanged}>
        { $l('SELECT_PHOTO_BTN') }
      </Button>
      { cameraButtonDisable
        ? null
        : (
          <Button icon={camera} onClick={startMediaStream}>
            { $l('TAKE_NEW_PHOTO_BTN_UPLOAD') }
          </Button>
        )}
    </div>
  </div>
);

Content.propTypes = {
  fileChanged: func.isRequired,
  startMediaStream: func.isRequired,
  cameraButtonDisable: any,
};

export default Content;
