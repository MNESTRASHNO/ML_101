import React, { Component, createRef, Fragment } from 'react';
import {
  object, number, func, array, any,
} from 'prop-types';
import AvatarEditor from 'react-avatar-editor';
import camera from 'airslate-static/src/_images/svg-inline/camera.svg';
import upload from 'airslate-static/src/_images/svg-inline/upload.svg';
import Footer from './Footer';
import Button from './Button';
import RangeZoom from './RangeZoom';
import { $l } from '../app-config';

export default class ImageEditor extends Component {
  editor = createRef();

  static propTypes = {
    image: object,
    width: number,
    height: number,
    border: number,
    minScale: number,
    maxScale: number,
    style: object,
    scale: number,
    color: array,
    stepScale: number.isRequired,
    fileChanged: func.isRequired,
    handleSave: func.isRequired,
    imageEditorUpdate: func.isRequired,
    startMediaStream: func.isRequired,
    cameraButtonDisable: any,
  };

  static defaultProps = {
    style: {
      width: 520,
      height: 520,
    },
    minScale: 1,
    maxScale: 5,
    width: 100,
    height: 100,
    border: 150,
    color: [0, 0, 0, 0.6],
    scale: 2,
    image: {},
  };

  saveImage = () => {
    const { handleSave } = this.props;
    const img = this.editor.current.getImageScaledToCanvas().toDataURL();
    const rect = this.editor.current.getCroppingRect();

    return handleSave({ img, ...rect });
  };

  renderTakeBtn = (cameraButtonDisable) => {
    const { startMediaStream } = this.props;

    return (
      cameraButtonDisable
        ? null
        : (
          <Button
            wrapClassName="modal-footer__btn"
            className="button button--sm button--secondary"
            icon={camera}
            onClick={startMediaStream}
          >
            {$l('TAKE_NEW_PHOTO_BTN')}
          </Button>
        )
    );
  };

  render() {
    const {
      image: { preview }, fileChanged, imageEditorUpdate, scale, minScale, maxScale,
      stepScale, style, height, width, border, color, cameraButtonDisable,
    } = this.props;

    return (
      <Fragment>
        <div className="upload-section__inner">
          <div className="modal-content__image-block">
            <AvatarEditor
              ref={this.editor}
              image={preview}
              scale={scale}
              width={width}
              height={height}
              border={border}
              color={color}
              style={style}
            />
            <RangeZoom
              scale={scale}
              imageEditorUpdate={imageEditorUpdate}
              minScale={minScale}
              maxScale={maxScale}
              stepScale={stepScale}
            />
          </div>
        </div>

        <Footer leftBtn={this.renderTakeBtn(cameraButtonDisable)}>
          <Button
            position="left"
            wrapClassName="modal-footer__btn"
            className="button button--sm button--secondary"
            icon={upload}
            onClick={fileChanged}
          >
            {$l('SELECT_PHOTO_BTN')}
          </Button>
          <Button
            wrapClassName="modal-footer__btn"
            className="button button--sm button--primary"
            onClick={this.saveImage}
          >
            {$l('SAVE_BTN')}
          </Button>
        </Footer>
      </Fragment>
    );
  }
}
