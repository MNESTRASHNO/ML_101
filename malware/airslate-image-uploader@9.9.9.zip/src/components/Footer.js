import React from 'react';
import PropTypes from 'prop-types';

const Footer = ({ children, leftBtn }) => (
  <footer className="modal-footer modal-footer--upload__section">
    {leftBtn && (
      <div className="modal-footer__actions">
        {leftBtn}
      </div>
    )}
    <div className="modal-footer__actions modal-footer__actions--md modal-footer__actions--justify-right">
      <div className="modal-footer__btn">
        {children.map((Child, idx) => (
          <div key={idx} className="modal-footer__btn">
            {Child}
          </div>
        ))}
      </div>
    </div>
  </footer>
);

Footer.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node,
    PropTypes.array,
  ]),
  leftBtn: PropTypes.element,
};

export default Footer;
