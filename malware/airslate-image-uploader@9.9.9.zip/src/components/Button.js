import React from 'react';
import { string, func, shape } from 'prop-types';
import Svg from 'airslate-controls/src/Svg';

const Button = ({
  children, wrapClassName, className, icon, onClick,
}) => (
  <div role="presentation" className={wrapClassName} onClick={onClick}>
    <label role="button" className={className}>
      <span className="button__body">
        {icon && <span className="button__icon">
          <Svg symbol={icon} />
        </span>}
        <span className="button__text">
          { children }
        </span>
      </span>
    </label>
  </div>
);

Button.propTypes = {
  children: string.isRequired,
  wrapClassName: string,
  className: string,
  icon: shape({
    id: string,
    content: string,
  }),
  onClick: func.isRequired,
};

Button.defaultProps = {
  className: 'button button--primary',
  wrapClassName: 'drag-and-drop__action-item',
};

export default Button;
