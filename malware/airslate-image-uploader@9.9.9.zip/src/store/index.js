import {
  createStore,
  combineReducers,
  applyMiddleware,
  compose,
} from 'redux';
import { getMiddleware } from '../middleware';
import reducers from '../reducers';

export const store = () => {
  const middleware = getMiddleware();

  const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

  return createStore(
    combineReducers(reducers),
    composeEnhancers(applyMiddleware(...middleware)),
  );
};