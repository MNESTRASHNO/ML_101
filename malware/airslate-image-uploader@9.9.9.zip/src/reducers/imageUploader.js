import { createAction, handleActions } from 'redux-actions';
import { createSelector } from 'reselect';
import get from 'lodash/get';
import { TYPE_DROPZONE } from '../constants';

const REDUCER_NAME = 'imageUploader';

export const SCALE = 'scale';

export const imageUpload = createAction('IMAGE_UPLOAD');
export const streamUpdate = createAction('STREAM_VIDEO');
export const resetStore = createAction('RESET');
export const imageEditorUpdate = createAction('UPDATE_IMAGE_EDITOR');
export const setTypeContent = createAction('TYPE_CONTENT');
export const loading = createAction('LOADING');
export const loaded = createAction('LOADED');

const initialState = {
  stream: null,
  image: null,
  load: false,
  typeContent: TYPE_DROPZONE,
  imageEditor: {
    [SCALE]: 2,
  },
};

export const imageUploader = handleActions({
  [imageUpload]: (state, { payload }) => ({ ...state, image: payload }),
  [setTypeContent]: (state, { payload }) => ({ ...state, typeContent: payload }),
  [streamUpdate]: (state, { payload }) => ({ ...state, stream: payload }),
  [imageEditorUpdate]: (state, { payload }) => ({
    ...state, imageEditor: { ...state.imageEditor, ...payload },
  }),
  [loading]: state => ({ ...state, loading: true }),
  [loaded]: state => ({ ...state, loading: false }),
  [resetStore]: () => initialState,
}, initialState);

export const stateSelector = state => get(state, REDUCER_NAME);
export const imageEditorSelector = createSelector(stateSelector, state => get(state, 'imageEditor'));

export const imageSelector = createSelector(stateSelector, state => get(state, 'image'));
export const typeContentSelector = createSelector(stateSelector, state => get(state, 'typeContent'));
export const isLoadingSelector = createSelector(stateSelector, state => get(state, 'loading'));
export const streamSelector = createSelector(stateSelector, state => get(state, 'stream'));
export const scaleSelector = createSelector(imageEditorSelector, state => get(state, [SCALE]));
