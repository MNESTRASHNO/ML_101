import { imageUploader } from './imageUploader';

export default {
  imageUploader,
};
