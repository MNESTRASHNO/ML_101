export const TYPE_EDITOR = 'Editor';
export const TYPE_CAMERA = 'Camera';
export const TYPE_DROPZONE = 'Dropzone';
export const ERROR_NOT_ALLOWED = 'NotAllowedError';
