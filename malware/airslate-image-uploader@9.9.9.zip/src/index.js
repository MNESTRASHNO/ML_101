import React from 'react';
import { Provider } from 'react-redux';
import { store as createStore } from './store';
import App from './conteiners/App';

const store = createStore();

export default function ImageUploader(props) {
  return (
    <Provider store={store}>
      <App {...props} />
    </Provider>
  );
}
