import thunk from 'redux-thunk';
import { isDev } from '../app-config';

export const getMiddleware = () => {
  const middleware = [thunk];

  if (isDev()) {
    middleware.push(require('redux-logger').createLogger({ collapsed: true }));
  }

  return middleware;
};
