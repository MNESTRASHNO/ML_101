import {
  loading, loaded, setTypeContent, streamUpdate, resetStore,
} from '../reducers/imageUploader';
import { isUserMedia } from '../utils';
import { $l } from '../app-config';
import { ERROR_NOT_ALLOWED } from '../constants';

export const startMediaStream = (TYPE_CONTENT, showError) => (dispatch) => {
  dispatch(loading());

  isUserMedia();

  navigator.mediaDevices.getUserMedia({ video: true })
    .then((stream) => {
      dispatch(streamUpdate(stream));
      dispatch(setTypeContent(TYPE_CONTENT));
      dispatch(loaded());
    })
    .catch((e) => {
      dispatch(loaded());
      dispatch(resetStore());

      if (typeof showError === 'function') {
        if (e.name === ERROR_NOT_ALLOWED) {
          showError($l('ERROR_CAMERA_ACCESS'));
        } else {
          showError(e.message);
        }
      }
    });
};

export const stopMediaStream = videoEl => (dispatch) => {
  videoEl.srcObject.getTracks().forEach(track => track.stop());
  dispatch(streamUpdate(null));
};
