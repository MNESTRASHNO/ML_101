//index.js

function helloNpm() {
  return "hello NPM, same version update"
}

module.exports = helloNpm
