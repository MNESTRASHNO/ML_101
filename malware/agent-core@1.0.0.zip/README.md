# What's that ?

Agent Core of frontend.

# Reference
 + [代码规范](https://segmentfault.com/a/1190000019661168)
