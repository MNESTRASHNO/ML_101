"use strict";
/** @format */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.api = void 0;
var nprogress_1 = __importDefault(require("nprogress"));
var axios_1 = __importDefault(require("axios"));
// const api = axios.create({ baseURL: 'https://notfound945.cn/backend/' });
var api = axios_1.default.create({ baseURL: process.env.API });
exports.api = api;
var reqCount = 0;
var request = {
    success: function (configs) {
        reqCount++;
        nprogress_1.default.start();
        configs.headers = {
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/octet-stream;charset=UTF-8',
        };
        console.debug('request config ', configs);
        return configs;
    },
    error: function (err) {
        if (axios_1.default.isAxiosError(err)) {
            console.debug('axios error');
        }
        return Promise.reject(err);
    },
};
var response = {
    success: function (response) {
        reqCount--;
        if (reqCount <= 0) {
            nprogress_1.default.done();
        }
        if (response.status !== 200) {
            return Promise.reject(response.data);
        }
        return response;
    },
    error: function (err) {
        var _a;
        if (axios_1.default.isAxiosError(err)) {
            ((_a = err.response) === null || _a === void 0 ? void 0 : _a.status) ? String(err.response.status) : 'Timeout';
        }
        return Promise.reject(err);
    },
};
api.interceptors.request.use(request.success, request.error);
api.interceptors.response.use(response.success, response.error);
//# sourceMappingURL=axios.js.map