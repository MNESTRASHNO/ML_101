/** @format */
declare const api: import("axios").AxiosInstance;
export { api };
