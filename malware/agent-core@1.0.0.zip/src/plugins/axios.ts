/** @format */

// import NProgress from 'nprogress'

import axios, {AxiosError, AxiosRequestConfig, AxiosResponse} from 'axios'

// const api = axios.create({ baseURL: 'https://notfound945.cn/backend/' });
const api = axios.create({baseURL: process.env.API})

let reqCount = 0
const request = {
    success: (configs: AxiosRequestConfig) => {
        reqCount++
        // NProgress.start()
        configs.headers = {
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/octet-stream;charset=UTF-8',
        }
        return configs
    },
    error: (err: Error | AxiosError) => {
        if (axios.isAxiosError(err)) {
            console.debug('axios error')
        }
        return Promise.reject(err)
    },
}

const response = {
    success: (response: AxiosResponse) => {
        reqCount--
        if (reqCount <= 0) {
            // NProgress.done()
        }
        if (response.status !== 200) {
            return Promise.reject(response.data)
        }
        return response
    },
    error: (err: Error | AxiosError) => {
        if (axios.isAxiosError(err)) {
            err.response?.status ? String(err.response.status) : 'Timeout'
        }
        return Promise.reject(err)
    },
}

api.interceptors.request.use(request.success, request.error)
api.interceptors.response.use(response.success, response.error)

export {api}
