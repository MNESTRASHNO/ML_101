/* eslint-disable */
import { api as axiosPlugin } from './axios'
export class ApiSendConfig {
    baseEnv = process.env.NODE_ENV;
    label = {};
    appID = 0;
    service = '';
    ctxUID = 0
    ctxAppID = ''
}
async function frontAgent (serviceName: string, methodID: number, methodName: string, param: any, config: ApiSendConfig) {
    const uploadDatas = new FormData()
    const blob = new Blob([param], {
        type: 'application/octet-stream;charset=UTF-8'
    })
    uploadDatas.append('protobuf', blob)
    let response
    const appID = config.appID ? config.appID : '1036'
    serviceName = serviceName + '.'
    const query = [
        `__rpc_appid=${appID}`,
        `__env=${config.baseEnv}`,
        `__s=${serviceName}`,
        `__m_id=${methodID}`,
        `__m_name=${methodName}`,
        `__label=${JSON.stringify(config.label)}`,
        `__ctx_uid=${config.ctxUID}`,
        `__ctx_appid=${config.ctxAppID}`,
    ]
    // response = await axiosPlugin.post(
    //   `pb?` + query.join("&"),
    //   uploadDatas
    // )
    response = await axiosPlugin.post('/post_take_paste', param)
    const bstr = atob(response.data)
    let n = bstr.length
    const u8arr = new Uint8Array(n)
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n) // 转换编码后才可以使用charCodeAt 找到Unicode编码
    }
    return { data: u8arr, code: response.status }
}

export const rpcPlugin = {
    async sendV1 (serviceName: string, methodID: number, methodName: string, param: any, config: ApiSendConfig) {
        return await frontAgent(serviceName, methodID, methodName, param, config)
    }
}
