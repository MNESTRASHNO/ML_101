export declare class ApiSendConfig {
    baseEnv: string;
    label: {};
    appID: number;
    service: string;
    ctxUID: number;
    ctxAppID: string;
}
export declare const rpcPlugin: {
    sendV1(serviceName: string, methodID: number, methodName: string, param: any, config: ApiSendConfig): Promise<{
        data: Uint8Array;
        code: number;
    }>;
};
