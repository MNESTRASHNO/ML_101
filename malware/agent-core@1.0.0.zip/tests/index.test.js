/** @format */
import { api } from 'dist/index';
describe('app:is object', () => {
    test('isArrayLike(): Object', () => {
        return api.post('https://notfound945.cn/backend/post_take_paste').then(data => {
            expect(data.status).toBe(200);
        });
    });
});
//# sourceMappingURL=index.test.js.map