/** @format */
declare const api: import("axios").AxiosInstance;
export { api };
//# sourceMappingURL=axios.d.ts.map