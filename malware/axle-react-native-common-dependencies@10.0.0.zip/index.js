function helloNpm() {
  return "hello NPM"
}

module.exports = helloNpm