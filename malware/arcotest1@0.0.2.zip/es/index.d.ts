import { ReactNode } from 'react';
import { ButtonProps } from '@arco-design/web-react/es/Button';
/**
 * @title TooltipButton
 */
export interface TooltipButtonProps {
    children?: any;
    /**
     * @zh 按钮的标题
     * @defaultValue `Hello Arco`
     * @version 1.0.0
     */
    title?: ReactNode;
    /**
     * @zh 按钮的提示
     */
    btnProps?: ButtonProps;
}
declare const TooltipButton: (props: TooltipButtonProps) => JSX.Element;
export default TooltipButton;
