## 属性/Props

### TooltipButton

|参数名|描述|类型|默认值|版本|
|---|---|---|---|---|
|title|按钮的标题|`ReactNode`|``Hello Arco``|1.0.0|
|btnProps|按钮的提示|`ButtonProps`|`-`|-|

## Demos


~~~json type=description
[
  {
    "kind": "file",
    "name": "组件名",
    "memberOf": "组件类型，例如：数据输入",
    "description": "描述你的组件。",
    "author": "物料作者",
    "package": "arcotest1"
  },
  {
    "kind": "member",
    "name": "基本用法",
    "description": "描述你的例子"
  }
]
~~~

~~~jsx
import React from 'react';
import TooltipButton from 'arcotest1';

export default () => {
  return <TooltipButton title="tooltip title">Demo Basic</TooltipButton>;
};

~~~

