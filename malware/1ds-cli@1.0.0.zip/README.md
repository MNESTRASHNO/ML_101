# 1ds-cli

1DS cli scripts

## Features

- Shipit-cli
- Remote sync
- Env sync

### Usage

```json
// package.json
{
  "name": "your-package",
  "version": "1.0.0",
  "scripts": {
    "release": "yarn dlx 1ds-cli",
    "release:alpha": "PRE_RELEASE=alpha npm run release",
    "release:beta": "PRE_RELEASE=beta npm run release",
    "release:dry-run": "DRYRUN=true npm run release"
  },
  "dependencies": {
    
  }
}
```
