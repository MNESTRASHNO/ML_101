# apnic-ui

Apnic vue ui components

## Features

- ES6 syntax, managed with Prettier + Eslint and Stylelint
- Unit testing via Vitest
- Vue
- ESM

## Install

```sh
yarn add apnic-ui
// or
npm i apnic-ui
```

### Usage

```js
import { TextTrackList } from 'apnic-ui';
import { createApp } from 'vue'

const app = createApp({})

app.component('TextTrackList', TextTrackList)
```
