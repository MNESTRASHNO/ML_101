export const inspect = {
    custom: "",
};
