import * as crypto from "./crypto/crypto";

export default crypto;
