export default {
    type: () => {
        return "Browser";
    },

    release: () => {
        return "1.0";
    },
};
