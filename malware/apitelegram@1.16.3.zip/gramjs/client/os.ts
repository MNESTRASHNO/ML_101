import * as os from "os";

export default os;
