export const promises = {
    lstat: (...args: any): any => {},
    stat: (...args: any): any => {},
    readFile: (...args: any): any => {},
    open: (...args: any): any => {},
};
export const createWriteStream: any = {};
export const WriteStream: any = {};
export const lstatSync: any = {};
export const existsSync: any = {};
