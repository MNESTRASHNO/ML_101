export default {
    basename(...args: any): any {},
    resolve(...args: any): any {},
    path(...args: any): any {},
    join(...args: any): any {},
};
