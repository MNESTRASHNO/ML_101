export class Socket {
    public destroyed?: boolean;

    connect(...args: any): any {}

    on(...args: any): any {}

    write(...args: any): any {}

    destroy(...args: any): any {}
    unref(...args: any): any {}
}
