export const SocksClient = {
    createConnection: (x: any): any => {},
};
