export class PromisedNetSockets {
    constructor(...args: any) {}

    connect(...args: any): any {}

    close(...args: any): any {}

    write(...args: any): any {}

    readExactly(...args: any): any {}

    read(...args: any): any {}
}
