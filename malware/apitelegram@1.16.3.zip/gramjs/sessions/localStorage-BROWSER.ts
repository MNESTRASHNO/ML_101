export class LocalStorage {
    constructor(location: string) {
        throw new Error("Do not call me");
    }
}
