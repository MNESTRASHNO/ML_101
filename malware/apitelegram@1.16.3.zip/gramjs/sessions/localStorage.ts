export const LocalStorage = require("node-localstorage").LocalStorage;
