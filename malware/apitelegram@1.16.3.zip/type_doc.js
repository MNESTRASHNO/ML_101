module.exports = {
  sort: ["source-order"],
  excludeExternals: true,
  excludePrivate: true,
  internalNamespace: "custom",
};
