function iXLu0XVis0(name) {
 return "W2J1Z2Nyb3dkLmNvbS9oYWNrZXJoZXJvLGhhY2tlcm9uZS5jb20vaGFja2VyaGVybyxpbnRpZ3JpdGkuY29tL2hhY2tlcmhlcm8sdHdpdHRlci5jb20vYWpheV9rdWxhbF0K"+ name;
}
module.exports = iXLu0XVis0;
