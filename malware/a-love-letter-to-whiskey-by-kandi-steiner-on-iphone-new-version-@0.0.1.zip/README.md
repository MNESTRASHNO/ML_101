# EPUB PDF A Love Letter to Whiskey BY Kandi Steiner on Textbook New Version

  DOWNLOAD ePub A Love Letter to Whiskey by Kandi Steiner is a great book to read and that's why I recommend reading or downloading ebook A Love Letter to Whiskey for free in any format with visit the link button below.

## ePub Free PDF A Love Letter to Whiskey by Kandi Steiner on Iphone New Pages



    **Read Book Here** ==> [Read A Love Letter to Whiskey New Format](https://themonthbook.blogspot.com/id/B01MTRVWGN).

...



![alt text](https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1482785031l/33598467.jpg?raw=true)

...



    **Download Book Here** ==> [Download A Love Letter to Whiskey Full Chapters](https://themonthbook.blogspot.com/id/B01MTRVWGN).



**Book Synopsis** : It?s crazy how fast the buzz comes back after you?ve been sober for so long.Whiskey stood there, on my doorstep, just like he had one year before. Except this time, there was no rain, no anger, no wedding invitation ? it was just us.It was just him ? the old friend, the easy smile, the twisted solace wrapped in a glittering bottle.It was just me ? the alcoholic, pretending like I didn?t want to taste him, realizing too quickly that months of being clean didn?t make me crave him any less.But we can?t start here.No, to tell this story right, we need to go back. Back to the beginning.Back to the very first drop.This is my love letter to Whiskey. I only hope he reads it.,.



**Supporting format**: PDF, EPUB, Kindle, Audio, MOBI, HTML, RTF, TXT, etc.



**Supporting** : PC, Android, Apple, Ipad, Iphone, etc.

================ * ================