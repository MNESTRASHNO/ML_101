module.exports = function () {
    console.log("hello world")
}