## all-in-one-web-header-footer

### 介绍

	基于 header-footer 的 all-in-one-web-header-footer 组件

### 使用
	
	import all-in-one-web-header-footer; 
	
	Vue.use(all-in-one-web-header-footer);
	
	同时引入以下css代码
	
	.icon {
      width: 1em;
      height: 1em;
      vertical-align: -0.15em;
      fill: currentColor;
      overflow: hidden;
    }
  

### 更新历史

	- 2023/07/11 v1.0.0 create project by@dunra
	- 2023/07/11 v1.0.1 修复引用问题 by@dunra
	- 2023/07/11 v1.0.2 删除无用代码 by@dunra

### 项目启动


	安装依赖	yarn install
	
	本地运行	yarn dev 或者 yarn serve
	
	打包编译	yarn lib 