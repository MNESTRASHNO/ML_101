module.exports = {
  fontWeight: {
    light: 100,
    normal: 400,
    lightSemibold: 500,
    semibold: 600,
    bold: 'bold',
    xBold: 900
  },

  borderRadius: 2,
  primaryBorderRadius: 4,
  secondaryBorderRadius: 6,

  input: {
    borderWidth: 1
  },

  containerSize: {
    small: 750,
    medium: 970,
    large: 1170
  },

  fontSize: {
    hugest: '4.5rem', // ~72px
    huger: '3.75rem', // ~60px
    huge: '3rem', // ~48px
    largest: '2rem', // ~32px
    larger: '1.5rem', // ~24px
    large: '1.125rem', // ~18px
    base: 16,
    small: '.875rem', // ~14px
    smaller: '.75rem', // ~12px
    smallest: '.625rem', // ~10px
    tiny: '.5rem' // ~8px
  },

  padding: {
    hugest: '4.6em', // ~72px
    huger: '3.75em', // ~60px
    huge: '3em', // ~48px
    largest: '2.5em', // ~40px
    larger: '2em', // ~32px
    large: '1.5em', // ~24px
    base: '1.25em', // ~20px
    small: '1em', // ~16px
    smaller: '.5em', // ~8px
    smallest: '.25em', // ~4px
    tiny: '.125em' // ~2px
  }
};



//////////////////
// WEBPACK FOOTER
// ./node_modules/angieslist-app-platform/node_modules/angieslist-styles/js/stylesTypography.js
// module id = 2223
// module chunks = 21