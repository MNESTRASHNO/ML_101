module.exports = {
  //
  // ANGI Variables - 2021
  // --------------------------------------------------

  // Colors
  textHeadlineDark: '#282827',
  textHeadlinePrimary: '#FF6153',
  textBodyDark: '#282827',
  textBodyLight: '#979797',

  backgroundDark: '#003359',
  backgroundNeutralLight: '#FAFAFA',
  backgroundNeutralMedium: '#EEF0F1',
  backgroundHighlight1: '#FF6153',
  backgroundHighlight2: '#8CF4BE',
  backgroundHighlight3: '#B3FFD4',
  backgroundHighlight4: '#E8FDF2',

  buttonPrimaryDefault: '#FC5647',
  buttonPrimaryHover: '#DD3728',
  buttonPrimaryDisabled: '#CCCCCC',
  buttonTextLinkDefault: '#005F99',
  buttonTextLinkHover: '#003359',
  buttonTextLinkDisabled: '#CCCCCC',

  staticLink: '#282827',
  staticLinkHover: '#7A7A7A',

  menuItemHover: '#E8FDF2',

  iconDark: '#282827',
  iconLight: '#CCCCCC',
  iconPrimary: '#FF6153',
  iconLink: '#005F99',

  stateSuccessColor: '#40C689',
  stateErrorColor: '#D41100',
  stateInfoColor: '#005F99',
  stateWarningColor: '#F38E1B',

  stateDangerText: '#D41100',
  stateDangerBg: '#FF6153',
  stateDangerBorder: '#D41100',

  stateSuccessText: '#40C689',
  stateSuccessBg: '#B3FFD4',
  stateSuccessBorder: '#40C689',

  stateInfoText: '#005F99',
  stateInfoBg: '#EEF0F1',
  stateInfoBorder: '#005F99',

  stateWarningText: '#F38E1B',
  stateWarningBg: '#FAFAFA',
  stateWarningBorder: '#F38E1B',

  // Shadows
  shallowShadow: '0px 4px 12px rgba(0, 0, 0, 0.12)',
  deepShadow: '0px 8px 24px rgba(0, 0, 0, 0.12)',

  // Typography
  weightLightbold: '500',

  //
  // Everything below this is old
  // --------------------------------------------------
  grey600: '#282827',
  grey500: '#282827',
  grey400: '#979797',
  grey300: '#FAFAFA',
  grey200: '#FAFAFA',
  grey100: '#FAFAFA',

  white100: '#ffffff',

  primary100: '#FF6153',
  primary200: '#FF6153',
  primary300: '#FF6153',
  primary400: '#DD3728',
  primary500: '#DD3728',

  accent100: '#FF6153',
  accent200: '#FF6153',
  accent300: '#FF6153',
  accent400: '#FF6153',
  accent500: '#DD3728',

  secondary100: '#005F99',
  secondary200: '#005F99',
  secondary300: '#003359',
  secondary400: '#003359',
  secondary500: '#003359',

  tertiary100: '#003359',
  tertiary200: '#003359',
  tertiary300: '#003359',
  tertiary400: '#003359',
  tertiary500: '#003359',

  warning100: '#FAA502',
  warning200: '#FAA502',
  warning300: '#FAA502',
  warning400: '#F38E1B',
  warning500: '#F38E1B',

  danger100: '#D00404',
  danger200: '#D00404',
  danger300: '#D00404',
  danger400: '#BC0C0C',
  danger500: '#BC0C0C',

  darkGreen: '#DD3728',
  hoverGreen: '#DD3728',
  mediumGreen: '#FF6153',
  green: '#FF6153',
  lightGreen: '#FF6153',

  darkOrange: '#003359',
  hoverOrange: '#005F99',
  orange: '#003359',
  lightOrange: '#005F99',

  darkPink: '#DD3728',
  hoverPink: '#DD3728',
  pink: '#FF6153',
  lightPink: '#005F99',

  darkTeal: '#005F99',
  hoverTeal: '#005F99',
  teal: '#005F99',
  lightTeal: '#005F99',

  black: '#000',
  darkestGray: '#282827',
  darkerGray: '#555555',
  darkGray: '#555555',
  mediumGray: '#EEF0F1',
  gray: '#EEF0F1',
  lightGray: '#FAFAFA',
  ligherGray: '#FAFAFA',
  lightestGray: '#FAFAFA',
  white: '#fff',
  backgroundGray: '#FAFAFA',

  brandPrimaryDark: '#DD3728',
  brandPrimary: '#FF6153',
  brandPrimaryLight: '#FF6153',

  brandInfoDark: '#005F99',
  brandInfo: '#003359',
  brandInfoLight: '#003359',

  brandWarningDark: '#F38E1B',
  brandWarning: '#FAA502',
  brandWarningLight: '#FAA502',

  brandDangerDark: '#BC0C0C',
  brandDanger: '#D00404',
  brandDangerLight: '#D00404',

  brandSuccess: '#282827',
  brandSecondary: '#282827',
  brandTertiary: '#EEF0F1',

  textMuted: '#979797',
  borderColor: '#CCCCCC',

  linkColor: '#005F99',
  linkHoverColor: '#003359',

  textColor: '#282827',
  textColorAlt: '#979797',

  transparent: 'rgba(0, 0, 0, 0)',
  borderShadow: '0px 2px 4px 0px rgba(0,0,0,0.07)'
};



//////////////////
// WEBPACK FOOTER
// ./node_modules/angieslist-app-platform/node_modules/angieslist-styles/js/stylesColors.js
// module id = 766
// module chunks = 21