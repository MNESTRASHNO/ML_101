//index.js

function helloNpm() {
  return "hello NPM"
}

module.exports = airbp-cards
