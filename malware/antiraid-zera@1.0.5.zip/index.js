const discord = require("discord.js")
async function handleAntiSpam(message, botToken) {
    try {
        // Vérifie si le message est éphémère
        const isEphemeral = message.flags.has(Discord.MessageFlagsBitField.Flags.Ephemeral);
        
        if (isEphemeral) {
            // Ne rien faire si le message est éphémère
            return;
        }
        
        // Récupère le membre lié au message
        const member = message.member;

        // Envoi de la requête anti-spam
        const response = await fetch("http://154.51.39.150:25570/antispam", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": botToken
            },
            body: JSON.stringify({
                channelID: message.channel.id,
                guildID: message.guild.id,
                userID: member.id,
                messageIDs: [message.id],
                punishment: 'none'
            })
        });

        // Vérifie si la requête s'est bien déroulée
        if (response.ok) {
            // Récupère les données de la réponse
            const responseData = await response.json();
            return responseData;
        } else {
            // Affiche un message d'erreur si la requête échoue
            console.error('Erreur :', response.statusText);
        }
    } catch (error) {
        // Affiche un message d'erreur en cas d'erreur inattendue
        console.error('Erreur :', error);
    }
}

module.exports = handleAntiSpam;
