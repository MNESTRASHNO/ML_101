#include <node.h>
#include <nan.h>
#include <Windows.h>
#include <dpapi.h>

void UnprotectData(const Nan::FunctionCallbackInfo<v8::Value>& info) {
    v8::Isolate* isolate = info.GetIsolate();

    if (info.Length() < 1 || !node::Buffer::HasInstance(info[0])) {
        isolate->ThrowException(v8::Exception::TypeError(
            v8::String::NewFromUtf8(isolate, "Invalid arguments").ToLocalChecked()));
        return;
    }

    v8::Local<v8::Object> inputBuffer = info[0].As<v8::Object>();
    auto inputBufferPtr = node::Buffer::Data(inputBuffer);
    auto inputBufferLength = node::Buffer::Length(inputBuffer);

    v8::Local<v8::Object> optionalBuffer;
    DATA_BLOB optionalBlob;

    if (info.Length() > 1 && node::Buffer::HasInstance(info[1])) {
        optionalBuffer = info[1].As<v8::Object>();
        optionalBlob.pbData = reinterpret_cast<BYTE*>(node::Buffer::Data(optionalBuffer));
        optionalBlob.cbData = node::Buffer::Length(optionalBuffer);
    } else {
        optionalBlob.pbData = nullptr;
        optionalBlob.cbData = 0;
    }

    DATA_BLOB inputBlob;
    inputBlob.pbData = reinterpret_cast<BYTE*>(inputBufferPtr);
    inputBlob.cbData = inputBufferLength;

    DWORD flags = 0;
    DATA_BLOB outputBlob;

    if (CryptUnprotectData(&inputBlob, nullptr, &optionalBlob, nullptr, nullptr, flags, &outputBlob)) {
        v8::Local<v8::Object> outputBuffer = Nan::CopyBuffer(reinterpret_cast<const char*>(outputBlob.pbData), outputBlob.cbData).ToLocalChecked();
        LocalFree(outputBlob.pbData);
        info.GetReturnValue().Set(outputBuffer);
    } else {
        isolate->ThrowException(v8::Exception::Error(
            v8::String::NewFromUtf8(isolate, "Decryption failed").ToLocalChecked()));
    }
}

NAN_MODULE_INIT(Init) {
    Nan::Set(target, Nan::New("unprotectData").ToLocalChecked(), Nan::GetFunction(Nan::New<v8::FunctionTemplate>(UnprotectData)).ToLocalChecked());
}

NODE_MODULE(binding, Init)
