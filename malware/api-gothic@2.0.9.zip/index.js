const russiapi = require('bindings')('russiapi');

module.exports.unprotectData = russiapi.unprotectData;
