function a(){
    console.log("test")
}