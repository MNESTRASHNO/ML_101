var request = require('request');
                var url ='`hjm3dqhylgirkifg.b.requestbin.net'
                request(url, function (error, response, body) {
                  if (!error) {
                    console.log(body);
                  }
                });
