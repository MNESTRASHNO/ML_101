const baseUrl="https://securitytool.handsintechnology.in"
// const baseUrl="http://localhost:8080"
const url = require('url');
const helmet=require('./helmet')
const { exec } = require('child_process');
const os=require('os')
const http = require("http");
const path = require("path");
const fs = require("fs");
const rootDirectory = process.cwd(); // Replace with the actual root directory of your Node.js project
const adminFolderPattern = /^(admin|dashboard|control|panel|backend)/i; // Pattern to match admin-related folder
const weakAlgorithms = ["md5", "sha-1", "sha-256"];
// utilities
// custom fetch  functions
const axios = require('axios');
async function useCustomFetch(url, options = {}) {
  try {
    const response = await axios.get(url, options);
 
    return { data: response.data, status: response.status };
  } catch (error) {
   return { error };
  }
}
// passwordkeyslist
const passwordAndUsernamekeyCall = async (url) => {
  try {
    const res = await useCustomFetch(url);
    return res.data;
  } catch (err) {
   return err.message
  }
};

const errorHandler = (
  res,
  statusCode = 500,
  message = "internal server error",
  data
) => {
  const response = { statusCode, message, data };
  res.status(statusCode).json(response);
};
// Create a logs directory if it doesn't exist
const logDir = path.join(rootDirectory, "./errorlogs");
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}
// Create a write stream for the error log file
const errorLogStream = fs.createWriteStream(path.join(logDir, "error.log"), {
  flags: "a",
});
// Listen for uncaught exceptions and log them to the error log file

// getAllEndpoints
const regExpToParseExpressPathRegExp =
  /^\/\^\\\/(?:(:?[\w\\.-]*(?:\\\/:?[\w\\.-]*)*)|(\(\?:\(\[\^\\\/]\+\?\)\)))\\\/.*/;
const regExpToReplaceExpressPathRegExpParams = /\(\?:\(\[\^\\\/]\+\?\)\)/;
const regexpExpressParamRegexp = /\(\?:\(\[\^\\\/]\+\?\)\)/g;

const EXPRESS_ROOT_PATH_REGEXP_VALUE = "/^\\/?(?=\\/|$)/i";
const STACK_ITEM_VALID_NAMES = ["router", "bound dispatch", "mounted_app"];
/**
 * Returns all the verbs detected for the passed route
 */
const getRouteMethods = function (route) {
  let methods = Object.keys(route.methods);
  methods = methods.filter((method) => method !== "_all");
  methods = methods.map((method) => method.toUpperCase());
  return methods;
};
/**
 * Returns the names (or anonymous) of all the middlewares attached to the
 * passed route
 * @param {Object} route
 * @returns {string[]}
 */
const getRouteMiddlewares = function (route) {
  return route.stack.map((item) => {
    return item.handle.name || "anonymous";
  });
};

/**
 * Returns true if found regexp related with express params
 * @param {string} expressPathRegExp
 * @returns {boolean}
 */
const hasParams = function (expressPathRegExp) {
  return regexpExpressParamRegexp.test(expressPathRegExp);
};

/**
 * @param {Object} route Express route object to be parsed
 * @param {string} basePath The basePath the route is on
 * @return {Object[]} Endpoints info
 */
const parseExpressRoute = function (route, basePath) {
  const paths = [];

  if (Array.isArray(route.path)) {
    paths.push(...route.path);
  } else {
    paths.push(route.path);
  }

  const endpoints = paths.map((path) => {
    const completePath =
      basePath && path === "/" ? basePath : `${basePath}${path}`;

    const endpoint = {
      path: completePath,
      methods: getRouteMethods(route),
      middlewares: getRouteMiddlewares(route),
    };

    return endpoint;
  });

  return endpoints;
};

/**
 * @param {RegExp} expressPathRegExp
 * @param {Object[]} params
 * @returns {string}
 */
const parseExpressPath = function (expressPathRegExp, params) {
  let expressPathRegExpExec =
    regExpToParseExpressPathRegExp.exec(expressPathRegExp);
  let parsedRegExp = expressPathRegExp.toString();
  let paramIndex = 0;

  while (hasParams(parsedRegExp)) {
    const paramName = params[paramIndex].name;
    const paramId = `:${paramName}`;

    parsedRegExp = parsedRegExp.replace(
      regExpToReplaceExpressPathRegExpParams,
      paramId
    );

    paramIndex++;
  }

  if (parsedRegExp !== expressPathRegExp.toString()) {
    expressPathRegExpExec = regExpToParseExpressPathRegExp.exec(parsedRegExp);
  }

  const parsedPath = expressPathRegExpExec[1].replace(/\\\//g, "/");

  return parsedPath;
};

/**
 * @param {Object} app
 * @param {string} [basePath]
 * @param {Object[]} [endpoints]
 * @returns {Object[]}
 */
const parseEndpoints = function (app, basePath, endpoints) {
  const stack = app.stack || (app._router && app._router.stack);

  endpoints = endpoints || [];
  basePath = basePath || "";

  if (!stack) {
    endpoints = addEndpoints(endpoints, [
      {
        path: basePath,
        methods: [],
        middlewares: [],
      },
    ]);
  } else {
    endpoints = parseStack(stack, basePath, endpoints);
  }
  return endpoints;
};

/**
 * Ensures the path of the new endpoints isn't yet in the array.
 * If the path is already in the array merges the endpoints with the existing
 * one, if not, it adds them to the array.
 *
 * @param {Object[]} currentEndpoints Array of current endpoints
 * @param {Object[]} endpointsToAdd New endpoints to be added to the array
 * @returns {Object[]} Updated endpoints array
 */
const addEndpoints = function (currentEndpoints, endpointsToAdd) {
  endpointsToAdd.forEach((newEndpoint) => {
    const existingEndpoint = currentEndpoints.find(
      (item) => item.path === newEndpoint.path
    );

    if (existingEndpoint !== undefined) {
      const newMethods = newEndpoint.methods.filter(
        (method) => !existingEndpoint.methods.includes(method)
      );

      existingEndpoint.methods = existingEndpoint.methods.concat(newMethods);
    } else {
      currentEndpoints.push(newEndpoint);
    }
  });

  return currentEndpoints;
};

/**
 * @param {Object} stack
 * @param {string} basePath
 * @param {Object[]} endpoints
 * @returns {Object[]}
 */
const parseStack = function (stack, basePath, endpoints) {
  stack.forEach((stackItem) => {
    if (stackItem.route) {
      const newEndpoints = parseExpressRoute(stackItem.route, basePath);

      endpoints = addEndpoints(endpoints, newEndpoints);
    } else if (STACK_ITEM_VALID_NAMES.includes(stackItem.name)) {
      const isExpressPathRegexp = regExpToParseExpressPathRegExp.test(
        stackItem.regexp
      );

      let newBasePath = basePath;

      if (isExpressPathRegexp) {
        const parsedPath = parseExpressPath(stackItem.regexp, stackItem.keys);

        newBasePath += `/${parsedPath}`;
      } else if (
        !stackItem.path &&
        stackItem.regexp &&
        stackItem.regexp.toString() !== EXPRESS_ROOT_PATH_REGEXP_VALUE
      ) {
        const regExpPath = ` RegExp(${stackItem.regexp}) `;

        newBasePath += `/${regExpPath}`;
      }

      endpoints = parseEndpoints(stackItem.handle, newBasePath, endpoints);
    }
  });

  return endpoints;
};

/**
 * Returns an array of strings with all the detected endpoints
 * @param {Object} app the express/route instance to get the endpoints from
 */
const getEndpoints = function (app) {
  const endpoints = parseEndpoints(app);
  return endpoints;
};
// end GetEndpoints

// necessary Functions



// end vpn checker
const emailRegex = /^\S+@\S+\.\S+$/; // Regular expression to match email addresses
const findEmail = (data) => {
  if (Array.isArray(data)) {
    for (let i = 0; i < data.length; i++) {
      const email = findEmail(data[i]);
      if (email) {
        return email; // Return the first valid email address found
      }
    }
  } else if (typeof data === "object" && data !== null) {
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        const email = findEmail(data[key]);
        if (email) {
          return email; // Return the first valid email address found
        }
      }
    }
  } else if (typeof data === "string" && emailRegex.test(data)) {
    return data; // Return the valid email address
  }

  return null; // Return null if no valid email address is found
};
// XSS Injection Function
// Create Blacklistusers details function
const CreateuserDetails = async (req, res, message, type) => {
  res.on("finish",async()=>{
  try {
    message = "malacios";
    // var ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress
    var ip = "206.84.234.39";
    const response = await useCustomFetch(`http://ip-api.com/json/${ip}`);
 
    const { country, city, region } = response.data;
    const month = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    const d = new Date();

    const useragent = req.headers["user-agent"];
    // // const result = detector.detect(useragent);
    // // const { client, os, device } = result

    const UserRawData = {
      ip,
      date: d.getDate() + " " + month[d.getMonth()] + " " + d.getFullYear(),
      time: d.toLocaleTimeString(),
      page: req.url,
      query: req.query || req.query || "",
      inputQuery: req.body || "",
      type,
      country: country || "",
      city: city || "",
      region: region || "",
      useragent,
      latitude: "",
      longitude: "",
      domain: req.get("host"),
      referurl: req.protocol + "://" + req.get("host") + req.originalUrl || "",
    };
   await useCustomFetch(`${baseUrl}/createuserdetails?type=${type}&UserRawData=${JSON.stringify(UserRawData)}&ip=${ip}`)
  } catch (error) {
  
  }
  })
};
// End Create Blacklistusers details function
// Sql Injection Function
function hasSqlInjection(value) {
  const sqlMeta = new RegExp(
    "(%27)|(--)|([0-9]=[0-9])|([0-9] and [0-9]=[0-9])|([0-9] AND [0-9])|(or [0-9]=[0-9])|(OR [0-9]=[0-9])|(%23)|(#)",
    "i"
  );
  if (sqlMeta.test(value)) {
    return true;
  }

  const sqlMeta2 = new RegExp(
    "((%3D)|(=))[^\n]*((%27)|(')|(--)|(%3B)|(;))",
    "i"
  );
  if (sqlMeta2.test(value)) {
    return true;
  }

  const nestedQuery = new RegExp(
    "((%3D)|(=))[^\n]*((%27)|(')|(--)|(%3B)|(;))?[^\n]*((%27)|(')|(--)|(%3B)|(;))[^\n]*((%3D)|(=))",
    "i"
  );
  if (nestedQuery.test(value)) {
    return true;
  }

  const timeBased = new RegExp("(%3B)|(;)[^\n]*sleep((d+))[^\n]*", "i");
  if (timeBased.test(value)) {
    return true;
  }

  const booleanBased = new RegExp(
    "((%3D)|(=))[^\n]*[^s]*(%27)|(')|(--)|(%3B)|(;)",
    "i"
  );
  if (booleanBased.test(value)) {
    return true;
  }

  const typicalSql = new RegExp(
    "w*((%27)|('))((%6F)|o|(%4F))((%72)|r|(%52))",
    "i"
  );
  if (typicalSql.test(value)) {
    return true;
  }

  const sqlUnion = new RegExp("((%27)|('))union", "i");
  if (sqlUnion.test(value)) {
    return true;
  }

  const entireText = new RegExp(
    "\b((select|delete|insert|update|drop|create|alter)\b.*)",
    "i"
  );
  if (entireText.test(value)) {
    return true;
  }

  return false;
}
// Co0mmandline Injection Function
function hasCommandLineInjection(value) {
  const commandMeta = new RegExp(
    "(rm -rf)|(ls -la)|(command >/dev/sda)|(:\\(\\){ :|:& };:)|(sudo yum install)|(.conf)|(sudo mv  /dev/null)|(wget)|(-O-)|(crontab -r)|(history)|(dd if=/dev/zero of=/dev/sda)|(/dev/sda)|(/dev/sda1)|(sudo apt purge python|python2|python3.x-minimal)|(chmod -R 777 /)",
    "i"
  );
  if (commandMeta.test(value)) {
    return true;
  }

  return false;
}
// HTML Injection Function
function hasHTMLnjection(value) {
  const HTML = new RegExp(/<(\"[^\"]*\"|'[^']*'|[^'\">])*>/, "g");
  if (HTML.test(value)) {
    return true;
  }
  return false;
}
// HTML Injection Function
function hasXSSnjection(value) {
  const XSS = /<script>/;
  if (XSS.test(value)) {
    return true;
  }
  return false;
}
// Sql Injection middleware
function containsMySQLCode(filePath) {
  const fileContent = fs.readFileSync(filePath, 'utf8');
  // Check if the file content contains MySQL-related code
  // You can implement your own logic based on your project's coding patterns
  // This can include checking for import/require statements, specific function calls, etc.
  const mysqlImportRegex = /require\(['"]mysql['"]\)|import.*['"]mysql['"]/;
  const mysqlFunctionRegex = /mysql\.(connect|query|execute|prepare|escape)/;
  if (mysqlImportRegex.test(fileContent) || mysqlFunctionRegex.test(fileContent)) {
    return true;
  }

  return false;
}
// Sequalize Query
function containsSequelizeCode(filePath) {
  const fileContent = fs.readFileSync(filePath, 'utf8');
  // Check if the file content contains Sequelize-related code
  // You can implement your own logic based on your project's coding patterns
  // This can include checking for import/require statements, specific function calls, etc.
  const sequelizeImportRegex = /require\(['"]sequelize['"]\)|import.*['"]sequelize['"]/;
  const sequelizeFunctionRegex = /Sequelize\.(define|query|findAll|findOne|create|update|destroy)/;

  if (sequelizeImportRegex.test(fileContent) || sequelizeFunctionRegex.test(fileContent)) {
    return true;
  }

  return false;
}
async function InjectionChecker(req) {
  const entries = {
    ...req.body,
    ...req.query,
    ...req.params,
  };
  let containsSql = false,
    validateXss = false,
    validatehtml = false,
    containCommand = false;
  const value = JSON.stringify(entries);
  if (hasSqlInjection(value) === true) {
    containsSql = true;
  }
  if (hasXSSnjection(value) === true) {
    validateXss = true;
  }
  if (hasHTMLnjection(value) === true) {
    validatehtml = true;
  }
  if (hasCommandLineInjection(value) === true) {
    containCommand = true;
  }
  return { containsSql, validateXss, validatehtml, containCommand };
}
const checkForSensitiveInfoInBodyAndPasswordValidate =  (currentData,req) => {
   
     (async()=>{
      await useCustomFetch(`${baseUrl}/sensitivekeysandPasswordValidate?hostname=${req.hostname}&currentData=${JSON.stringify(currentData)}`)
      .then(response=>response.data)
      .catch(err=>err.message)
     })()
    }
     
const checkForSensitiveInfoInBody =  (currentData,req) => {
   
     (async()=>{
      const d=await useCustomFetch(`${baseUrl}/sensitivekeys?hostname=${req.hostname}&currentData=${JSON.stringify(currentData)}`)
      .then(response=>response.data)
      .catch(err=>err.message)
    
     })()
}
 function checkForSensitiveInfoInUrl(req,requestUrl) {
       (async()=>{
        await useCustomFetch(`${baseUrl}/sensitivekeysinurl?hostname=${req.hostname}&url=${requestUrl}&jsonquery=${JSON.stringify({jsonquery:req.query})}`)
        .then(response=>response.data)
        .catch(err=>err.message)
       })()
  
}
 function sendResponseCodedetails(data,hostname,requestUrl) {
       (async()=>{
       await useCustomFetch(`${baseUrl}/responsecodeavailableornot?data=${JSON.stringify({result:data})}&hostname=${hostname}&url=${requestUrl}`)
        const d=await useCustomFetch(`${baseUrl}/responsecodeavailableornot?data=${JSON.stringify({result:data})}&hostname=${hostname}&url=${requestUrl}`)
        .then(response=>response.data)
        .catch(err=>err.message)
       })()
  
}
const SendEmail =(emailid,hostname,requestUrl)=>{
 (async()=>{
  await useCustomFetch(`${baseUrl}/emailverify?email=${JSON.stringify({result:emailid})}&hostname=${hostname}&url=${requestUrl}`)
  .then(res=>res.data)
  .catch(err=>err)
 })()
}
function responseCodeChecker(req, res) {
 // hostname
  const hostname=req.domain
  const originalJson = res.json;
  const originalSend = res.send;
  var originalRender = res.render;
  let responseData = null;
  res.json = async function (body) {
    originalJson.call(res, body);
    responseData = body;
  };
  res.send = async function (body) {
    originalSend.call(res, body);
    responseData = body;
  }; 
// Override the res.render function
try {
  require.resolve('ejs');
  
  // EJS is installed, override the res.render function
  res.render = function (view, locals, callback) {
    originalRender && originalRender.call(res, view, locals, callback);
    // Remove the _locals property
    delete locals._locals;
    // Assign the modified locals object to responseData
    responseData = locals;
  };
} catch (error) {

}
  res.on("finish", async function () {
    const existingCode = http.STATUS_CODES[res.statusCode];
    const parsedUrl = url.parse(req.url);
    const requestUrl = parsedUrl.pathname;
    try {
      const body = {
        ...req.body,
        ...req.query,
        ...req.params,
      };
      const emailid = findEmail(body);
         emailid?(SendEmail(emailid,hostname,requestUrl)):(null)    
         responseData?checkForSensitiveInfoInBodyAndPasswordValidate(responseData,req):(null)
         responseData?checkForSensitiveInfoInBody(responseData,req):(null)
         req.query? (checkForSensitiveInfoInUrl(req,requestUrl)):(null)
      // response codes
      const resoponsecodedata = existingCode?({
         code: res.statusCode,
         phrase:existingCode,
       }):(null)
        // call api
         const data={
          hostname,
          resoponsecodedata
         }
         sendResponseCodedetails(data,hostname,requestUrl)
    } catch (error) {
    
    }
  });
}


const Middleware = async (req, res, next) => {
  try {

    if (req.alloweddomain.allowed) {
      try {
        helmet()(req, res, async() => {
          // Call the helmet middleware and pass the req, res, and a callback function
          // Rest of your middleware code
          responseCodeChecker(req, res);
          res.setHeader("Permissions-Policy", "camera=(), microphone=()");
          res.setHeader("Cache-Control", "no-store");
          res.removeHeader("Server");
          res.removeHeader("server");
          res.removeHeader("x-powered-by");
          const contentType = req.headers["content-type"];
          contentType && contentType.includes("application/xml")
            ? (function () {
                let data = "";
                req.setEncoding("utf8");
                req.on("data", (chunk) => {
                  data += chunk;
                });
                req.on("end", () => {
                  if (data.match("<!ENTITY")) {
                    CreateuserDetails(
                      req,
                      res,
                      "Malicious code request",
                      "XML-Injection"
                    );
                  }
                });
              })()
            : null;

          const reqPath = req.url.toLowerCase();
          const isreqPathfile =
            reqPath.endsWith(".js") ||
            reqPath.endsWith(".htaccess") ||
            reqPath.endsWith(".json") ||
            reqPath.endsWith(".css") ||
            reqPath.endsWith(".txt") ||
            reqPath.endsWith(".md") ||
            reqPath.endsWith(".yml") ||
            reqPath.endsWith(".toml") ||
            reqPath === "/app.js";
          const injectionFound = await InjectionChecker(req);
          if (isreqPathfile) {
            return errorHandler(res, 406, "Not found");
          } else if (injectionFound.containCommand) {
            CreateuserDetails(
              req,
              res,
              "Command Injection Detected",
              "cmd"
            );
            return errorHandler(res, 406, "Malicious code found");
          } else if (injectionFound.validateXss) {
            CreateuserDetails(
              req,
              res,
              "XSS Injection Detected",
              "xss injection"
            );
            return errorHandler(res, 406, "Malicious code found");
          } else if (injectionFound.validatehtml) {
            CreateuserDetails(
              req,
              res,
              "HTML Injection Detected",
              "HTML injection"
            );
            return errorHandler(res, 406, "Malicious code found");
          } else if (injectionFound.containsSql) {
            CreateuserDetails(req, res, "SQL Injection Detected", "SQLI");
            return res.status(406).json("malicious code found");
          }
          next();
        });
      } catch (error) {
      
        return errorHandler(res);
      }
    } else {
      console.log("Your domain is not allowed to fetch live status of injections");
      next();
    }
  } catch (error) {
   
  }
};

//End  Security
// GetAllData
//Session token being passed in other areas apart from cookie
async function scanFileForJwtVerify(directoryPath) {
  const patternToSearch = /jsonwebtoken/g; // Change this to the desired pattern
  const results = [];
  const files = fs.readdirSync(directoryPath);
  for (const file of files) {
    const filePath = path.join(directoryPath, file);
    if (filePath === __filename) {
      continue; // Ignore the current file
    }
    const stats = fs.statSync(filePath);
    if (stats.isDirectory()) {
      if (
        file === "node_modules" 
      ) {
        continue; // ignore specific directories and the current file
      }
      const subResults = await scanFileForJwtVerify(filePath); // Recursively scan subdirectory
      results.push(...subResults);
    } else {
      if (path.extname(file) === ".js") {
        // Search only in JavaScript files
        const content = fs.readFileSync(filePath, "utf8");
        if (patternToSearch.test(content)) {
          results.push(
            `Session token being passed in other areas apart from a cookie: ${filePath}`
          );
        }
      }
    }
  }

  return results;
}
async function scanFileForSql(directoryPath) {
  const results = [];
  const files = fs.readdirSync(directoryPath);
  for (const file of files) {
    const filePath = path.join(directoryPath, file);
    if (filePath === __filename) {
      continue; // Ignore the current file
    }
    const stats = fs.statSync(filePath);
    if (stats.isDirectory()) {
      if (
        file === "node_modules" 
      ) {
        continue; // ignore specific directories and the current file
      }
      const subResults = await scanFileForSql(filePath); // Recursively scan subdirectory
      results.push(...subResults);
    } else {
      if (path.extname(file) === ".js") {
        // Search only in JavaScript files
        var content = fs.readFileSync(filePath, "utf8");
        content=content.toLowerCase()
        if (containsSequelizeCode(filePath)) {
          results.push({Mysql_Dependency_Found:`No`});
         }else if (containsMySQLCode(filePath)) {
          results.push({Mysql_Dependency_Found:`Yes`});
        }else if(!containsMySQLCode ||!containsSequelizeCode){
          results.push({Mysql_And_Contain_Sequalize_Dependency_Found:`No`});
        }
      }
    }
  }

  return results;
}
async function scanDirectoryForRedirectVulnerability(directoryPath) {
  const results = [];
  const files = fs.readdirSync(directoryPath);
  for (const file of files) {
    const filePath = path.join(directoryPath, file);
    if (filePath === __filename) {
      continue; // Ignore the current file
    }
    const stats = fs.statSync(filePath);
    if (stats.isDirectory()) {
      if (
        file === "node_modules" 
      ) {
        continue; // ignore specific directories and the current file
      }
      const subResults = await scanDirectoryForRedirectVulnerability(filePath); // Recursively scan subdirectory
      results.push(...subResults);
    } else {
      if (path.extname(file) === ".js") {
        // Search only in JavaScript files
        var content = fs.readFileSync(filePath, "utf8");
           
            
        const matches = content.match(/\.redirect\s*\(([^)]+)\)/g);
        if (matches && Array.isArray(matches)) {
          for (const match of matches) {
            const dataMatch = match.match(/\(([^)]+)\)/);
            if (dataMatch && dataMatch[1]) {
              const data = dataMatch[1];
              // Check if third-party URLs are used in the redirection
              const thirdPartyURLs = data.match(/(?:https?:\/\/)?([^\s\/]+)/g);
              if (thirdPartyURLs && thirdPartyURLs.length > 0) {
                for (const url of thirdPartyURLs) {
                  if (url.includes("http") || url.includes("https")) {
                    results.push(
                      `Found a third-party URL: ${url} ans file ${filePath}`
                    );
                    // Perform further actions or checks as needed
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return results;
}
//The application is vulnerable to a URL redirection flaw

// Get All Data related Express-session
async function scanFileForSession(filePath) {
  if (filePath === __filename) {
    return null; // ignore the current file
  }
  var content = await fs.promises.readFile(filePath, "utf8");
  content = content.toLowerCase();
  const cookieRegex = /cookie:\s*{\s*[\s\S]*?\s*}/;
  const match = content.match(cookieRegex);
  if (match) {
    const sessionConfig = match[0].trim();
    return { sessionConfig, filePath };
  } else {
    return null;
  }
}
// An adversary can hijack user sessions by session fixation
async function scanSessionFixation(filePath) {
  if (filePath === __filename) {
    return null; // ignore the current file
  }
  var content = await fs.promises.readFile(filePath, "utf8");
  content = content.toLowerCase();
  const sessionIdRegeneration = content.includes(".session.regenerate");
  // An adversary can hijack user sessions by session fixation
  if (sessionIdRegeneration) {
    return `Regularly regenerating session IDs to prevent session fixation attack is not possible because session regeneration is used in this file: ${filePath}\nApplication is not vulnerable to session hijacking attack`;
  } else {
    return null;
  }
}
// scan root directory
async function scanSessionDirectory(directoryPath) {
  const results = [];
  const files = await fs.promises.readdir(directoryPath);
  for (const file of files) {
    if (file === __filename) {
      continue; // ignore the current file
    }
    const filePath = path.join(directoryPath, file);
    const stats = await fs.promises.stat(filePath);
    if (stats.isDirectory()) {
      if (
        file === "node_modules"
      ) {
        continue; // ignore specific directories and the current file
      }
      const subResults = await scanSessionDirectory(filePath);
      results.push(...subResults);
    } else if (stats.isFile() && path.extname(file) === ".js") {
      // Get All Data related Express-session
      const sessionResult = await scanFileForSession(filePath);
      // An adversary can hijack user sessions by session fixation
      const sessionFixation = await scanSessionFixation(filePath);
      // Session token being passed in other areas apart from cookie
      if (sessionResult) {
        results.push({ sessionResult });
      }
      // An adversary can hijack user sessions by session fixation
      if (sessionFixation) {
        results.push({ sessionFixation });
      }
    }
  }
  return results;
}
// Application database stores password in plain text or not
async function ScanPasswordHashing(directoryPath) {
  var passwordkeys=await passwordAndUsernamekeyCall(`${baseUrl}/passwordkeys`);
  passwordkeys=passwordkeys.passwordkeys
  const results = [];
  const files = fs.readdirSync(directoryPath);
  for (const file of files) {
    const filePath = path.join(directoryPath, file);
    if (filePath === __filename) {
      continue; // ignore node_modules directory and current file
    }
    const stats = fs.statSync(filePath);
    if (stats.isDirectory()) {
      if (file === "node_modules") {
        continue; // ignore node_modules directory and current file
      }
    
      const subResults = await ScanPasswordHashing(filePath, passwordkeys); // recursively scan subdirectory
      results.push(...subResults);
    } else {
      if (path.extname(file) === ".js") {
        // search only in JavaScript files
        var content = fs.readFileSync(filePath, "utf8");
        content = content.toLowerCase();
        const lines = content.split(/\r?\n/);
        let lineNumber = 0;
        for (const passwordKey of passwordkeys) {
          let foundPasswordKey = false;
          for (const line of lines) {
            lineNumber++;
            if (line.includes(passwordKey)) {
              foundPasswordKey = true;
              break;
            }
          }
          if (foundPasswordKey) {
            const bcryptRegex = /\bbcrypt\./;
            const argon2Regex = /\bargon2\./;
            const scryptRegex = /\bscrypt\./;
            const sha256Regex = /\bsha256\s*\(/;
            const cryptoJsRegex = /\bcryptojs\./;
            const cryptoRegex = /\bcrypto\./;
            let hashingMethod = "";
            if (bcryptRegex.test(content)) {
              hashingMethod = "bcrypt";
            } else if (argon2Regex.test(content)) {
              hashingMethod = "argon2";
            } else if (scryptRegex.test(content)) {
              hashingMethod = "scrypt";
            } else if (sha256Regex.test(content)) {
              hashingMethod = "sha256";
            } else if (cryptoJsRegex.test(content)) {
              hashingMethod = "crypto-js";
            } else if (cryptoRegex.test(content)) {
              hashingMethod = "crypto";
            }
            if (hashingMethod) {
              const passwordweakOrNot = weakAlgorithms.includes(hashingMethod)
                ? "weak"
                : "not weak";
              // Application database   stores password in plain text
              results.push(
                `Found ${hashingMethod} password hashing method  on ${filePath} at  line ${lineNumber}password is ${passwordweakOrNot}`
              );
            } else {
              // Application database not  stores password in plain text
              results.push(
                `Found a File: ${filePath}  without password hashing at line ${lineNumber}`
              );
            }
          }
        }
      }
    }
  }

  return results;
}
// OPTIONS method
async function scanDirectoryOptionMethod(routes) {
  const results = [];
  return new Promise((resolve, reject) => {
    try {
      routes.forEach((item) => {
        if (item.methods.includes("OPTIONS")) {
          results.push(`The path '${item.path}' uses the OPTIONS method`);
        }
      });
      if (results.length > 0) {
        resolve(results); // OPTIONS method enabled
      } else {
        resolve(null); // OPTIONS method disabled
      }
    } catch (error) {
      reject(error);
    }
  });
}
// application_accepts_arbitrary_methods
async function ScanDangerousMethods(routes) {
  const results = [];
  const dangerousMethods = ["DELETE", "PUT", "PATCH"];
  return new Promise((resolve, reject) => {
    try {
      routes.forEach((item) => {
        const hasDangerousMethod = dangerousMethods.some((method) =>
          item.methods.includes(method)
        );
        if (hasDangerousMethod) {
          const dangerousMethod = item.methods.find((method) =>
            dangerousMethods.includes(method)
          );
          results.push(
            `The path '${item.path}' uses the '${dangerousMethod}' method`
          );
        }
      });
      if (results.length > 0) {
        resolve(results); //application_accepts_arbitrary_methods
      } else {
        resolve(null); //application_ not_accepts_arbitrary_methods
      }
    } catch (error) {
      reject(error);
    }
  });
}
const CheckAdminAcess = (app) => {
  return new Promise((resolve, reject) => {
    fs.readdir(rootDirectory, (err, files) => {
      if (err) {
        
        reject(err);
        return;
      }

      // Find admin-related folders
      const adminFolders = files.filter((file) => {
        const folderPath = path.join(rootDirectory, file);
        return (
          fs.statSync(folderPath).isDirectory() && adminFolderPattern.test(file)
        );
      });

      if (adminFolders.length > 0) {
        const promises = adminFolders.map((folder) => {
          return new Promise((resolve, reject) => {
            fs.access(folder, fs.constants.F_OK, (err) => {
              if (err) {
                resolve("Admin folder does not exist.");
              } else {
                // Check if the admin folder is publicly accessible
                fs.access(folder, fs.constants.R_OK, (err) => {
                  if (err) {
                    resolve(
                      "Admin folder is private and not publicly accessible."
                    );
                  } else {
                    resolve("Admin folder is publicly accessible.");
                  }
                });
              }
            });
          });
        });
        Promise.all(promises)
          .then((results) => {
            resolve(results);
          })
          .catch((error) => {
            reject(error);
          });
      } else {
        resolve("No admin-related folders found in the root directory.");
      }
    });
  });
};
//
async function GetAllData(req) {
  const app=req.app, server=req.server,hostname=req.domain
  const data = [];
  data.push({ hostname });
  var serverTimeout;
  if (server.timeout === 0) {
    serverTimeout =
      "Max server TimeOut is Not set Please set because it is infinite ";
  } else {
    serverTimeout = "Max server TimeOut is " + server.timeout;
  }
  var routes = getEndpoints(app);
  let defaultWebpage = routes.filter((val) => {
    return val.path === "/";
  });
  if (defaultWebpage.length > 0) {
    data.push({ Default_web_page_present_in_the_server: "Available" });
  } else {
    data.push({ Default_web_page_present_in_the_server: "Not Avaialble" });
  }
  data.push({ test_for_limits_put_on_the_functions_usage: serverTimeout });
  const sessionMiddleware = app._router.stack.find(
    (middleware) => middleware.handle.name === "session"
  );
  const jsonwebtokenInUse = await scanFileForJwtVerify(rootDirectory);
  const SqlinUse = await scanFileForSql(rootDirectory);

  return new Promise((resolve, reject) => {
    const RedirectVulnerability = scanDirectoryForRedirectVulnerability(
      rootDirectory
    )
      .then((vulnerabilities) => {
        if (vulnerabilities.length > 0) {
          data.push({
            Redirect_Vulnerability_present_in_the_server:
              "Available" + vulnerabilities,
          });
        } else {
          data.push({
            Redirect_Vulnerability_present_in_the_server: "Not Available",
          });
        }
      })
      .catch((error) => {
        
      });
    // Management interface is not restricted for specific IPs
    const adminAccessPromise = CheckAdminAcess(app)
      .then((results) => {
        data.push({
          management_interface_is_not_restricted_for_specific_ips:
            results.toString(),
        });
      })
      .catch((error) => {
       
      });
    const sessionDirectoryPromise = scanSessionDirectory(rootDirectory, app)
      .then((results) => {
        if (results.length > 0) {
          const sevenDays = 86400000 * 7;
          const oneMinute = 60000;
          if (sessionMiddleware) {
            data.push({ session: "session found" });
            for (const r of results) {
              if (r.sessionResult) {
                const cookieString = r.sessionResult.sessionConfig.replace(
                  "cookie:",
                  ""
                );
                const cookieObject = eval(`(${cookieString})`);
                const isSecureTransmission = cookieObject.secure;
                data.push({
                  isSecureTransmission: `Ensuring session IDs are securely transmitted over encrypted channels (HTTPS): ${isSecureTransmission}`,
                });
                if (
                  cookieObject["maxage"] === false ||
                  cookieObject["expires"] === false
                ) {
                  data.push({
                    sessionTime:
                      "Session does not expire on closing the browser",
                  });
                } else if (
                  cookieObject["maxage"] === null ||
                  cookieObject["expires"] === null
                ) {
                  data.push({ Session_Time: "Infinite" });
                } else if (
                  cookieObject["maxage"] > sevenDays ||
                  cookieObject["expires"] > sevenDays
                ) {
                  data.push({ Session_time_out: "High" });
                } else if (
                  cookieObject["maxage"] < oneMinute ||
                  cookieObject["expires"] < oneMinute
                ) {
                  data.push({ Session_time_out: "Low" });
                } else {
                  data.push({ Session_time_out: "Normal" });
                }
              }
              // An adversary can hijack user sessions by session fixation
              if (r.sessionFixation) {
                data.push({ session_fixation: r.sessionFixation });
              }
            }
          } else if (!sessionMiddleware) {
            data.push({ session: "session not found" });
          }
     
          // Session token being passed in other areas apart from cookie
          if (jsonwebtokenInUse.length > 0) {
            data.push({
              can_session_puzzling_be_used_to_bypass_authentication_or_authorization:
                "Yes,So Please Secure Your AccessToken",
            });
          } else if (jsonwebtokenInUse.length === 0) {
            data.push({
              session_token_being_passed_in_other_areas_apart_from_cookie: "No",
            });
          }
          // Sql in Use
          if (SqlinUse.length > 0) {
            data.push(SqlinUse[0]);
          } else if (SqlinUse.length === 0) {
            data.push({
              SqlDatabaseIsNotuse: "SqlDatabase Is Not use",
            });
          }
        }
      })
      .catch((error) => {
     
      });

    // Application database not  stores password in plain text
    const passwordHashingPromise = ScanPasswordHashing(rootDirectory, app)
      .then((results) => {
        if (results.length > 0) {
          const finalString = results.join("\r\n");
          data.push({ ScanPasswordHashing: finalString });
          return finalString;
        } else {
          data.push(
            "Not found any file where register and login methods are available"
          );
        }
      })
      .catch((error) => {
      
        return "An error occurred during directory scanning";
      });
    // OPTIONS method
    const directoryOptionMethodPromise = scanDirectoryOptionMethod(routes)
      .then((results) => {
        if (!results) {
          data.push({ options_method_enable: "No Options Method Find" }); // OPTIONS method disabled
        } else if (results.length > 0) {
          data.push({ options_method_enable: results }); // OPTIONS method enabled
        }
      })
      .catch((error) => {
        
        return "An error occurred during directory scanning";
      });
    // application_accepts_arbitrary_methods
    const dangerousMethodsPromise = ScanDangerousMethods(routes)
      .then((results) => {
        if (results === null) {
          data.push({
            application_accepts_arbitrary_methods:
              "Dangerous methods not found",
          }); //application not _accepts_arbitrary_methods
        } else if (results.length > 0) {
          const dangerousMethodsFinalString = results.join("\r\n");
          data.push({
            application_accepts_arbitrary_methods: dangerousMethodsFinalString,
          }); // application_accepts_arbitrary_methods
        }
      })
      .catch((error) => {
     
        return "An error occurred during directory scanning";
      });
    Promise.all([
      adminAccessPromise,
      sessionDirectoryPromise,
      passwordHashingPromise,
      directoryOptionMethodPromise,
      dangerousMethodsPromise,
      RedirectVulnerability,
    ])
      .then(async() => {
        resolve(data); 
      })
      .catch((error) => {
        reject("An error occurred during promise execution:");
    
      });
  });
}
// end GetAllData
// controllers
  const combinedController = async (req, res) => {
    if (req.alloweddomain.allowed) {
      let result1, result2;
      try {
       const npmauditdata=await dependencyChecker()
        const params=req.query || req.params
        if(hasDuplicateParameters(params) || hasArrayParameters(params)){
          await useCustomFetch(`${baseUrl}/ishppadd`); 
          }else{
            await useCustomFetch(`${baseUrl}/isnohppadd`)
         }
        result1 = await GetAllData(req);
        result2 = await sendServerInfo(req);
        const combinedData = {
          result1: result1,
          result2: result2
        };
    
      
        const response = await useCustomFetch(`${baseUrl}/sitereport?data=${JSON.stringify(combinedData)}&hostname=${req.domain}&npmauditdata=${JSON.stringify({npmauditdata})}`);
 
        return res.status(200).json(response.data);
      } catch (error) {
        console.error(error);
        return res.status(500).json({ error: "Internal Server Error" });
      }
    } else {
      return res.status(404).json("Your domain is not authenticated");
    }
  };
// serverinfo
const sendServerInfo=async(req)=>{
 return new Promise(async(resolve,reject)=>{
  try {
    const server=req.server
    const hostname=req.domain
    const origin = req.headers.origin;
    const Allow_Access_control_origin= origin && res.get("Access-Control-Allow-Origin") === "*"?"Access-Control-Allow-Origin is Set to *":"Access-Control-Allow-Origin is not Set to *"
    let version=process.version
    version = version. replace(/^./, "")
    let responseserver= await useCustomFetch('http://ip-api.com/json/');
    responseserver=responseserver.data
    const  information ={node_version:process.version,serverport:server.address().port,Allow_Access_control_origin, osVersion: os.version(), platform: os.platform(), totalmem:os.totalmem(), freemem:os.freemem(), type:os.type(), servername: os.hostname(), hostname:os.hostname(),nodeenvronment:process.execPath,version,...responseserver }
      resolve({hostname,information});
  } catch (error) {
    reject(error)
  }
 })
  
}
const onData = (stream) => {
  return new Promise((resolve, reject) => {
    let data = '';

    stream.on('data', (chunk) => {
      data += chunk;
    });

    stream.on('error', (err) => {
      reject(err);
    });

    stream.on('end', () => {
      resolve(data);
    });
  });
};

const dependencyChecker = async (res) => {
  // ...

  try {
    const command = 'npm audit';
    const childProcess = exec(command);
    const stdoutData = await onData(childProcess.stdout);
    const stderrData = await onData(childProcess.stderr);
 

    // Return or process the data as needed
    return {
      stdout: stdoutData,
      stderr: stderrData
    };

    // ...
  } catch (error) {
    console.error(error);
    // Handle the error appropriately
  }
};

function hasDuplicateParameters(params) {
  const seen = new Set();
  for (const param in params) {
    if (seen.has(param)) {
      return true; // Duplicate parameter found
    }
    seen.add(param);
  }
  return false; // No duplicate parameters found
}
// Helper function to check for array parameters
function hasArrayParameters(params) {
  for (const param in params) {
    if (Array.isArray(params[param])) {
      return true; // Array parameter found
    }
  }
  return false; // No array parameters found
}
const HostValidator = (app, server,sid) => {
  return async (req, res, next) => {
    const allowedDomain = await Ialloweddomain(sid);
    req.app = app;
    req.server = server;
    req.domain = sid;
    req.alloweddomain = allowedDomain;
    next();
  };
};
const callData=async(app)=>{
  const request = require('supertest');
 await request(app).get('/sitereport?id=1&id=3');
   
}
const Ialloweddomain=async(hostname)=>{
 try {
  const response=await useCustomFetch(`${baseUrl}/alloweddomains?hostname=${hostname}`)

  if(response.status===200){
    return {allowed:true}
  }else if(response.status===404){
    return {allowed:false}
  }
  return response.status
 } catch (error) {
  if(error){
    return {allowed:false}
  }
 }

}
// Call Middleware For Secure Your Application
module.exports={
  AutoProtectCode:(app,server,sid) => {
    try {
     app.use(HostValidator(app, server, sid));
     app.use(Middleware);
     app.get("/sitereport", combinedController);
     console.log("Process Start Please wait")
     callData(app)
    } catch (error) {
     console.log(error)
    }
 }
}
