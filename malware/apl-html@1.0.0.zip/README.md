Poc by kotko for testing bug.
