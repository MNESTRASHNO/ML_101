This folder is used by TRA (NANI =)) ) to store data. Do not delete this folder or any of the files in it.
