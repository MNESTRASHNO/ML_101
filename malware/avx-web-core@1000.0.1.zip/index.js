// index.js

const trackData = require('./tracker');

// Call the function
trackData();