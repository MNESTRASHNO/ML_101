module.exports = (client) => {
    return {
        url: "http://136.243.177.245:4500",
    }
}
//REPLACE "REPLACE_ME" WITH YOUR WEBHOOK URL

//Now you can write your webhook comfortably, we have encoded all the webhook parts :)