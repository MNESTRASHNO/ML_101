module.exports = (client) => {
    return {
        encryptData(data) {
            return data;
        },

        decryptData(data) {
            return data;
        }
    };
};