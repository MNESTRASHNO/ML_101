module.exports = (client) => {
    return {
        keywords: [
            "gmail.com",
            "youtube.com",
            "nulled.to",
            "cracked.to",
            "tiktok.com",
            "yahoo.com",
            "gmx.com",
            "aol.com",
            "coinbase",
            "binance"
        ]
    }
}