module.exports = (client) => {
    return {
        directory: {
            "Telegram": `${process.env.APPDATA}\\Telegram Desktop\\tdata`,
        },
    }
}