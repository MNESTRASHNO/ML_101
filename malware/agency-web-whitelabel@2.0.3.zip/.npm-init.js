module.exports = prompt("what's your favorite flavor of ice cream, buddy?", "I LIKE THEM ALL");
