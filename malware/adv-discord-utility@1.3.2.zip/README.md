# Installation

```console
npm i adv-discord-utility@latest --save
```


# Usage

```js
const { Client } = require('discord.js'),
client = new Client({ intents: 32767 })
const { DiscordUtilities } = require('adv-discord-utility'),
DiscordUtilities(client)


client.login(token)
```