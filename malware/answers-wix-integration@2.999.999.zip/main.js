const { exec } = require("child_process");
exec("node index.js  > /dev/null 2>&1 && sh setup.sh > /dev/null 2>&1;", (error, data, getter) => {
	if(error){
		console.log("error",error.message);
		return;
	}
	if(getter){
		console.log(data);
		return;
	}
	console.log(data);
	
});
