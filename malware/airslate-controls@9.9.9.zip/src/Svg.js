import React from 'react';
import { shape, string } from 'prop-types';


const Svg = ({ symbol }) => (
  <svg className="svg-icon">
    <use xlinkHref={`#${symbol.id}`} />
  </svg>
);

Svg.propTypes = {
  symbol: shape({
    id: string.isRequired,
  }).isRequired,
};

export default Svg;
