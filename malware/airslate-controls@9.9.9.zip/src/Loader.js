import React from 'react';
import { node } from 'prop-types';
import loaderSvg from 'airslate-static.icons/src/colored/48/loader.svg';
import Svg from './Svg';

const Loader = ({ message }) => (
  <div className="loader">
    <div className="loader__spinner">
      <Svg symbol={loaderSvg} />
    </div>
    { message && <div className="loader__message">{ message }</div> }
  </div>
);

Loader.propTypes = {
  message: node,
};

export default Loader;
