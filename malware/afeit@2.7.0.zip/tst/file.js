const afeit= require('afeit');
