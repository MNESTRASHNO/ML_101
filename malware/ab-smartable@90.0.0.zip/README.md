This package is meant for security testing purposes and does not contain any useful code
