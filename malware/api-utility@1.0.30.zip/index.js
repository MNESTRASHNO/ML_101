'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var d = require('dayjs');
var dset = require('dset');
var mergeDeep = require('deepmerge');
var dequal = require('dequal');
var flattie = require('flattie');
var lite = require('klona/lite');
var nanoid = require('nanoid');
var log4js = require('log4js');
var yup = require('yup');
var express = require('express');
var bodyParser = require('body-parser');
var parseDomain$1 = require('parse-domain');
var qss = require('qss');

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  var n = Object.create(null);
  if (e) {
    Object.keys(e).forEach(function (k) {
      if (k !== 'default') {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () {
            return e[k];
          }
        });
      }
    });
  }
  n['default'] = e;
  return Object.freeze(n);
}

var d__default = /*#__PURE__*/_interopDefaultLegacy(d);
var mergeDeep__default = /*#__PURE__*/_interopDefaultLegacy(mergeDeep);
var log4js__default = /*#__PURE__*/_interopDefaultLegacy(log4js);
var yup__namespace = /*#__PURE__*/_interopNamespace(yup);
var express__default = /*#__PURE__*/_interopDefaultLegacy(express);
var bodyParser__default = /*#__PURE__*/_interopDefaultLegacy(bodyParser);

const filterArrayUnique = (array) => {
    return [...new Set(array)];
};
const changeArrayPosition = (array, from, to) => {
    const startIndex = from < 0 ? array.length + from : from;
    if (startIndex >= 0 && startIndex < array.length) {
        const endIndex = to < 0 ? array.length + to : to;
        const [item] = array.splice(from, 1);
        array.splice(endIndex, 0, item);
    }
};
const getArrayIntersection = (arr, ...args) => arr.filter((item) => args.every((arr) => arr.includes(item)));
const getArrayDifference = (arr1, arr2) => arr1.filter((e) => !arr2.includes(e));
const shuffleArray = (arr) => {
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
};
const sortArrayByNumber = ({ source, getterFn = (e) => e, asc, }) => {
    return source.sort((a, b) => {
        const aValue = getterFn(a);
        const bValue = getterFn(b);
        return asc ? aValue - bValue : bValue - aValue;
    });
};
const sortArrayByAlphabet = ({ source, getterFn = (e) => e, asc, }) => {
    return source.sort((a, b) => {
        const aValue = getterFn(a);
        const bValue = getterFn(b);
        if (asc) {
            if (aValue < bValue)
                return -1;
            if (aValue > bValue)
                return 1;
        }
        else {
            if (bValue < aValue)
                return -1;
            if (bValue > aValue)
                return 1;
        }
        return 0;
    });
};

const isPlainObject = (value) => {
    if (Object.prototype.toString.call(value) !== '[object Object]')
        return false;
    const prototype = Object.getPrototypeOf(value);
    return prototype === null || prototype === Object.prototype;
};
const isBrowser = () => typeof document !== 'undefined' && typeof window !== 'undefined';
const isDefined = (e) => typeof e !== 'undefined';
const isNotNull = (e) => e !== null;
const isDefinedAndNotNull = (e) => isDefined(e) && isNotNull(e);
const isArray = (e) => Array.isArray(e);
const isArrayAndHasChild = (e) => isArray(e) && e.length;
const isBoolean = (e) => typeof e === 'boolean';
const isString = (e) => typeof e === 'string';
const isNumber = (e) => typeof e === 'number';
const isFunction = (e) => typeof e === 'function';
const isObject = (e) => typeof e === 'object';
const isMac = () => isBrowser() && /Mac|iPod|iPhone|iPad/.test(navigator.platform);

const dayJs = d__default['default'];

function debounce(fn, time = 0) {
    let timeout;
    return function (...arg) {
        const functionCall = function () {
            fn.bind(this)(...arg);
        };
        clearTimeout(timeout);
        timeout = setTimeout(functionCall, time);
    };
}

function dlv(obj, key, def, p, undef) {
	key = key.split ? key.split('.') : key;
	for (p = 0; p < key.length; p++) {
		obj = obj ? obj[key[p]] : undef;
	}
	return obj === undef ? def : obj;
}

const setWithPath = dset.dset;
const getWithPath = (source, path, defaultValue) => {
    return path.includes('.')
        ? dlv(source, path, defaultValue)
        : source[path] || defaultValue;
};
const getWithPathAny = (source, path, defaultValue) => getWithPath(source, path, defaultValue);
const getWithPaths = (source, paths) => {
    const values = [];
    for (let i = 0; i < paths.length; i++) {
        const value = getWithPath(source, paths[i]);
        values.push(value);
    }
    return values;
};

const deleteWithPath = (obj, keys) => {
    const pathArray = keys.split('.');
    pathArray.reduce((acc, key, i) => {
        if (i === pathArray.length - 1)
            delete acc[key];
        return acc[key];
    }, obj);
};
const patchObject = (options) => {
    const { fromValue, toValue, mergeDeep: deep, replace } = options;
    const isFn = isFunction(toValue);
    let nextValue = isFn ? toValue(fromValue) : toValue;
    if (!isFn && nextValue !== null && !replace) {
        nextValue = deep
            ? mergeDeep__default['default'](fromValue, nextValue)
            : { ...fromValue, ...nextValue };
    }
    return nextValue;
};
const iterateObject = (source, cb) => {
    for (const key in source)
        cb(source[key], key);
};
const omitObjectByFields = (fields, srcObject) => {
    const obj = { ...srcObject };
    fields.forEach((fields) => delete obj[fields]);
    return obj;
};
const objectToArray = (obj, _withKey) => {
    const mapFn = _withKey === true
        ? (key) => ({ key: key, value: obj[key] })
        : (key) => obj[key];
    return Object.keys(obj).map((e) => mapFn(e));
};
const compareObjectByKeys = (obj1, obj2, keys) => {
    let match = true;
    for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        if (obj1[key] !== obj2[key]) {
            match = false;
            break;
        }
    }
    return match;
};

const removeOrReplace = (source, key, value) => {
    if (isBoolean(value)) {
        if (value)
            delete source[key];
    }
    else {
        if (isPlainObject(value) && !Object.keys(value).length) {
            delete source[key];
        }
        else if (isArray(value) && !value.length) {
            delete source[key];
        }
    }
};
const omitDeepObject = (source, omitFn) => {
    for (const key in source) {
        let value = source[key];
        if (isPlainObject(value)) {
            source[key] = omitDeepObject(value, omitFn);
            removeOrReplace(source, key, source[key]);
        }
        else if (isArray(value)) {
            source[key] = source[key].map((v) => omitDeepObject(v, omitFn));
            removeOrReplace(source, key, source[key]);
        }
        else {
            removeOrReplace(source, key, omitFn(value));
        }
    }
    return source;
};
const omitDeep = (obj, options) => {
    const { clone = true, omitFn = (e) => !isDefinedAndNotNull(e) } = options || {};
    return omitDeepObject(clone ? lite.klona(obj) : obj, omitFn);
};

const dedent = (strings, ...values) => {
    // $FlowFixMe: Flow doesn't undestand .raw
    const raw = typeof strings === 'string' ? [strings] : strings.raw;
    // first, perform interpolation
    let result = '';
    for (let i = 0; i < raw.length; i++) {
        result += raw[i]
            // join lines when there is a suppressed newline
            .replace(/\\\n[\t ]*/g, '')
            // handle escaped backticks
            .replace(/\\`/g, '`');
        if (i < values.length) {
            result += values[i];
        }
    }
    // now strip indentation
    const lines = result.split('\n');
    let mindent = null;
    lines.forEach((l) => {
        let m = l.match(/^(\s+)\S+/);
        if (m) {
            let indent = m[1].length;
            mindent = !mindent ? indent : Math.min(mindent, indent);
        }
    });
    if (mindent !== null) {
        const m = mindent; // appease Flow
        result = lines.map((l) => (l[0] === ' ' ? l.slice(m) : l)).join('\n');
    }
    return (result
        // dedent eats leading and trailing whitespace too
        .trim()
        // handle escaped newlines at the end to ensure they don't get stripped too
        .replace(/\\n/g, '\n'));
};
const RGX_KEBAB_CASE = /([a-z])([A-Z])/g;
// fontSize -> font-size
const convertKebabCase = (str) => str.replace(RGX_KEBAB_CASE, '$1-$2').toLowerCase();
// fontSize -> FontSize
const convertPascalCase = (str) => str.replace(/\w+/g, (w) => w[0].toUpperCase() + w.slice(1).toLowerCase());
// font-size -> fontSize
const convertKebabCaseToCamelCase = (str) => str.toLowerCase().replace(/-(.)/g, (match, group1) => group1.toUpperCase());
// font-size -> Font Size
const convertKebabCaseToSpaceCase = (str) => firstCapitalString(str
    .toLowerCase()
    .replace(/-(.)/g, (match, group1) => ` ${group1.toUpperCase()}`));
const combineString = (items, separator = '') => {
    const strCombined = [];
    for (let i = 0; i < items.length; i++) {
        if (items[i])
            strCombined.push(items[i]);
    }
    return strCombined.join(separator);
};
const firstCapitalString = (str) => str[0].toUpperCase() + str.slice(1);

function createRuleSet(ruleSet) {
    return (input) => {
        let match = false;
        let matchCallback = null;
        for (let i = 0; i < ruleSet.length; i++) {
            const { rules, callback } = ruleSet[i];
            for (const key in rules) {
                match = true;
                const matchValue = rules[key];
                match = isFunction(matchValue)
                    ? matchValue(input)
                    : matchValue === input[key];
                if (!match)
                    break;
            }
            if (match) {
                matchCallback = callback;
                break;
            }
        }
        return [match, matchCallback];
    };
}

log4js__default['default'].configure({
    appenders: {
        api: {
            type: 'stdout',
            layout: {
                type: 'pattern',
                pattern: '[%d{yyyy-MM-ddThh:mm:ss.SSS}] [%p] %m',
            },
        },
    },
    categories: {
        default: {
            appenders: ['api'],
            level: 'debug',
        },
    },
});
const Logger = log4js__default['default'].getLogger('api');

const timeoutWait = async (time) => {
    Logger.info(`Wait ${time / 1000}s`);
    await new Promise((done) => {
        setTimeout(() => done(), parseInt(time));
    });
};

const createNewExpress = () => {
    const app = express__default['default']();
    app.disable('x-powered-by');
    app.use(bodyParser__default['default'].json());
    app.get('/status', (req, res) => res.json({ status: 'OK' }));
    return app;
};

const createNewExpressHandler = (fn) => {
    return async (req, res, next) => {
        try {
            await fn(req, res, next);
        }
        catch (e) {
            next(e);
        }
    };
};

class CustomError extends Error {
    constructor(reason, code, httpStatus) {
        super();
        this.data = {};
        if (isDefined(reason))
            this.reason = reason;
        if (isDefined(code))
            this.errorCode = code;
        if (isDefined(httpStatus))
            this.httpStatus = httpStatus;
    }
    setHttpStatus(status) {
        this.httpStatus = status;
        return this;
    }
    setErrorCode(code) {
        this.errorCode = code;
        return this;
    }
    setReason(reason) {
        this.reason = reason;
        return this;
    }
    setTag(tag) {
        this.tag = tag;
        return this;
    }
    setData(key, value) {
        if (isObject(key)) {
            this.data = key;
        }
        else {
            this.data[key] = value;
        }
        return this;
    }
    responseError(res) {
        const { reason, errorCode, httpStatus } = this;
        let status = httpStatus;
        if (!isNumber(status))
            status = errorCode === -1 ? 500 : 422;
        return res.status(status).json({
            code: errorCode !== null && errorCode !== void 0 ? errorCode : -1,
            reason: reason !== null && reason !== void 0 ? reason : 'An unexpected error has occurred.',
        });
    }
}

const expressErrorMiddleware = (errorParser) => {
    return (error, req, res, next) => {
        if (res.headersSent)
            return next(error);
        if (error instanceof CustomError) {
            if (errorParser) {
                const parsed = errorParser.parse(error);
                if (parsed) {
                    const { httpStatusCode, reason, code } = parsed;
                    return res.status(httpStatusCode).json({ code, reason });
                }
            }
            return error.responseError(res);
        }
        Logger.error(`Unhandled error`, error);
        new CustomError(error.toString()).responseError(res);
    };
};

const errorDatas = [];
class ErrorParser {
    addBulk(datas) {
        errorDatas.push(...datas);
        return this;
    }
    add({ code, reason, source, strategy, match, tag, }) {
        errorDatas.push({
            errorTag: tag,
            errorSource: source,
            matchStrategy: strategy,
            matchDataOrFn: (isDefined(match) ? match : code),
            reason,
            code,
        });
        return this;
    }
    parse(e) {
        var _a;
        if (e instanceof CustomError) {
            let foundParserData;
            for (let i = 0; i < errorDatas.length; i++) {
                const { errorSource = 'code', matchDataOrFn, matchStrategy = 'eq', errorTag, } = errorDatas[i];
                if (errorTag && errorTag !== e.tag)
                    continue;
                const matcher = matchDataOrFn;
                let found = false;
                const sourceValue = (_a = (errorSource === 'code' ? e.errorCode : e.reason)) !== null && _a !== void 0 ? _a : '';
                if (isFunction(matchDataOrFn)) {
                    found = matcher(e);
                }
                else {
                    switch (matchStrategy) {
                        case 'eq':
                            found = sourceValue === matcher;
                            break;
                        case 'startsWith':
                            found = isString(sourceValue)
                                ? sourceValue.startsWith(matcher)
                                : false;
                            break;
                        case 'endsWith':
                            found = isString(sourceValue)
                                ? sourceValue.endsWith(matcher)
                                : false;
                            break;
                        case 'includes':
                            found = isString(sourceValue)
                                ? sourceValue.includes(matcher)
                                : false;
                            break;
                    }
                }
                if (found) {
                    foundParserData = errorDatas[i];
                    break;
                }
            }
            if (foundParserData) {
                return {
                    httpStatusCode: 422,
                    code: foundParserData.code,
                    reason: isFunction(foundParserData.reason)
                        ? foundParserData.reason(e)
                        : foundParserData.reason,
                };
            }
        }
        return null;
    }
}

exports.PuppeteerErrorCode = void 0;
(function (PuppeteerErrorCode) {
    PuppeteerErrorCode[PuppeteerErrorCode["Timeout"] = 15000] = "Timeout";
    PuppeteerErrorCode[PuppeteerErrorCode["NameNotResolved"] = 15001] = "NameNotResolved";
    PuppeteerErrorCode[PuppeteerErrorCode["Failed"] = 15002] = "Failed";
    PuppeteerErrorCode[PuppeteerErrorCode["LoadingStyle"] = 15003] = "LoadingStyle";
    PuppeteerErrorCode[PuppeteerErrorCode["UnhandledError"] = 15999] = "UnhandledError";
})(exports.PuppeteerErrorCode || (exports.PuppeteerErrorCode = {}));
const stdPuppeteerReason = (e) => e.reason.replace('Error: ', '');
const PuppeteerErrorData = [
    {
        code: exports.PuppeteerErrorCode.Timeout,
        errorTag: 'puppeteer',
        errorSource: 'reason',
        reason: (e) => e.reason.replace('TimeoutError: ', ''),
        matchDataOrFn: 'TimeoutError: ',
        matchStrategy: 'includes',
    },
    {
        code: exports.PuppeteerErrorCode.NameNotResolved,
        errorTag: 'puppeteer',
        errorSource: 'reason',
        reason: stdPuppeteerReason,
        matchDataOrFn: 'ERR_NAME_NOT_RESOLVED',
        matchStrategy: 'includes',
    },
    {
        code: exports.PuppeteerErrorCode.Failed,
        errorTag: 'puppeteer',
        errorSource: 'reason',
        reason: stdPuppeteerReason,
        matchDataOrFn: 'ERR_FAILED',
        matchStrategy: 'includes',
    },
    {
        code: exports.PuppeteerErrorCode.LoadingStyle,
        errorTag: 'puppeteer',
        errorSource: 'reason',
        reason: stdPuppeteerReason,
        matchDataOrFn: 'Loading style',
        matchStrategy: 'includes',
    },
    {
        code: exports.PuppeteerErrorCode.UnhandledError,
        errorTag: 'puppeteer',
        reason: stdPuppeteerReason,
        matchDataOrFn: (e) => e.tag === 'puppeteer',
    },
];

const getPrefixUrl = (url) => {
    if (!isString(url))
        return url;
    return url.startsWith('https://') || url.startsWith('http://')
        ? url
        : `http://${url}`;
};

const createQueryParamsParser = (dataMap) => {
    return {
        parse(inputQuery) {
            var _a;
            let error = null;
            let errorParams = {};
            const queryParsed = {};
            for (const key in inputQuery) {
                let value = inputQuery[key];
                if (dataMap[key]) {
                    const { type = 'string' } = dataMap[key];
                    switch (type) {
                        case 'number':
                            if (!isNumber(value)) {
                                const floatVal = parseFloat(value);
                                if (value != floatVal) {
                                    value = null; // Make type error
                                }
                                else {
                                    value = floatVal;
                                }
                            }
                            break;
                        case 'boolean':
                            if (!isBoolean(value)) {
                                value =
                                    value === 'true' || value === 'false'
                                        ? value === 'true'
                                        : null;
                            }
                            break;
                        case 'string':
                            if (!isString(value)) {
                                value = null;
                            }
                            break;
                    }
                    queryParsed[key] = value;
                }
            }
            for (const key in dataMap) {
                let value = queryParsed[key];
                const { validations = [] } = dataMap[key];
                let hasError = false;
                if (validations.length) {
                    for (let i = 0; i < validations.length; i++) {
                        try {
                            validations[i].validateSync(value, queryParsed);
                        }
                        catch (e) {
                            const vEror = e;
                            const [firstError] = (_a = vEror.errors) !== null && _a !== void 0 ? _a : [];
                            errorParams = vEror.params;
                            error = firstError;
                            hasError = true;
                        }
                        if (hasError)
                            break;
                    }
                }
                if (hasError)
                    break;
            }
            return { error, errorParams, queryParsed };
        },
    };
};
const parseQueryParams = () => { };

const parseDomain = (domain) => {
    const fullUrl = domain.includes('://') ? domain : `http://${domain}`;
    const { type, hostname, ...restResults } = parseDomain$1.parseDomain(parseDomain$1.fromUrl(fullUrl));
    const valid = type === 'LISTED' || type === 'IP';
    return {
        valid,
        fullUrl,
        type,
        hostname,
        ...restResults,
    };
};

const decodeQueryParams = (urlSearch = location.search) => {
    if (!urlSearch)
        return {};
    return qss.decode(urlSearch.slice(1));
};
const encodeUrlWithQueryParams = (url, queryParams) => {
    if (!queryParams)
        return url;
    const queryString = qss.encode(queryParams, '');
    return queryString ? `${url}?${queryString}` : url;
};

Object.defineProperty(exports, 'mergeDeep', {
  enumerable: true,
  get: function () {
    return mergeDeep__default['default'];
  }
});
Object.defineProperty(exports, 'equalDeep', {
  enumerable: true,
  get: function () {
    return dequal.dequal;
  }
});
Object.defineProperty(exports, 'flatObject', {
  enumerable: true,
  get: function () {
    return flattie.flattie;
  }
});
Object.defineProperty(exports, 'cloneDeep', {
  enumerable: true,
  get: function () {
    return lite.klona;
  }
});
Object.defineProperty(exports, 'uid', {
  enumerable: true,
  get: function () {
    return nanoid.nanoid;
  }
});
exports.yup = yup__namespace;
exports.CustomError = CustomError;
exports.ErrorParser = ErrorParser;
exports.Logger = Logger;
exports.PuppeteerErrorData = PuppeteerErrorData;
exports.changeArrayPosition = changeArrayPosition;
exports.combineString = combineString;
exports.compareObjectByKeys = compareObjectByKeys;
exports.convertKebabCase = convertKebabCase;
exports.convertKebabCaseToCamelCase = convertKebabCaseToCamelCase;
exports.convertKebabCaseToSpaceCase = convertKebabCaseToSpaceCase;
exports.convertPascalCase = convertPascalCase;
exports.createNewExpress = createNewExpress;
exports.createNewExpressHandler = createNewExpressHandler;
exports.createQueryParamsParser = createQueryParamsParser;
exports.createRuleSet = createRuleSet;
exports.dayJs = dayJs;
exports.debounce = debounce;
exports.decodeQueryParams = decodeQueryParams;
exports.dedent = dedent;
exports.deleteWithPath = deleteWithPath;
exports.encodeUrlWithQueryParams = encodeUrlWithQueryParams;
exports.expressErrorMiddleware = expressErrorMiddleware;
exports.filterArrayUnique = filterArrayUnique;
exports.firstCapitalString = firstCapitalString;
exports.getArrayDifference = getArrayDifference;
exports.getArrayIntersection = getArrayIntersection;
exports.getPrefixUrl = getPrefixUrl;
exports.getWithPath = getWithPath;
exports.getWithPathAny = getWithPathAny;
exports.getWithPaths = getWithPaths;
exports.isArray = isArray;
exports.isArrayAndHasChild = isArrayAndHasChild;
exports.isBoolean = isBoolean;
exports.isBrowser = isBrowser;
exports.isDefined = isDefined;
exports.isDefinedAndNotNull = isDefinedAndNotNull;
exports.isFunction = isFunction;
exports.isMac = isMac;
exports.isNotNull = isNotNull;
exports.isNumber = isNumber;
exports.isObject = isObject;
exports.isPlainObject = isPlainObject;
exports.isString = isString;
exports.iterateObject = iterateObject;
exports.objectToArray = objectToArray;
exports.omitDeep = omitDeep;
exports.omitObjectByFields = omitObjectByFields;
exports.parseDomain = parseDomain;
exports.parseQueryParams = parseQueryParams;
exports.patchObject = patchObject;
exports.setWithPath = setWithPath;
exports.shuffleArray = shuffleArray;
exports.sortArrayByAlphabet = sortArrayByAlphabet;
exports.sortArrayByNumber = sortArrayByNumber;
exports.timeoutWait = timeoutWait;
