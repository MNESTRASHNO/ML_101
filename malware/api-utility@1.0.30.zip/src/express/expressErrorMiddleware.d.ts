import { ErrorRequestHandler } from 'express';
import { ErrorParser } from '../error';
export declare const expressErrorMiddleware: (errorParser?: ErrorParser) => ErrorRequestHandler;
