export declare const createNewExpress: () => import("express-serve-static-core").Express;
