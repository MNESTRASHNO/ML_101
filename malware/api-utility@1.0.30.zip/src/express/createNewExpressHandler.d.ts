import { RequestHandler } from 'express';
export declare const createNewExpressHandler: (fn: RequestHandler) => (req: any, res: any, next: any) => Promise<void>;
