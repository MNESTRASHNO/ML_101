export declare type OmitObjectFn = (value: any) => boolean | any;
export declare const omitDeep: <T extends object>(obj: T, options?: {
    omitFn?: OmitObjectFn;
    clone?: boolean;
}) => T;
