import { nanoid as uid } from 'nanoid';
export { uid };
export declare const dedent: (strings: TemplateStringsArray, ...values: Array<string>) => string;
export declare const convertKebabCase: (str: string) => string;
export declare const convertPascalCase: (str: string) => string;
export declare const convertKebabCaseToCamelCase: (str: string) => string;
export declare const convertKebabCaseToSpaceCase: (str: string) => string;
export declare const combineString: (items: Array<any>, separator?: string) => string;
export declare const firstCapitalString: (str: string) => string;
