import d from 'dayjs';
export declare const dayJs: typeof d;
