export declare const timeoutWait: (time: any) => Promise<void>;
