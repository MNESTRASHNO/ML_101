export declare type RuleSetOptions<T, P> = P | ((input: RuleSetValue<T>) => boolean);
export declare type RuleSet<T> = {
    rules: {
        [P in keyof T]: RuleSetOptions<T, T[P]>;
    };
    callback: any;
};
export declare type RuleSetValue<T> = {
    [P in keyof T]: T[P] extends RuleSetOptions<any, infer V> ? V : T[P];
};
export declare function createRuleSet<T>(ruleSet: Array<RuleSet<T>>): (input: T) => [boolean, any];
