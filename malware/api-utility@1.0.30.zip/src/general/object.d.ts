import mergeDeep from 'deepmerge';
import { dequal as equalDeep } from 'dequal';
import { flattie as flatObject } from 'flattie';
import { klona as cloneDeep } from 'klona/lite';
import { LiteralUnion } from 'type-fest';
export { mergeDeep, cloneDeep, equalDeep, flatObject };
export declare const deleteWithPath: <T>(obj: T, keys: string) => void;
export declare const patchObject: <T>(options: {
    fromValue: T;
    toValue: T | ((value: T) => T);
    replace?: boolean;
    mergeDeep?: boolean;
}) => T;
export declare const iterateObject: <T extends object, P extends keyof T>(source: T, cb: (obj: T[P], key: P) => void) => void;
export declare const omitObjectByFields: <T extends object>(fields: LiteralUnion<keyof T, string>[], srcObject: T) => Partial<T>;
export declare const objectToArray: <Obj extends object, ObjKey extends keyof Obj, WithKey extends boolean>(obj: Obj, _withKey?: WithKey) => WithKey extends false ? Obj[ObjKey][] : {
    value: Obj[ObjKey];
    key: keyof Obj;
}[];
export declare const compareObjectByKeys: (obj1: any, obj2: any, keys: Array<string>) => boolean;
