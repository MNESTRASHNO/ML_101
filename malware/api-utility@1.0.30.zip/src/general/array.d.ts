export declare const filterArrayUnique: <T>(array: T[]) => T[];
export declare const changeArrayPosition: (array: Array<any>, from: number, to: number) => void;
export declare const getArrayIntersection: (arr: Array<any>, ...args: Array<any>) => any[];
export declare const getArrayDifference: (arr1: Array<any>, arr2: Array<any>) => any[];
export declare const shuffleArray: (arr: Array<any>) => any[];
export declare const sortArrayByNumber: <T>({ source, getterFn, asc, }: {
    source: T[];
    getterFn?: (value: T) => number;
    asc?: boolean;
}) => T[];
export declare const sortArrayByAlphabet: <T>({ source, getterFn, asc, }: {
    source: T[];
    getterFn?: (value: T) => string;
    asc?: boolean;
}) => T[];
