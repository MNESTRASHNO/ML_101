export declare function debounce<ResultFn extends (this: any, ...newArgs: Array<any>) => ReturnType<ResultFn>>(fn: any, time?: number): (...arg: any[]) => void;
