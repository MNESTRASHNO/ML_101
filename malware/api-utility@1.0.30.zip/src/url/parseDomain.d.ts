import { ParseResult } from 'parse-domain';
export declare const parseDomain: (domain: string) => ParseResult & {
    valid: boolean;
    fullUrl: string;
};
