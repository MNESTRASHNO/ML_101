export declare type QueryParamsData = {
    type?: 'string' | 'number' | 'boolean';
    validations?: Array<{
        validateSync: (value: any, obj: any) => any;
    }>;
};
export declare const createQueryParamsParser: <T extends Record<string, QueryParamsData>>(dataMap: T) => {
    parse(inputQuery: Record<string, any>): {
        error: any;
        errorParams: {};
        queryParsed: Record<keyof T, any>;
    };
};
export declare const parseQueryParams: () => void;
