export declare const getPrefixUrl: (url: string) => string;
