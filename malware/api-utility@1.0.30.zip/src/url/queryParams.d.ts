export declare const decodeQueryParams: (urlSearch?: string) => Record<string, string>;
export declare const encodeUrlWithQueryParams: (url: string, queryParams: Record<string, any>) => string;
