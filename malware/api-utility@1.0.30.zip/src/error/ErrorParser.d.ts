import { CustomError } from './CustomError';
export declare type ErrorParserResponse = {
    code: number;
    reason: string | ((v: CustomError) => string);
    httpStatusCode: number;
};
export declare type ErrorParserStrategy = 'eq' | 'startsWith' | 'endsWith' | 'includes';
declare type MatchDataOrFn<T extends string> = T extends 'code' ? number | ((v: CustomError) => boolean) : string | ((v: CustomError) => boolean);
export declare type ErrorParserData = Omit<ErrorParserResponse, 'httpStatusCode'> & {
    errorTag?: string;
    errorSource?: 'code' | 'reason';
    matchStrategy?: ErrorParserStrategy;
    matchDataOrFn?: string | number | ((value: CustomError) => void);
};
export declare class ErrorParser {
    addBulk(datas: Array<ErrorParserData>): this;
    add<Source extends 'code' | 'reason'>({ code, reason, source, strategy, match, tag, }: {
        code: number;
        reason: string | ((value: CustomError) => string);
        source?: Source;
        tag?: string;
        strategy?: ErrorParserStrategy;
        match?: MatchDataOrFn<Source>;
    }): this;
    parse(e: Error): ErrorParserResponse;
}
export {};
