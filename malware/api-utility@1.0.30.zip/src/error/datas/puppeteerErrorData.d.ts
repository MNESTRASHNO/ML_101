import { ErrorParserData } from '../ErrorParser';
export declare enum PuppeteerErrorCode {
    Timeout = 15000,
    NameNotResolved = 15001,
    Failed = 15002,
    LoadingStyle = 15003,
    UnhandledError = 15999
}
export declare const PuppeteerErrorData: Array<ErrorParserData>;
