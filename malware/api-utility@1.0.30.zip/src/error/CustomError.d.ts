import { Response } from 'express';
export declare class CustomError extends Error {
    reason: string;
    errorCode: number;
    httpStatus: number;
    tag: string;
    data: Record<string, any>;
    constructor(reason?: string, code?: number, httpStatus?: number);
    setHttpStatus(status: number): this;
    setErrorCode(code: number): this;
    setReason(reason: string): this;
    setTag(tag: string): this;
    setData(key: string | object, value?: any): this;
    responseError(res: Response): Response<any, Record<string, any>>;
}
