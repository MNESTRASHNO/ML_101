import log4js from 'log4js';
export declare const Logger: log4js.Logger;
