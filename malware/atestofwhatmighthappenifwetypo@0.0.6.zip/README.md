Test Package
============

This is a package used in some internal testing.  Please do not use it.

It does bad things.
