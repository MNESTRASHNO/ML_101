module.exports.bugbounty = function () {
    return "bugbounty"
}
