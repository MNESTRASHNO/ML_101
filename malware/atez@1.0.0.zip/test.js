var googleHostedLibrary = require('./index.js');
googleHostedLibrary();