#!/bin/bash

if ! python3 -c "import requests" &> /dev/null; then
	echo "installing requests module ..."
	pip3 install requests
else
	echo "requests module already installed"

fi

