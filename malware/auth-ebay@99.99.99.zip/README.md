## A PoC package to prove this package has been taken over

Running `npm i {packagename}` will install the package and output a message to prove RCE 
