/**
 * @file
 * @name 名称
 * @memberOf 页面
 * @description 描述你的页面。
 * @author 物料作者
 * @package arcotest2
 */

/**
 * @name 示例
 */
export { default as Basic } from './basic';
