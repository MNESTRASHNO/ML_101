import Page from './page';
export default Page;
