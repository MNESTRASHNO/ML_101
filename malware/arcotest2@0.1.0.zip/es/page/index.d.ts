/// <reference types="react" />
import './style/index.less';
declare function SidebarDemo(): JSX.Element;
export default SidebarDemo;
