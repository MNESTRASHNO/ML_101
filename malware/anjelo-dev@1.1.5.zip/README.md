# https://www.facebook.com/anjelogwpo
```js
const fs = require("fs");
const login = require("Anjelo-Dev");

var credentials = {email: "FB_EMAIL", password: "FB_PASSWORD"}; 

login(credentials, (err, api) => {
    if(err) return console.error(err);
    
    fs.writeFileSync('appstate.json', JSON.stringify(api.getAppState(), null,'\t')); 
});
```

download and go to your facebook profile and download => [c3c-fbstate](https://github.com/c3cbot/c3c-fbstate) pagka open nyo copy niyo nalang and paste nyo nalang ito sa ! (appstate.json)

-------