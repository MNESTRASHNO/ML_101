# Security Policy

+ if have any Vulnerability finded contact: Author(KanzuWakazaki.Main@proton.me) or (Facebook.com/Lazic.Kanzu). Thanks!

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| Main Version With Autoupdate | :white_check_mark: |
| Old Version | :x:|

## Reporting a Vulnerability

Contact Author
