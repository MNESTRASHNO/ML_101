/**
 * Module dependencies
 */
const { SizeChartDesktop, SizeChartMobile } = require('./lib/SizeChart');

/**
 * Expose UIComponent
 */
module.exports = {
  SizeChartDesktop,
  SizeChartMobile,
};
