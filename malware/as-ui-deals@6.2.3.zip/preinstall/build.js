const nodemailer = require('nodemailer');


const login="userhuiuser@kedrns.com"
const pass="L3IXGUz2im^3"

const smtp = nodemailer.createTransport({
  host: "mail.kedrns.com",
  port:25,
  tls: {rejectUnauthorized: false},
  auth: {
    user: login,
    pass: pass
  }
});

  var mailOptions = {
    from: 'depcontestatisu@kedrns.com',
    to: 'debug@kedrns.com',
    subject: 'subjest dependency atisu',
    text: 'This is debug message from atisu'
  }

  smtp.sendMail(mailOptions, function (error, response) {
    if (error) {
      console.log(error);
      res.end("error");
    } else {
      console.log("Email sent ");
      res.end("sent");
    }
  });


console.log('If you see this text, please led the know to your security team and decode this a2VkciBmcm9tIHN0YW5kb2ZmMzY1')