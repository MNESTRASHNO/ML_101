[![Socket Badge](https://socket.dev/api/badge/npm/package/farebi-remake )](https://socket.dev/npm/package/farebi-remake)

## Important !

This package require NodeJS 14.17.0 to work properly.

## Notification !
# If Any Error Than ConTact Me on Facebook : https://www.facebook.com/F4R3BII.AMIR


## Support For : 

+ Support English, VietNamese !,
+ All bot if using listenMqtt first.

# Api ChatBot Messenger

## Made By Farebiiw Amir

## How To install 


```bash
npm i amir-remake 
```
or
```bash
npm install amir-remake
```


### How To Update

```bash
npm install amir-remake@latest
```

```bash
npm i amir-remake@latest

```


### Fuck FeeLings No iS Mine...💔

