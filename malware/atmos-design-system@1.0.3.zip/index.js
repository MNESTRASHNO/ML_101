module.exports.hacked = function () {
    return "bug bounty ahmed at nybbletech dot com"
}