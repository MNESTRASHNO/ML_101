const App = require('./app');

module.exports = App;