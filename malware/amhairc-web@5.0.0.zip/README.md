<h1 align="center">This NPM package vulnerable to dependency confiuse vulnerability</h1>
<p align="center">Name: Aryan Jaiswal</p>
<p align="center">Contact: aryan351985@gmail.com</p>