module.exports.bugbounty = function () {
    return "loblaw-digital"
}
