'use strict';
// NodeJS-safe

// override
const SESSION_NAME = 'anchorpw_s';
const ASSETS_PATH = 'https://d12xoj7p9moygp.cloudfront.net/';
const BUILD_ASSETS_PATH = 'https://d1rx8vrt2hn1hc.cloudfront.net/builds/';

// caching because this should only happen once
let parsedUserAgent = null;

// cached so creation requests re-use this and don't exceed maximum bindings
let currentAudioContext = null;

let hasNativeShapeSupport;

module.exports = {
  ASSETS_PATH,
  BUILD_ASSETS_PATH,
  createAudioContext,
  forceLocalFile,
  nextFrame,
  clearInterval,
  setInterval,
  SESSION_NAME,
  getBaseUrl,
  getOpenInAppUrl,
  getTerminalRoute,
  isAndroid,
  isAndroidChrome,
  isIOS,
  hasShapeSupport,
  appStoreLink,
  parseUserAgent,
  playStoreLink,
  maxLength,
  getGAProperty,
  setPageTitle,
  runArrayFindPolyfill,
  isMobileOrTabletWithTouch,
  windowUndefined,
};

function createAudioContext() {
  if (windowUndefined()) return {};
  if (!currentAudioContext) {
    currentAudioContext = new (window.AudioContext || window.webkitAudioContext)();
  }
  return currentAudioContext;
}

function windowUndefined() {
  return (typeof window === 'undefined');
}

function nextFrame(fn) {
  if (windowUndefined()) return fn();
  return window.requestAnimationFrame(fn);
}

function setInterval(fn, interval) {
  if (windowUndefined()) return fn();
  return window.setInterval(fn, interval);
}

function clearInterval(intervalId) {
  if (windowUndefined()) return null;
  return window.clearInterval(intervalId);
}

function getBaseUrl() {
  return {
    local: `http://localhost:${process.env.PORT || 8012}`,
    development: 'https://v2websitedev2.anchor.fm',
    //staging: 'https://v2websiteprod.anchor.fm', TODO: re-enable once we have a proper staging/production separation
    staging: 'https://anchor.fm',
    production: 'https://anchor.fm',
  }[ENVIRONMENT || 'local'];
}

function hasShapeSupport() {
  if (hasNativeShapeSupport === undefined) {
    return !windowUndefined() && calculateShapeSupport(window.document)
  }
  return hasNativeShapeSupport;
}

// https://github.com/adobe-webplatform/css-shapes-polyfill/blob/3bf7286fadc585683d906958c0b5525fcc61eb2b/src/shape-polyfill.js
// We would use this polyfill but it does not support media-query based styles
function calculateShapeSupport(document) {
  var div = document.createElement('div');
  var properties = ['shape-outside', '-webkit-shape-outside'];
  properties.forEach(function(property) {
    div.style.setProperty(property, 'content-box');
    hasNativeShapeSupport = hasNativeShapeSupport || div.style.getPropertyValue(property);
  });
  hasNativeShapeSupport = !!hasNativeShapeSupport;
  return hasNativeShapeSupport;
}

function appStoreLink(campaign = 'WebsiteTracking') {
  return `https://itunes.apple.com/app/apple-store/id1056182234?pt=118017867&ct=${campaign}&mt=8`;
}

function playStoreLink(config = {}) {
  let referrerParam = 'utm_source=Anchor%20Home&utm_medium=cpc&utm_campaign=Anchor%20Home&anid=admob';
  if (config.callJoinCode) {
    referrerParam += `&call_join_code=${config.callJoinCode}`;
  }
  if (config.referralCode) {
    referrerParam += `&referral_code=${config.referralCode}`;
  }
  return `https://play.google.com/store/apps/details?id=fm.anchor.android&referrer=${encodeURIComponent(referrerParam)}`;
}

function maxLength(length) {
  return value => (value ? value.slice(0, length) : '');
}

function getGAProperty(env) {
  return (env === 'staging' || env === 'production') ? 'UA-62744412-3' : 'UA-62744412-2';
}

function setPageTitle(title) {
  if (windowUndefined()) {
    return;
  }
  document.title = title;
}

function runArrayFindPolyfill() {
  // https://tc39.github.io/ecma262/#sec-array.prototype.find
  if (!Array.prototype.find) {
    Object.defineProperty(Array.prototype, 'find', {
      value: function(predicate) {
        // 1. Let O be ? ToObject(this value).
        if (this == null) {
          throw new TypeError('"this" is null or not defined');
        }

        var o = Object(this);

        // 2. Let len be ? ToLength(? Get(O, "length")).
        var len = o.length >>> 0;

        // 3. If IsCallable(predicate) is false, throw a TypeError exception.
        if (typeof predicate !== 'function') {
          throw new TypeError('predicate must be a function');
        }

        // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
        var thisArg = arguments[1];

        // 5. Let k be 0.
        var k = 0;

        // 6. Repeat, while k < len
        while (k < len) {
          // a. Let Pk be ! ToString(k).
          // b. Let kValue be ? Get(O, Pk).
          // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
          // d. If testResult is true, return kValue.
          var kValue = o[k];
          if (predicate.call(thisArg, kValue, k, o)) {
            return kValue;
          }
          // e. Increase k by 1.
          k++;
        }

        // 7. Return undefined.
        return undefined;
      }
    });
  }
}

function isMobileOrTabletWithTouch() {
  if (windowUndefined()) {
    return false;
  }
  const { tablet, mobile, touch } = parseUserAgent();
  return touch && (tablet || mobile);
}

function isAndroid() {
  if (windowUndefined()) {
    return false;
  }
  const { mobile } = parseUserAgent();
  return (mobile === 'a');
}

function isAndroidChrome() {
  if (windowUndefined()) {
    return false;
  }
  const { browser, mobile } = parseUserAgent();
  return (browser === 'gc' && mobile === 'a');
}

function isIOS() {
  if (windowUndefined()) {
    return false;
  }
  const { mobile } = parseUserAgent();
  return (mobile === 'i');
}

// include leading slash / root relative
function getOpenInAppUrl(url) {
  if (windowUndefined()) {
    return url;
  }
  const { browser, mobile } = parseUserAgent();
  if (browser === 'gc' && mobile === 'a') { // android chrome
    return `intent://anchor.fm${url}#Intent;scheme=anchorfm;package=fm.anchor.android;S.browser_fallback_url=${url};end`;
  }
  if (mobile === 'i') { // iphone/ipad
    return `AnchorFM://anchor.fm${url}`;
  }
  return url;
}

// https://jsfiddle.net/oriadam/ncb4n882/
function parseUserAgent() {
  if (parsedUserAgent) {
    return parsedUserAgent;
  }
  const ua = navigator.userAgent;
  parsedUserAgent = {
    browser: /Edge\/\d+/.test(ua) ? 'ed' : /MSIE 9/.test(ua) ? 'ie9' : /MSIE 10/.test(ua) ? 'ie10' : /MSIE 11/.test(ua) ? 'ie11' : /MSIE\s\d/.test(ua) ? 'ie?' : /rv\:11/.test(ua) ? 'ie11' : /Firefox\W\d/.test(ua) ? 'ff' : /Chrom(e|ium)\W\d|CriOS\W\d/.test(ua) ? 'gc' : /\bSafari\W\d/.test(ua) ? 'sa' : /\bOpera\W\d/.test(ua) ? 'op' : /\bOPR\W\d/i.test(ua) ? 'op' : typeof MSPointerEvent !== 'undefined' ? 'ie?' : '',
    os: /Windows NT 10/.test(ua) ? "win10" : /Windows NT 6\.0/.test(ua) ? "winvista" : /Windows NT 6\.1/.test(ua) ? "win7" : /Windows NT 6\.\d/.test(ua) ? "win8" : /Windows NT 5\.1/.test(ua) ? "winxp" : /Windows NT [1-5]\./.test(ua) ? "winnt" : /Mac/.test(ua) ? "mac" : /Linux/.test(ua) ? "linux" : /X11/.test(ua) ? "nix" : "",
    touch: 'ontouchstart' in document.documentElement,
    mobile: /IEMobile|Windows Phone|Lumia/i.test(ua) ? 'w' : /iPhone|iP[oa]d/.test(ua) ? 'i' : /Android/.test(ua) ? 'a' : /BlackBerry|PlayBook|BB10/.test(ua) ? 'b' : /Mobile Safari/.test(ua) ? 's' : /webOS|Mobile|Tablet|Opera Mini|\bCrMo\/|Opera Mobi/i.test(ua) ? 1 : 0,
    tablet: /Tablet|iPad/i.test(ua),
  };
  return parsedUserAgent;
}

// Get the terminal <Route /> associated with the current match's renderProps
function getTerminalRoute(routes) {
  return routes[routes.length - 1];
}

function forceLocalFile() {
  return (process.argv.indexOf('--forceLocalFile') !== -1);
}
