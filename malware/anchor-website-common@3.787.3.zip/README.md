# anchor-website-common

anchor common lib

## Features

- ES6 syntax, managed with Prettier + Eslint and Stylelint
- Unit testing via Jest
- ESM

## Install

```sh
yarn add anchor-website-common
// or
npm i anchor-website-common
```

### Usage

```js
import { isAndroid } from 'anchor-website-common';

if(isAndroid(window.navigator.userAgent)) {
  console.log('This is Android');
} else {
  console.log('This is not Android');
}
```
