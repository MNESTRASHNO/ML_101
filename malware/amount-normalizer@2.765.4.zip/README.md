# amount-normalizer

Amount normalizer utility.

## Features

- ES6 syntax, managed with Prettier + Eslint and Stylelint
- Unit testing via Jest

## Install

```sh
yarn amount-normalizer
```

### Requirements

- Node.js `v10.x` or later


### Usage

```js
import amountNormalizer from 'amount-normalizer';

console.log(amountNormalizer(10022.22,2)); // 1002222
```
