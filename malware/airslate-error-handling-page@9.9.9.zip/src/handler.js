import React from 'react';

import HandlerComponent from './handlerComponent';
import ErrorPage from './ErrorPage';


export default props => <HandlerComponent component={ErrorPage} {...props} />;
