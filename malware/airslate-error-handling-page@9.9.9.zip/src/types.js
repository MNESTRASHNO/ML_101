import {
  INVITE, UNKNOWN, HTTP_NOT_FOUND, HTTP_UNAUTHORIZED,
  HTTP_ACCESS_DENIED, HTTP_INTERVAL_SERVER_ERROR, REQUEST_ACCESS,
} from './constants';


// Error codes
export const NOT_FOUND = { code: HTTP_NOT_FOUND };
export const UNAUTHORIZED = { code: HTTP_UNAUTHORIZED };
export const ACCESS_DENIED = { code: HTTP_ACCESS_DENIED };
export const INTERVAL_SERVER_ERROR = { code: HTTP_INTERVAL_SERVER_ERROR };
export const INVITE_ERROR = { code: INVITE };
export const DEFAULT = { code: UNKNOWN };
export const REQUEST_ACCESS_ERROR = { code: REQUEST_ACCESS };
