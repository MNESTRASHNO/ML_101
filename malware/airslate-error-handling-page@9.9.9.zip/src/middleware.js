import {
  Hub,
  Severity,
  BrowserClient,
} from '@sentry/browser';
import ReduxErrorJSLogger from './ReduxErrorJSLogger';


const SentryBrowser = new BrowserClient({
  dsn: __SENTRY_KEY__,
  debug: !__PROD__,
  environment: __TARGET__,
  release: `${__BRANCH__}@${__BUILD_NUMBER__}`,
});

const Sentry = new Hub(SentryBrowser);

export const ErrorJSLoggerWithOption = option => ReduxErrorJSLogger(Sentry, Severity, option);

export default ReduxErrorJSLogger(Sentry, Severity, null);
