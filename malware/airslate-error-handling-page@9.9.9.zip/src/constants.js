// Common
const { STATIC_URL, MAIN_DOMAIN } = global.AIRSLATE_ENV_CONFIGURATION;

export const EMPTY_STRING = '';
export const REDUX_ACTION = 'redux-action';
export const REDUX_STORE = 'redux-store';
export const IMAGES_STATIC_PATH = `${STATIC_URL}/images/default`;

export const EMPTY_ERROR_STATE = {};
export const ERROR_ACTION_REQUEST = 'EHP::ERROR::REQUESTED';
export const ERROR_ACTION_FORWARD = 'EHP::ERROR::FORWARD';
export const ERROR_ACTION_CLEAR = 'EHP::ERROR::CLEAR';


// images
export const ERROR_IMAGE_ACCESS_DENIED = `${IMAGES_STATIC_PATH}/access-denied.png`;
export const ERROR_IMAGE_NOT_FOUND = `${IMAGES_STATIC_PATH}/404.png`;
export const ERROR_IMAGE_EXERTION = `${IMAGES_STATIC_PATH}/500.png`;


// Redirect
export const MY_DOMAIN_PATH = `my.${MAIN_DOMAIN}`;
export const HOME_PATH = '/';
export const LOGIN_PATH = `/login?redirect=${global.location.pathname}${global.location.search}`;
export const REQUEST_ACCESS_PATH = '/request-access';


// Error types
export const UNKNOWN = 'UNKNOWN';
export const INVITE = 'INVITE_ERROR';
export const REQUEST_ACCESS = 'REQUEST_ACCESS';


export const HTTP_BAD_REQUEST = 400;
export const HTTP_UNAUTHORIZED = 401;
export const HTTP_PAYMENT_REQUIRED = 402;
export const HTTP_ACCESS_DENIED = 403;
export const HTTP_NOT_FOUND = 404;
export const HTTP_METHOD_NOT_ALLOWED = 405;
export const HTTP_NOT_ACCEPTABLE = 406;
export const HTTP_PROXY_AUTHENTICATION_REQUIRED = 407;
export const HTTP_REQUEST_TIMEOUT = 408;
export const HTTP_CONFLICT = 409;
export const HTTP_GONE = 410;
export const HTTP_LENGTH_REQUIRED = 411;
export const HTTP_PRECONDITION_FAILED = 412;
export const HTTP_REQUEST_ENTITY_TOO_LARGE = 413;
export const HTTP_REQUEST_URI_TOO_LONG = 414;
export const HTTP_UNSUPPORTED_MEDIA_TYPE = 415;
export const HTTP_REQUESTED_RANGE_NOT_SATISFIABLE = 416;
export const HTTP_EXPECTATION_FAILED = 417;
export const HTTP_UNPROCESSABLE_ENTITY = 422;
export const HTTP_INTERVAL_SERVER_ERROR = 500;
export const HTTP_NOT_IMPLEMENTED = 501;
export const HTTP_BAD_GATEWAY = 502;
export const HTTP_SERVICE_UNAVAILABLE = 503;
export const HTTP_GATEWAY_TIMEOUT = 504;
export const HTTP_HTTP_VERSION_NOT_SUPPORTED = 505;

// Error enum
export const PAYLOAD_BY_ERROR_CODE = {
  [HTTP_UNAUTHORIZED]: {
    force: true,
    redirect: LOGIN_PATH,
  },

  [HTTP_BAD_REQUEST]: {
    code: HTTP_BAD_REQUEST,
    title: 'PAGE_TITLE_INTERVAL_SERVER_ERROR',
    image: ERROR_IMAGE_NOT_FOUND,
    action: 'PAGE_ACTION_HOME',
    redirect: HOME_PATH,
  },

  [HTTP_ACCESS_DENIED]: {
    code: HTTP_ACCESS_DENIED,
    title: 'PAGE_TITLE_NO_PERMISSION',
    image: ERROR_IMAGE_NOT_FOUND,
    message: 'PAGE_MESSAGE_NO_PERMISSION',
    action: 'PAGE_ACTION_HOME',
    redirect: HOME_PATH,
  },

  [HTTP_NOT_FOUND]: {
    code: HTTP_ACCESS_DENIED,
    title: 'PAGE_TITLE_NOT_FOUND',
    image: ERROR_IMAGE_NOT_FOUND,
    message: 'PAGE_MESSAGE_NOT_FOUND',
    action: 'PAGE_ACTION_HOME',
    redirect: HOME_PATH,
  },

  [HTTP_INTERVAL_SERVER_ERROR]: {
    code: HTTP_INTERVAL_SERVER_ERROR,
    title: 'PAGE_TITLE_INTERVAL_SERVER_ERROR',
    image: ERROR_IMAGE_EXERTION,
    action: 'PAGE_ACTION_HOME',
    redirect: HOME_PATH,
  },

  [HTTP_UNPROCESSABLE_ENTITY]: {
    code: HTTP_UNPROCESSABLE_ENTITY,
    title: 'PAGE_TITLE_INTERVAL_SERVER_ERROR',
    image: ERROR_IMAGE_EXERTION,
    action: 'PAGE_ACTION_HOME',
    redirect: HOME_PATH,
  },

  [INVITE]: {
    code: INVITE,
    message: 'PAGE_MESSAGE_WORKSPACE_NOT_FOUND',
    action: 'PAGE_ACTION_WORKSPACE_NOT_FOUND',
    redirect: MY_DOMAIN_PATH,
  },

  [REQUEST_ACCESS]: {
    force: true,
    redirect: REQUEST_ACCESS_PATH,
  },

  [UNKNOWN]: {
    code: UNKNOWN,
    title: 'PAGE_TITLE_UNKNOWN',
    image: ERROR_IMAGE_NOT_FOUND,
    message: 'PAGE_MESSAGE_UNKNOWN',
    action: 'PAGE_ACTION_HOME',
    redirect: HOME_PATH,
  },
};
