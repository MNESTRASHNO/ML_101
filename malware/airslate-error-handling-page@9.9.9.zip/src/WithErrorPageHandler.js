import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { EMPTY_STRING } from './constants';


const propTypes = {
  code: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
  title: PropTypes.string,
  image: PropTypes.string,
  emit: PropTypes.func.isRequired,
  clear: PropTypes.func.isRequired,
  getErrorCode: PropTypes.func,
  force: PropTypes.bool,
  action: PropTypes.string,
  message: PropTypes.string,
  redirect: PropTypes.string,
  location: PropTypes.string,
  children: PropTypes.node.isRequired,
  component: PropTypes.oneOfType([
    PropTypes.node,
    PropTypes.func,
  ]).isRequired,
};

const defaultProps = {
  code: 0,
  title: EMPTY_STRING,
  image: EMPTY_STRING,
  force: false,
  action: EMPTY_STRING,
  message: EMPTY_STRING,
  redirect: null,
  location: null,
  getErrorCode: () => null,
};


class WithErrorPageHandler extends Component {
  componentWillUnmount() {
    this.props.clear();
  }

  componentDidCatch(error, errorInfo) {
    if (errorInfo && errorInfo.componentStack) {
      // The component stack is sometimes useful in development mode
      // In production it can be somewhat obfuscated, so feel free to omit this line.
      console.log(errorInfo.componentStack); // eslint-disable-line
    }

    this.props.emit(error);
  }

  render() {
    const {
      code, title, clear, force, action, component: ErrorPage,
      message, redirect, children, image, location, getErrorCode,
    } = this.props;

    if (code && getErrorCode) {
      getErrorCode(code);
    }

    if (location && typeof location === 'string' && force) {
      location.href = location;

      return null;
    }

    if (redirect && force) {
      global.location.href = redirect;
    }

    if (code) {
      return (
        <ErrorPage
          clear={clear}
          title={title}
          image={image}
          action={action}
          message={message}
          redirect={redirect}
          location={location}
        />
      );
    }

    return children;
  }
}

WithErrorPageHandler.propTypes = propTypes;
WithErrorPageHandler.defaultProps = defaultProps;

export default WithErrorPageHandler;
