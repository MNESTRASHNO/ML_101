import { connect } from 'react-redux';
import errorHandler, { clearAction } from './action';
import WithErrorPageHandler from './WithErrorPageHandler';
import { EMPTY_ERROR_STATE } from './constants';

const mapDispatchToProps = {
  clear: clearAction,
  emit: errorHandler,
};

const selectSlatePermission = state => state.error || EMPTY_ERROR_STATE;

export default connect(selectSlatePermission, mapDispatchToProps)(WithErrorPageHandler);
