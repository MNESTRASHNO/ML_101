import { createAction } from 'redux-actions';
import {
  UNKNOWN,
  HOME_PATH,
  ERROR_ACTION_REQUEST,
  ERROR_ACTION_FORWARD,
  ERROR_ACTION_CLEAR,
  PAYLOAD_BY_ERROR_CODE,
} from './constants';


export const errorAction = createAction(ERROR_ACTION_REQUEST);
export const forwardAction = createAction(ERROR_ACTION_FORWARD);
export const clearAction = createAction(ERROR_ACTION_CLEAR);


export default function errorHandler(error) {
  const code = error.code || error.status || UNKNOWN;
  const isErrorInstance = error instanceof Error;

  if (PAYLOAD_BY_ERROR_CODE[code]) {
    if (isErrorInstance) {
      return errorAction(PAYLOAD_BY_ERROR_CODE[code]);
    }
    // Provide extra arguments
    return errorAction({ ...PAYLOAD_BY_ERROR_CODE[code], ...error });
  }

  if (isErrorInstance) {
    return errorAction({
      code,
      title: error.message,
      action: 'PAGE_ACTION_HOME',
      redirect: HOME_PATH,
    });
  }

  return Error(error);
}
