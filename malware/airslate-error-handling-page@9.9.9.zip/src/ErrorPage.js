import React from 'react';
import { string, func } from 'prop-types';
import { Link } from 'react-router-dom';

import Svg from 'airslate-controls/src/Svg';
import airSlateLogoSvg from 'airslate-static.icons/src/custom/airslate-logo.svg';

import ContentPlaceholder from 'ui-components/src/components/ContentPlaceholder';
import ContentPlaceholderImage from 'ui-components/src/components/ContentPlaceholder/ContentPlaceholderImage';
import ContentPlaceholderTitle from 'ui-components/src/components/ContentPlaceholder/ContentPlaceholderTitle';
import ContentPlaceholderText from 'ui-components/src/components/ContentPlaceholder/ContentPlaceholderText';
import ContentPlaceholderActions from 'ui-components/src/components/ContentPlaceholder/ContentPlaceholderActions';
import ContentPlaceholderButton from 'ui-components/src/components/ContentPlaceholder/ContentPlaceholderButton';

import { EMPTY_STRING, ERROR_IMAGE_ACCESS_DENIED } from './constants';
import loc from './locale';


const ErrorView = ({
  title,
  message,
  image,
  clear,
  action,
  redirect,
  location,
}) => (
  <div className="sl-grid__wrap">
    <main className="sl-grid__container">
      <div className="sl-grid__container-inner">
        <div className="page-logo page-logo--aligned-center">
          <div className="page-logo__image">
            <Svg symbol={airSlateLogoSvg} />
          </div>
        </div>
        <div className="sl-container sl-container--aligned-center">
          <ContentPlaceholder centered>
            <ContentPlaceholderImage>
              {image && <img src={image} alt={loc(title)} />}
            </ContentPlaceholderImage>
            <ContentPlaceholderTitle>
              <h1>{title && loc(title)}</h1>
            </ContentPlaceholderTitle>
            <ContentPlaceholderText>
              <p>{message && loc(message)}</p>
            </ContentPlaceholderText>
            <ContentPlaceholderActions size="sm">
              <ContentPlaceholderButton>
                {action && (redirect && !location) && (
                  <Link
                    to={redirect}
                    onClick={clear}
                    className="sl-button sl-button--primary"
                  >
                    <span className="sl-button__body">
                      <span className="sl-button__text">{loc(action)}</span>
                    </span>
                  </Link>
                )}
                {action && location && (
                  <a onClick={clear} href={location} className="sl-button sl-button--primary">
                    <span className="sl-button__body">
                      <span className="sl-button__text">{loc(action)}</span>
                    </span>
                  </a>
                )}
              </ContentPlaceholderButton>
            </ContentPlaceholderActions>
          </ContentPlaceholder>
        </div>
      </div>
    </main>
  </div>
);

ErrorView.propTypes = {
  title: string,
  message: string,
  redirect: string,
  location: string,
  image: string,
  action: string,
  clear: func.isRequired,
};

ErrorView.defaultProps = {
  title: EMPTY_STRING,
  message: EMPTY_STRING,
  redirect: EMPTY_STRING,
  location: EMPTY_STRING,
  image: ERROR_IMAGE_ACCESS_DENIED,
  action: EMPTY_STRING,
};

export default ErrorView;
