import Locale from '@airslate/front-locales/lib';

const { get } = Locale('AS_ERROR_', window.allConstants);

export default get;
