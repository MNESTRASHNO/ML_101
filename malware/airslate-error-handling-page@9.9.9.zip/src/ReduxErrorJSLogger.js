import requestError from './action';
import {
  UNKNOWN,
  REDUX_STORE,
  REDUX_ACTION,
  ERROR_ACTION_FORWARD,
} from './constants';

const dictionary = (arr) => {
  if (Array.isArray(arr)) {
    return arr.reduce((acc, key) => {
      acc[key] = true;
      return acc;
    }, {});
  }

  return {};
};

export default function ReduxErrorJSLogger(Sentry, Severity, option) {
  const filterState = (option && option.filterState) || false;
  const filterActions = (option && option.filterActions && dictionary(option.filterActions)) || {};

  return (store) => {
    const reduxStore = () => {
      const state = store.getState();

      if (filterState) {
        return { [REDUX_STORE]: filterState(state) };
      }

      return { [REDUX_STORE]: state };
    };

    const processException = (exception) => {
      const extra = reduxStore();

      Sentry.run(hub => hub.withScope((scope) => {
        scope.setExtras(extra);
        Sentry.captureException(exception);
      }));

      if (__LOCAL__ || __DEV__) {
        /* eslint-disable */
        console.log('---- ReduxErrorJSLogger ----');
        console.log(`Target: ${__APP_NAME__} - ${__BRANCH__}@${__BUILD_NUMBER__}`);
        console.error(exception);
        console.log('---- ReduxErrorJSLogger ----');
        /* eslint-enable */
      }

      store.dispatch(requestError(exception));
    };

    const trackCustomMessage = ({ payload }) => {
      const extra = reduxStore();
      const event = (payload && (payload.event || payload.code)) || UNKNOWN;
      const hint = (payload && (payload.hint || payload.message)) || UNKNOWN;

      Sentry.run(hub => hub.withScope((scope) => {
        scope.setExtras(extra);
        Sentry.captureEvent(event, hint);
      }));
    };

    const trackNexAction = ({ type: message, payload: data }) => {
      Sentry.run(hub => hub.addBreadcrumb({
        data,
        message,
        category: REDUX_ACTION,
        level: Severity.Debug,
      }));
    };

    const proxyResult = value => value;

    const wrapErrorHandling = action => (...args) => {
      let result;
      try {
        result = action(...args);
      } catch (err) {
        // sync error in reducer within a thunk
        processException(err);
      }
      if (result instanceof Promise) {
        // async error in thunk
        return result.then(proxyResult).catch(processException);
      }
      return result;
    };

    return next => (action) => {
      if (action && action.type) {
        if (action.type === ERROR_ACTION_FORWARD) {
          // Send custom exception to Sentry
          trackCustomMessage(action);
        } else if (filterActions[action.type] == null) {
          // Add action to Sentry Breadcrumb
          trackNexAction(action);
        }

        // Ignore plain actions
        return next(action);
      }

      return next(wrapErrorHandling(action));
    };
  };
}
