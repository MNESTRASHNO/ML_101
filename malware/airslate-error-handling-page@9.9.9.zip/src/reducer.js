import { handleActions } from 'redux-actions';
import { EMPTY_STRING, ERROR_ACTION_REQUEST, ERROR_ACTION_CLEAR } from './constants';


const defaultActionHandler = (state, { payload }) => ({ ...state, ...payload });


const initialState = {
  code: 0,
  title: EMPTY_STRING,
  action: EMPTY_STRING,
  message: EMPTY_STRING,
  redirect: EMPTY_STRING,
};

export default handleActions({
  [ERROR_ACTION_REQUEST]: defaultActionHandler,
  [ERROR_ACTION_CLEAR]: () => initialState,
}, initialState);
