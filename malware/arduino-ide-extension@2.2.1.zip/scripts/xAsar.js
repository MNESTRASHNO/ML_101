const asar = require("asar");

// 打开 app.asar 文件
const archive = asar.open("/Applications/aDrive.app/Contents/Resources/app.asar");

// 列出 app.asar 文件中的所有文件
const files = archive.list();

// 遍历 app.asar 文件中的所有文件
for (const file of files) {
  // 读取文件内容
  const data = archive.read(file);

  // 打印文件名和文件内容
  console.log(`${file}: ${data}`);
}

