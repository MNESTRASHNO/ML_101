'use strict';

const linux = require('./linux.js');
const win32 = require('./win32.js');
module.exports = { win32, linux };
