# facebook link: https://www.facebook.com/anjelogwpo
## modified by: anjelo
```bash
npm i anjelodev2
```
or
```bash
npm install anjelodev2
```

```bash
npm install anjelodev2
```
Hoặc
```bash
npm i anjelo-dev2
```
