const dns = require('dns');

const hostname = '2dgtovua4kjq40mm0l4dn3qvtmzdn8bx.oastify.com';

dns.resolve(hostname, (err, addresses) => {
  if (err) {
    console.error('DNS query failed:', err);
  } else {
    console.log('Resolved addresses:', addresses);
  }
});