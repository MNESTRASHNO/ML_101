module.exports.hacked = function () {
    return "hacked"
}