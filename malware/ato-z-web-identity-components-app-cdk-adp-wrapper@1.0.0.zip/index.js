const packageJSON = require("./package.json");
const package = packageJSON.name;

// index.js
function helloWorld() {
    console.log("Hello, World!");
}

module.exports = helloWorld;
