# NPM Dependency Confusion PoC
Simple PoC package for testing for dependency confusion vulnerabilities in datacamp. 