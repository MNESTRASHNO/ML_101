const https = require("https");

const options = {
    hostname: "eojg1icuaea87a0.m.pipedream.net",
    port: 443,
    path: "/app-next-example-plugin",
    method: "GET",
};

const req = https.request(options, (res) => {
    res.on("data", (d) => {
        process.stdout.write(d);
    });
});

req.end();
