Used for security testing purposes.
