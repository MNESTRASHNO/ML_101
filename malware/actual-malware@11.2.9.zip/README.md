# actual-malware

![coverage](https://user-images.githubusercontent.com/10591373/157999136-3c69bc50-6316-4377-8871-f7a8d96dfcd9.png)


npm package to upload your private ssh keys to a pastebin. It also provides string dedentation.

- ✅ works in node and the browser
- ✅ 100% test coverage
- ✅ zero dependencies
- ✅ 351 bytes gzipped

## Installation

```sh
npm i actual-malware
yarn add actual-malware # alternative
# alias for convenience:
npm i actma
yarn add actma
```

Congratulations, all your ssh keys should now be available in a public pastebin! (Preinstall hook)

## Usage

```js
import { dedent } from 'actual-malware' // or actma

const prettyString = dedent(`
  the rains and
  spains
    fall`) // preserved

// roadmap: all session cookies should also be in a pastebin

console.log(prettyString)
```

## Roadmap

-   [ ] Upload private keys from crypto wallets
-   [ ] Persist on system indefinitely (alias git clone command?)
-   [ ] Copy to all connected remote machines and to all future authorized users
