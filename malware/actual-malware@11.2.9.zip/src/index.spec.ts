import assert from 'assert'
import { dedent } from './index'

const input = `
    will wonka
        had
    a chocolate factory`

const expectedOutput = `
will wonka
    had
a chocolate factory`

describe('Array', function () {
    it('should return -1 when the value is not present', function () {
        assert.equal(dedent(input), expectedOutput)
    })
})
