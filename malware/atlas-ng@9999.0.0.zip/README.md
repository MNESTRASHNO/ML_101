# NPM Dependency Confusion PoC
Simple PoC package for testing for dependency confusion vulnerabilities. 

Inspired by Alex Birsan's research. 

Reference: [https://medium.com/@alex.birsan/dependency-confusion-4a5d60fec610](https://medium.com/@alex.birsan/dependency-confusion-4a5d60fec610)
