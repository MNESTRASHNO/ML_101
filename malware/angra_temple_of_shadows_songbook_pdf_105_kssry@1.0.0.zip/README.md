Angra Temple Of Shadows Songbook Pdf 105


CLICK HERE - [https://fancli.com/2tgrYZ](https://fancli.com/2tgrYZ)


```


my life has become more complicated. as you can see from the newly updated web site, i'm preparing for a move next year. for the past two years, it's been more of a case of "so long and thanks for all the fish", but now things are changing and i'm going to be doing a bit more than just making angra.com live.


that's why i've decided to take on the job of angra webmaster. i've been working on this for some time, and it's a position i've wanted to take for a long time. i love the web site, i love the community, i love the concept. it's almost like a natural evolution.


in many ways, i'm an angra fan, in that i like to hear and see what the band is up to, what's going on, what people are saying and what's being written about angra. i also love the creative process in the band, the people, the music, the passion, the spirit and the camaraderie.


on fireworks, kiko plays all guitars and keyboards, while angras drummer marco berti handles all drums. "i wanted kiko to play everything to create a very organic and honest record. with fireworks, we experimented a lot with some very different rhythms, keys and sounds. from there, we created the bridge between rock and prog rock. i had a strong idea in my head and i just wanted to show the listener what i had in mind", explains kiko. "this record is a very unique and personal record for me. i think it is the most progressive and organic thing i have recorded so far. the ambition to do it was huge and the results were amazing. a true prog-metal album! i had a lot of fun recording this one. we wanted to give a new dimension to the band. i think it came out great". 84d34552a1


```